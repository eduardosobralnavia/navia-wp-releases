<?php















defined( 'ABSPATH' ) || exit;

class NAS_Abilities {

	const CATEGORY = 'navia-suite';

	public static function init(): void {
		add_action( 'wp_abilities_api_categories_init', array( __CLASS__, 'category' ) );
		add_action( 'wp_abilities_api_init', array( __CLASS__, 'register' ) );
	}

	public static function category(): void {
		if ( function_exists( 'wp_has_ability_category' ) && wp_has_ability_category( self::CATEGORY ) ) {
			return;
		}
		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => 'Navia Suite',
				'description' => 'Environment, checks, caches and the setup of the standard stack (Contact Form 7, OMGF, Cookie Notice).',
			)
		);
	}

	private static function permission( string $cap, string $module = '' ): callable {
		return static function () use ( $cap, $module ) {
			if ( ! is_user_logged_in() ) {
				return new WP_Error( 'nas_not_logged_in', 'The request is not authenticated as a WordPress user.' );
			}
			if ( ! NAS_Settings::module_on( 'suite_mcp' ) ) {
				return new WP_Error( 'nas_module_off', 'The Suite tools (MCP) module is off on this site (Navia Suite > Modules).' );
			}
			if ( $module && ! NAS_Plugin::is_loaded( $module ) ) {
				return new WP_Error( 'nas_module_off', 'The ' . ( NAS_Settings::modules()[ $module ]['label'] ?? $module ) . ' module is off on this site (Navia Suite > Modules).' );
			}
			return current_user_can( $cap );
		};
	}

	private static function rate(): bool {
		$key   = 'nas_rate_' . get_current_user_id();
		$count = (int) get_transient( $key );
		if ( $count >= 30 ) {
			return false;
		}
		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		return true;
	}

	private static function reg( string $name, string $label, string $desc, array $props, callable $cb, callable $perm, bool $readonly = false, array $required = array() ): void {
		$schema = array(
			'type'                 => 'object',
			'properties'           => $props,
			'additionalProperties' => false,
		);
		if ( $required ) {
			$schema['required'] = $required;
		} else {
			$schema['default'] = array();
		}
		wp_register_ability(
			self::CATEGORY . '/' . $name,
			array(
				'label'               => $label,
				'description'         => $desc,
				'category'            => self::CATEGORY,
				'input_schema'        => $schema,
				'execute_callback'    => $cb,
				'permission_callback' => $perm,
				'meta'                => array(
					'annotations'  => array(
						'readonly'    => $readonly,
						'destructive' => false,
						'idempotent'  => $readonly,
					),
					'public'       => true,
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
				),
			)
		);
	}

	public static function register(): void {
		self::reg(
			'get-environment',
			'Suite environment and checks',
			'Call first in a session. Returns the mode (single, network, subsite), WordPress, PHP, Elementor (Free or Pro), theme, languages, the modules running here, the status of every stack plugin (Rank Math, Polylang, W3TC, OMGF, CF7, Post SMTP, Cookie Notice, UpdraftPlus, Wordfence...), and every check with status ok, warn, fail or info, what to do, and the key of a one click fix when there is one.',
			array(),
			array( __CLASS__, 'get_environment' ),
			self::permission( 'manage_options' ),
			true
		);

		self::reg(
			'purge-caches',
			'Clear caches',
			'Clears the page cache (one post, or everything when post_id is 0 or missing), the W3TC database cache when it is on, Elementor generated CSS and the Rank Math sitemap cache. Call after design changes that touch every page.',
			array( 'post_id' => array( 'type' => 'integer', 'minimum' => 0 ) ),
			array( __CLASS__, 'purge' ),
			self::permission( 'edit_pages' )
		);

		self::reg(
			'setup-contact-form',
			'Create or update the lead form',
			'Creates or updates the Contact Form 7 lead form of one language: name, email, phone, optional service and area lists, message, privacy consent with the privacy page of that language, labels and messages in that language (pt is European Portuguese). Mail goes to recipient (the client), From the site mailbox (Post SMTP sender), Reply-To the visitor, with the page URL and date. Returns the id and the shortcode to put in an Elementor Shortcode widget. Run once per language.',
			array(
				'lang'           => array( 'type' => 'string', 'description' => 'Polylang slug, for example pt or en.' ),
				'recipient'      => array( 'type' => 'string', 'format' => 'email', 'description' => 'Client email that receives the leads.' ),
				'title'          => array( 'type' => 'string' ),
				'services'       => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'areas'          => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'privacy_url'    => array( 'type' => 'string', 'description' => 'Optional. Default: privacy policy page of that language.' ),
				'phone_required' => array( 'type' => 'boolean' ),
				'form_id'        => array( 'type' => 'integer', 'description' => 'Update this form instead of the one the Suite made for the language.' ),
			),
			array( __CLASS__, 'setup_form' ),
			self::permission( 'manage_options', 'forms' ),
			false,
			array( 'lang', 'recipient' )
		);

		self::reg(
			'get-font-plan',
			'Font plan for OMGF',
			'Lists every font family and weight the Elementor site uses (kit, theme style, pages, headers, footers, templates), what OMGF detected, and which files would be kept, unloaded and preloaded. Read only. Status nothing_detected means OMGF needs Save & Optimize and a visit first.',
			array(),
			array( __CLASS__, 'font_plan' ),
			self::permission( 'manage_options', 'fonts' ),
			true
		);

		self::reg(
			'apply-font-plan',
			'Apply the font plan to OMGF',
			'Unloads every font file the site does not use, preloads up to four kept regular weights, sets latin only and font-display swap, clears caches and visits the homepage. Check the pages afterwards; tell the person to measure only after two or three visits.',
			array( 'preload' => array( 'type' => 'boolean', 'default' => true ) ),
			array( __CLASS__, 'apply_fonts' ),
			self::permission( 'manage_options', 'fonts' )
		);

		self::reg(
			'setup-cookie-notice',
			'Configure the cookie bar',
			'Writes Cookie Notice: texts per language (message, accept, refuse, more, revoke; missing ones use European Portuguese or English defaults), colours from the Elementor kit, refuse and revoke on, privacy policy page of each language.',
			array(
				'texts' => array(
					'type'                 => 'object',
					'description'          => 'lang => {message, accept, refuse, more, revoke}',
					'additionalProperties' => array(
						'type'       => 'object',
						'properties' => array(
							'message' => array( 'type' => 'string' ),
							'accept'  => array( 'type' => 'string' ),
							'refuse'  => array( 'type' => 'string' ),
							'more'    => array( 'type' => 'string' ),
							'revoke'  => array( 'type' => 'string' ),
						),
					),
				),
			),
			array( __CLASS__, 'setup_cookies' ),
			self::permission( 'manage_options', 'cookies' )
		);

		self::reg(
			'apply-fix',
			'Apply a one click fix',
			'Applies a fix listed by get-environment (field action of a check): elementor_perf (Elementor performance settings that gave 90+ on mobile), trash_samples (Hello world and Sample Page to the trash), hygiene_on (no per-post feed links).',
			array( 'fix' => array( 'type' => 'string', 'enum' => array( 'elementor_perf', 'trash_samples', 'hygiene_on' ) ) ),
			array( __CLASS__, 'apply_fix' ),
			self::permission( 'manage_options' ),
			false,
			array( 'fix' )
		);

		self::reg(
			'get-update-log',
			'Update log',
			'Returns the Suite update log with the environment and the open checks, as Markdown, ready for the development project.',
			array(),
			array( __CLASS__, 'update_log' ),
			self::permission( 'manage_options' ),
			true
		);
	}



	public static function get_environment( $input = array() ) {
		$checks = NAS_Checks::run();
		$mods   = array();
		foreach ( NAS_Settings::modules() as $k => $m ) {
			$mods[ $k ] = array(
				'label'   => $m['label'],
				'on'      => NAS_Settings::module_on( $k ),
				'running' => NAS_Plugin::is_loaded( $k ),
				'legacy'  => NAS_Settings::legacy_active( $k ),
			);
		}
		$out = array(
			'environment' => NAS_Env::summary(),
			'modules'     => $mods,
			'stack'       => NAS_Env::stack_status(),
			'conflicts'   => NAS_Env::conflicts(),
			'counts'      => NAS_Checks::counts( $checks ),
			'checks'      => $checks,
		);
		if ( class_exists( 'NAS_SMTP' ) ) {
			$out['smtp'] = NAS_SMTP::status();
		}
		if ( class_exists( 'NAS_Forms' ) ) {
			$out['forms'] = NAS_Settings::get( 'forms' )['forms'] ?? array();
		}
		return $out;
	}

	public static function purge( $input = array() ) {
		if ( ! self::rate() ) {
			return new WP_Error( 'nas_rate', 'Too many calls in the last minute.' );
		}
		$post_id = (int) ( $input['post_id'] ?? 0 );
		return array( 'purged' => NAS_Cache::purge( $post_id ), 'post_id' => $post_id );
	}

	public static function setup_form( $input ) {
		if ( ! self::rate() ) {
			return new WP_Error( 'nas_rate', 'Too many calls in the last minute.' );
		}
		return NAS_Forms::setup( (array) $input );
	}

	public static function font_plan( $input = array() ) {
		return NAS_Fonts::plan();
	}

	public static function apply_fonts( $input = array() ) {
		if ( ! self::rate() ) {
			return new WP_Error( 'nas_rate', 'Too many calls in the last minute.' );
		}
		return NAS_Fonts::apply( ! isset( $input['preload'] ) || (bool) $input['preload'] );
	}

	public static function setup_cookies( $input = array() ) {
		if ( ! self::rate() ) {
			return new WP_Error( 'nas_rate', 'Too many calls in the last minute.' );
		}
		if ( ! NAS_Cookies::available() ) {
			return new WP_Error( 'nas_no_cookie_notice', 'Cookie Notice is not active on this site.' );
		}
		if ( ! empty( $input['texts'] ) && is_array( $input['texts'] ) ) {
			NAS_Cookies::save_texts( $input['texts'] );
		}
		return NAS_Cookies::apply();
	}

	public static function apply_fix( $input ) {
		$msg = NAS_Checks::apply_fix( (string) ( $input['fix'] ?? '' ) );
		if ( ! $msg ) {
			return new WP_Error( 'nas_unknown_fix', 'Unknown fix.' );
		}
		NAS_Updater::record( 'fix', $msg . ' (MCP)' );
		return array( 'done' => $msg );
	}

	public static function update_log( $input = array() ) {
		return array( 'markdown' => NAS_Updater::export_markdown() );
	}
}
