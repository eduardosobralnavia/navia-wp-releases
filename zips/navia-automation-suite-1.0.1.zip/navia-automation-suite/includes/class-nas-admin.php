<?php





defined( 'ABSPATH' ) || exit;

class NAS_Admin {

	const MENU = 'navia-suite';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'site_menu' ), 9 );
		add_action( 'network_admin_menu', array( __CLASS__, 'network_menu' ), 9 );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'network_admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_post_nas_save_modules', array( __CLASS__, 'save_modules' ) );
		add_action( 'admin_post_nas_save_site', array( __CLASS__, 'save_site' ) );
		add_action( 'admin_post_nas_apply_fix', array( __CLASS__, 'apply_fix' ) );
		add_action( 'admin_post_nas_export_log', array( __CLASS__, 'export_log' ) );
		add_action( 'admin_post_nas_save_updates', array( __CLASS__, 'save_updates' ) );
		add_action( 'network_admin_edit_nas_save_matrix', array( __CLASS__, 'save_matrix' ) );
		add_action( 'network_admin_edit_nas_save_updates', array( __CLASS__, 'save_updates' ) );
		add_filter( 'plugin_action_links_' . NAS_Env::basename(), array( __CLASS__, 'links' ) );
		add_filter( 'network_admin_plugin_action_links_' . NAS_Env::basename(), array( __CLASS__, 'network_links' ) );
	}

	public static function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::MENU ) ) . '">Dashboard</a>' );
		return $links;
	}

	public static function network_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( network_admin_url( 'admin.php?page=' . self::MENU ) ) . '">Network dashboard</a>' );
		return $links;
	}

	private static function icon(): string {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M3 16V4h2.4l6.2 8.1V4H14v12h-2.4L5.4 7.9V16z"/><circle cx="17" cy="15" r="2" fill="#a7aaad"/></svg>';
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	public static function site_menu(): void {
		add_menu_page( 'Navia Suite', 'Navia Suite', 'manage_options', self::MENU, array( __CLASS__, 'dashboard' ), self::icon(), 58 );
		add_submenu_page( self::MENU, 'Navia Suite', 'Dashboard', 'manage_options', self::MENU, array( __CLASS__, 'dashboard' ) );
		add_submenu_page( self::MENU, 'Modules', 'Modules', 'manage_options', 'navia-suite-modules', array( __CLASS__, 'modules_page' ) );
		add_submenu_page( self::MENU, 'Stack', 'Stack', 'manage_options', 'navia-suite-stack', array( __CLASS__, 'stack_page' ) );
		add_submenu_page( self::MENU, 'Updates', 'Updates', 'manage_options', 'navia-suite-updates', array( __CLASS__, 'updates_page' ) );
	}

	public static function network_menu(): void {
		if ( ! NAS_Env::network_mode() ) {
			return;
		}
		add_menu_page( 'Navia Suite', 'Navia Suite', 'manage_network_options', self::MENU, array( __CLASS__, 'network_dashboard' ), self::icon(), 22 );
		add_submenu_page( self::MENU, 'Navia Suite', 'Sites and modules', 'manage_network_options', self::MENU, array( __CLASS__, 'network_dashboard' ) );
		add_submenu_page( self::MENU, 'Updates', 'Updates', 'manage_network_options', 'navia-suite-updates', array( __CLASS__, 'updates_page' ) );
	}



	public static function notice_flash( string $msg ): void {
		set_transient( 'nas_notice_' . get_current_user_id(), $msg, 60 );
	}

	public static function notices(): void {
		$msg = get_transient( 'nas_notice_' . get_current_user_id() );
		if ( $msg ) {
			delete_transient( 'nas_notice_' . get_current_user_id() );
			echo '<div class="notice notice-success is-dismissible"><p>' . wp_kses_post( $msg ) . '</p></div>';
		}
		if ( NAS_Plugin::legacy() && current_user_can( 'activate_plugins' ) ) {
			$names = array();
			foreach ( NAS_Plugin::legacy() as $k ) {
				$names[] = NAS_Settings::modules()[ $k ]['label'];
			}
			echo '<div class="notice notice-warning"><p><strong>Navia Suite:</strong> these modules did not start because the old standalone plugin is still active: ' . esc_html( implode( ', ', array_unique( $names ) ) ) . '. Deactivate the old plugin; its settings and content are read by the Suite as they are.</p></div>';
		}
	}

	private static function badge( string $status ): string {
		$map = array(
			'ok'   => array( '#00a32a', 'OK' ),
			'warn' => array( '#dba617', 'Attention' ),
			'fail' => array( '#d63638', 'Fix' ),
			'info' => array( '#2271b1', 'Info' ),
		);
		$s = $map[ $status ] ?? $map['info'];
		return '<span style="display:inline-block;min-width:68px;text-align:center;padding:2px 8px;border-radius:10px;color:#fff;font-size:11px;font-weight:600;background:' . $s[0] . '">' . $s[1] . '</span>';
	}

	public static function header( string $title ): void {
		echo '<div class="wrap nas-wrap"><h1>' . esc_html( $title ) . ' <span style="font-size:13px;color:#646970;font-weight:400">Navia Automation Suite ' . esc_html( NAS_VERSION ) . '</span></h1>';
		echo '<style>.nas-wrap .nas-card{background:#fff;border:1px solid #c3c4c7;padding:14px 18px;margin:16px 0;max-width:1100px}.nas-wrap .nas-card h2{margin-top:0}.nas-wrap td,.nas-wrap th{vertical-align:top}.nas-wrap .nas-muted{color:#646970}.nas-wrap .nas-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}</style>';
	}



	public static function dashboard(): void {
		$env    = NAS_Env::summary();
		$checks = NAS_Checks::run();
		$count  = NAS_Checks::counts( $checks );
		self::header( 'Navia Suite' );
		?>
		<div class="nas-card">
			<h2>This site</h2>
			<div class="nas-grid">
				<div><strong>Mode</strong><br><?php echo esc_html( $env['mode_label'] ); ?></div>
				<div><strong>WordPress / PHP</strong><br><?php echo esc_html( $env['wordpress'] . ' / ' . $env['php'] ); ?></div>
				<div><strong>Elementor</strong><br><?php echo esc_html( $env['elementor'] ? $env['elementor'] . ( $env['elementor_pro'] ? ' + Pro ' . $env['elementor_pro'] : ' (Free)' ) : 'Not active' ); ?></div>
				<div><strong>Theme</strong><br><?php echo esc_html( $env['theme'] ); ?></div>
				<div><strong>Languages</strong><br><?php echo esc_html( $env['languages'] ? implode( ', ', $env['languages'] ) : $env['default_lang'] ); ?></div>
				<div><strong>Suite / channel</strong><br><?php echo esc_html( NAS_VERSION . ' / ' . ucfirst( NAS_Updater::channel() ) ); ?></div>
				<div><strong>Checks</strong><br><?php echo (int) $count['fail']; ?> to fix, <?php echo (int) $count['warn']; ?> attention, <?php echo (int) $count['ok']; ?> OK</div>
			</div>
			<p class="nas-muted" style="margin-bottom:0">Modules running here: <?php echo esc_html( implode( ', ', array_map( static fn( $k ) => NAS_Settings::modules()[ $k ]['label'] ?? $k, NAS_Plugin::loaded() ) ) ); ?>. <a href="<?php echo esc_url( admin_url( 'admin.php?page=navia-suite-modules' ) ); ?>">Change</a></p>
		</div>

		<div class="nas-card">
			<h2>AI automation</h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="nas_save_site">
				<?php wp_nonce_field( 'nas_save_site' ); ?>
				<p><label for="nas_user"><strong>Automation user</strong></label>
				<?php
				wp_dropdown_users(
					array(
						'name'              => 'automation_user',
						'id'                => 'nas_user',
						'role__in'          => array( 'administrator' ),
						'selected'          => (int) NAS_Settings::get( 'automation_user' ),
						'show_option_none'  => 'Not chosen',
						'option_none_value' => 0,
					)
				);
				?>
				<span class="nas-muted">The account the agent connects with (a dedicated account, for example one named after the agent). Administrator of this site, never a super admin.</span></p>
				<p><label><input type="checkbox" name="auto_purge" value="1" <?php checked( NAS_Settings::get( 'auto_purge' ) ); ?>> Clear caches after Suite changes and after every Elementor save</label></p>
				<?php submit_button( 'Save', 'secondary', 'submit', false ); ?>
			</form>
			<p><strong>Claude connector URL:</strong> <code><?php echo esc_html( $env['mcp_endpoint'] ); ?></code><br>
			<span class="nas-muted">Claude &gt; Settings &gt; Connectors &gt; Add custom connector. Authentication: required when the server asks; OAuth client: Anthropic's hosted client metadata. Before Allow, be logged in on this site as the automation user. If it fails, remove the connector and add it again (do not use Reconnect). Open a new conversation afterwards: connectors load when a conversation starts.</span></p>
		</div>

		<div class="nas-card">
			<h2>Checks</h2>
			<table class="widefat striped">
				<thead><tr><th style="width:90px">Status</th><th style="width:22%">Check</th><th>Detail</th><th style="width:28%">What to do</th></tr></thead>
				<tbody>
				<?php
				$order = array( 'fail' => 0, 'warn' => 1, 'info' => 2, 'ok' => 3 );
				usort( $checks, static fn( $a, $b ) => $order[ $a['status'] ] <=> $order[ $b['status'] ] );
				foreach ( $checks as $ch ) :
					?>
					<tr>
						<td><?php echo self::badge( $ch['status'] ); ?></td>
						<td><strong><?php echo esc_html( $ch['label'] ); ?></strong><br><span class="nas-muted"><?php echo esc_html( $ch['group'] ); ?></span></td>
						<td><?php echo esc_html( $ch['detail'] ); ?></td>
						<td><?php echo esc_html( $ch['fix'] ); ?>
							<?php if ( $ch['action'] ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px">
									<input type="hidden" name="action" value="nas_apply_fix">
									<input type="hidden" name="fix" value="<?php echo esc_attr( $ch['action'] ); ?>">
									<?php wp_nonce_field( 'nas_apply_fix' ); ?>
									<button class="button button-small">Fix now</button>
								</form>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		</div>
		<?php
	}

	public static function save_site(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_save_site' );
		NAS_Settings::save_site(
			array(
				'automation_user' => isset( $_POST['automation_user'] ) ? absint( $_POST['automation_user'] ) : 0,
				'auto_purge'      => ! empty( $_POST['auto_purge'] ),
			)
		);
		self::notice_flash( 'Saved.' );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::MENU ) );
		exit;
	}

	public static function apply_fix(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_apply_fix' );
		$msg = NAS_Checks::apply_fix( isset( $_POST['fix'] ) ? sanitize_key( $_POST['fix'] ) : '' );
		NAS_Updater::record( 'fix', $msg );
		self::notice_flash( $msg ? $msg : 'Nothing to do.' );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::MENU ) );
		exit;
	}



	public static function modules_page(): void {
		self::header( 'Modules' );
		$network  = NAS_Env::network_mode();
		$editable = ! $network || current_user_can( 'manage_network_options' );
		$groups   = array(
			'automation'   => 'AI automation (MCP)',
			'elementor'    => 'Elementor Free extras',
			'optimisation' => 'Optimisation',
			'stack'        => 'Stack setup',
		);
		if ( $network ) {
			echo '<p>This site is part of a network. ' . ( current_user_can( 'manage_network_options' ) ? 'You can change its modules here or for every site in <a href="' . esc_url( network_admin_url( 'admin.php?page=' . self::MENU ) ) . '">Network Admin &gt; Navia Suite</a>.' : 'Only a super admin changes the modules.' ) . '</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="nas_save_modules">';
		wp_nonce_field( 'nas_save_modules' );
		foreach ( $groups as $g => $gl ) {
			echo '<div class="nas-card"><h2>' . esc_html( $gl ) . '</h2><table class="form-table" role="presentation">';
			foreach ( NAS_Settings::modules() as $key => $m ) {
				if ( $m['group'] !== $g ) {
					continue;
				}
				$on     = NAS_Settings::module_on( $key );
				$ready  = NAS_Settings::module_ready( $key );
				$legacy = NAS_Settings::legacy_active( $key );
				$state  = $legacy ? 'Old plugin still active' : ( ! $ready ? 'Requirements missing (' . implode( ', ', $m['needs'] ) . ')' : ( NAS_Plugin::is_loaded( $key ) ? 'Running' : 'Off' ) );
				echo '<tr><th scope="row">' . esc_html( $m['label'] ) . '</th><td>';
				echo '<label><input type="checkbox" name="modules[' . esc_attr( $key ) . ']" value="1" ' . checked( $on, true, false ) . disabled( ! $editable, true, false ) . '> On</label> <span class="nas-muted">(' . esc_html( $state ) . ')</span>';
				if ( 'theme_builder' === $key && NAS_Env::elementor_pro() ) {
					echo '<br><strong>Elementor Pro is active:</strong> keep this off unless the site uses no Pro theme builder.';
				}
				echo '<p class="description">' . esc_html( $m['desc'] ) . '</p></td></tr>';
			}
			echo '</table></div>';
		}
		if ( $editable ) {
			submit_button( 'Save modules' );
		}
		echo '</form></div>';
	}

	public static function save_modules(): void {
		$network = NAS_Env::network_mode();
		if ( ! current_user_can( $network ? 'manage_network_options' : 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_save_modules' );
		$posted  = isset( $_POST['modules'] ) && is_array( $_POST['modules'] ) ? array_map( 'sanitize_key', array_keys( wp_unslash( $_POST['modules'] ) ) ) : array();
		$modules = array();
		foreach ( NAS_Settings::module_keys() as $key ) {
			$modules[ $key ] = in_array( $key, $posted, true );
		}
		NAS_Settings::save_site( array( 'modules' => $modules ) );
		NAS_Updater::record( 'modules', 'Modules on ' . home_url( '/' ) . ': ' . implode( ', ', array_keys( array_filter( $modules ) ) ) );
		update_option( 'nas_flush_rewrite', 1, false );
		NAS_Cache::after_change( 0 );
		self::notice_flash( 'Modules saved. Caches cleared.' );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-modules' ) );
		exit;
	}



	public static function network_dashboard(): void {
		self::header( 'Navia Suite: sites and modules' );
		$sites   = get_sites( array( 'number' => 500, 'orderby' => 'id' ) );
		$modules = NAS_Settings::modules();
		$net     = NAS_Settings::network();
		?>
		<p>Each subsite runs only the ticked modules. New sites get the defaults in the last row. The Theme Builder default is off on sites with Elementor Pro.</p>
		<form method="post" action="<?php echo esc_url( network_admin_url( 'edit.php?action=nas_save_matrix' ) ); ?>">
			<?php wp_nonce_field( 'nas_save_matrix' ); ?>
			<div style="overflow-x:auto;max-width:100%">
			<table class="widefat striped" style="width:auto">
				<thead><tr><th>Site</th>
				<?php foreach ( $modules as $key => $m ) : ?>
					<th style="font-size:11px;max-width:90px"><?php echo esc_html( $m['label'] ); ?></th>
				<?php endforeach; ?>
				</tr></thead>
				<tbody>
				<?php
				foreach ( $sites as $site ) :
					$bid = (int) $site->blog_id;
					?>
					<tr><td><strong><?php echo esc_html( get_blog_option( $bid, 'blogname' ) ); ?></strong><br><span class="nas-muted"><?php echo esc_html( $site->domain . $site->path ); ?></span></td>
					<?php foreach ( $modules as $key => $m ) : ?>
						<td style="text-align:center"><input type="checkbox" name="m[<?php echo (int) $bid; ?>][<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( NAS_Settings::module_on( $key, $bid ) ); ?>></td>
					<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
				<tr><td><em>New sites</em></td>
				<?php foreach ( $modules as $key => $m ) : ?>
					<td style="text-align:center"><input type="checkbox" name="new[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( isset( $net['new_site_modules'][ $key ] ) ? (bool) $net['new_site_modules'][ $key ] : NAS_Settings::module_default( $key ) ); ?>></td>
				<?php endforeach; ?>
				</tr>
				</tbody>
			</table>
			</div>
			<?php submit_button( 'Save' ); ?>
		</form>
		<div class="nas-card">
			<h2>Module screens</h2>
			<p>Articles (MCP): image provider keys for the whole network. Elementor (MCP): uniqueness index of the network. Performance: every subsite in one screen. Each site keeps its own page under Navia Suite in its dashboard.</p>
		</div>
		</div>
		<?php
	}

	public static function save_matrix(): void {
		if ( ! current_user_can( 'manage_network_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_save_matrix' );
		$m     = isset( $_POST['m'] ) && is_array( $_POST['m'] ) ? wp_unslash( $_POST['m'] ) : array();
		$sites = get_sites( array( 'fields' => 'ids', 'number' => 500 ) );
		foreach ( $sites as $bid ) {
			$row = array();
			foreach ( NAS_Settings::module_keys() as $key ) {
				$row[ $key ] = ! empty( $m[ $bid ][ $key ] );
			}
			NAS_Settings::save_site( array( 'modules' => $row ), (int) $bid );
		}
		$new = array();
		foreach ( NAS_Settings::module_keys() as $key ) {
			$new[ $key ] = ! empty( $_POST['new'][ $key ] );
		}
		NAS_Settings::save_network( array( 'new_site_modules' => $new ) );
		NAS_Updater::record( 'modules', 'Network module matrix saved' );
		self::notice_flash( 'Saved. Each site loads its modules from the next request.' );
		wp_safe_redirect( network_admin_url( 'admin.php?page=' . self::MENU ) );
		exit;
	}



	public static function stack_page(): void {
		$tabs = array(
			'forms'   => array( 'Forms', 'NAS_Forms' ),
			'smtp'    => array( 'Email', 'NAS_SMTP' ),
			'cookies' => array( 'Cookies', 'NAS_Cookies' ),
			'fonts'   => array( 'Fonts', 'NAS_Fonts' ),
			'hygiene' => array( 'SEO hygiene', 'NAS_Hygiene' ),
		);
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'forms';
		$tab = isset( $tabs[ $tab ] ) ? $tab : 'forms';
		self::header( 'Stack' );
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $t ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=navia-suite-stack&tab=' . $k ) ) . '">' . esc_html( $t[0] ) . '</a>';
		}
		echo '</nav>';
		$class = $tabs[ $tab ][1];
		if ( class_exists( $class ) ) {
			$class::render_tab();
		} else {
			echo '<div class="nas-card"><p>This module is off on this site. Switch it on in <a href="' . esc_url( admin_url( 'admin.php?page=navia-suite-modules' ) ) . '">Modules</a>.</p></div>';
		}
		echo '</div>';
	}



	public static function updates_page(): void {
		$is_net = is_network_admin();
		self::header( 'Updates' );
		$net = NAS_Settings::network();
		$m   = NAS_Updater::manifest();
		?>
		<div class="nas-card">
			<h2>Version and update channel</h2>
			<p>Installed: <strong><?php echo esc_html( NAS_VERSION ); ?></strong>. Channel: <strong><?php echo esc_html( ucfirst( NAS_Updater::channel() ) ); ?></strong><?php echo $net['manifest_url'] ? ' (custom manifest)' : ''; ?>.
			<?php if ( $m ) : ?>
				Latest on this channel: <strong><?php echo esc_html( $m['version'] ); ?></strong><?php echo version_compare( $m['version'], NAS_VERSION, '>' ) ? ' (update available in Plugins)' : ' (up to date)'; ?>.
			<?php elseif ( 'off' !== NAS_Updater::channel() ) : ?>
				No version published on this channel yet.
			<?php endif; ?></p>
			<?php if ( ! is_multisite() || $is_net ) : ?>
			<form method="post" action="<?php echo esc_url( $is_net ? network_admin_url( 'edit.php?action=nas_save_updates' ) : admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="nas_save_updates">
				<?php wp_nonce_field( 'nas_save_updates' ); ?>
				<fieldset>
					<p><label><input type="radio" name="channel" value="stable" <?php checked( NAS_Updater::channel(), 'stable' ); ?>> <strong>Stable</strong>: versions already tested. For client sites.</label></p>
					<p><label><input type="radio" name="channel" value="beta" <?php checked( NAS_Updater::channel(), 'beta' ); ?>> <strong>Beta</strong>: every new version as soon as it is published. For the test site and our own sites.</label></p>
					<p><label><input type="radio" name="channel" value="off" <?php checked( NAS_Updater::channel(), 'off' ); ?>> <strong>Off</strong>: no update checks; versions are installed by uploading the zip.</label></p>
				</fieldset>
				<?php if ( is_multisite() ) : ?><p class="description">On a network the channel applies to every site.</p><?php endif; ?>
				<details style="margin:8px 0"><summary>Advanced: custom manifest URL</summary>
					<p><input type="url" class="large-text code" name="manifest_url" value="<?php echo esc_attr( $net['manifest_url'] ); ?>" placeholder="https://.../manifest.json"></p>
					<p class="description">Overrides the channel when filled. JSON with version, package, requires, requires_php, tested and changelog.</p>
				</details>
				<?php submit_button( 'Save', 'primary', 'submit', false ); ?>
				<?php submit_button( 'Check for updates now', 'secondary', 'check_now', false ); ?>
			</form>
			<?php else : ?>
				<p class="description">The channel is chosen by a super admin in Network Admin &gt; Navia Suite &gt; Updates.</p>
			<?php endif; ?>
			<p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nas_export_log' ), 'nas_export_log' ) ); ?>">Download the update log (Markdown)</a> <span class="nas-muted">Paste it into the development project when something needs fixing.</span></p>
		</div>
		<div class="nas-card">
			<h2>Update log</h2>
			<table class="widefat striped"><thead><tr><th style="width:150px">When (UTC)</th><th style="width:110px">Type</th><th style="width:70px">Version</th><th>What</th><th style="width:110px">Who</th></tr></thead><tbody>
			<?php foreach ( array_slice( array_reverse( NAS_Updater::log() ), 0, 100 ) as $e ) : ?>
				<tr><td><?php echo esc_html( $e['time'] ); ?></td><td><?php echo esc_html( $e['type'] ); ?></td><td><?php echo esc_html( $e['version'] ); ?></td><td><?php echo esc_html( $e['summary'] ); ?>
				<?php if ( ! empty( $e['details']['steps'] ) ) : ?>
					<ul style="margin:4px 0 0 18px;list-style:disc"><?php foreach ( (array) $e['details']['steps'] as $s ) : ?><li><?php echo esc_html( $s ); ?></li><?php endforeach; ?></ul>
				<?php endif; ?></td><td><?php echo esc_html( $e['user'] ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<div class="nas-card">
			<h2>Changelog</h2>
			<pre style="white-space:pre-wrap;max-height:480px;overflow:auto"><?php echo esc_html( NAS_Updater::changelog() ); ?></pre>
		</div>
		</div>
		<?php
	}

	public static function save_updates(): void {
		$cap = is_multisite() ? 'manage_network_options' : 'manage_options';
		if ( ! current_user_can( $cap ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_save_updates' );
		$before  = NAS_Updater::channel();
		$channel = isset( $_POST['channel'] ) ? sanitize_key( $_POST['channel'] ) : $before;
		$channel = in_array( $channel, NAS_Updater::CHANNELS, true ) ? $channel : 'stable';
		NAS_Updater::flush_manifest();
		NAS_Settings::save_network(
			array(
				'channel'      => $channel,
				'manifest_url' => isset( $_POST['manifest_url'] ) ? esc_url_raw( wp_unslash( $_POST['manifest_url'] ) ) : '',
			)
		);
		NAS_Updater::flush_manifest();
		if ( $before !== $channel ) {
			NAS_Updater::record( 'channel', 'Update channel changed from ' . $before . ' to ' . $channel );
		}
		$msg = 'Saved.';
		if ( ! empty( $_POST['check_now'] ) ) {
			wp_update_plugins();
			$m   = NAS_Updater::manifest();
			$msg = $m ? ( version_compare( $m['version'], NAS_VERSION, '>' ) ? 'Version ' . esc_html( $m['version'] ) . ' is available: update it in Plugins.' : 'Up to date (' . esc_html( NAS_VERSION ) . ').' ) : 'No version published on the ' . esc_html( $channel ) . ' channel yet.';
		}
		self::notice_flash( $msg );
		wp_safe_redirect( is_multisite() ? network_admin_url( 'admin.php?page=navia-suite-updates' ) : admin_url( 'admin.php?page=navia-suite-updates' ) );
		exit;
	}

	public static function export_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_export_log' );
		nocache_headers();
		header( 'Content-Type: text/markdown; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="navia-suite-log-' . sanitize_title( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '-' . gmdate( 'Ymd' ) . '.md"' );
		echo NAS_Updater::export_markdown();
		exit;
	}
}
