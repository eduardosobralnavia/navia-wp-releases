<?php








defined( 'ABSPATH' ) || exit;

class NAS_Cache {

	public static function init(): void {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 90 );
		add_action( 'admin_post_nas_purge', array( __CLASS__, 'handle_purge' ) );

		add_action( 'elementor/editor/after_save', array( __CLASS__, 'after_elementor_save' ), 20, 1 );
	}





	public static function purge( int $post_id = 0 ): array {
		$done = array();


		if ( $post_id && function_exists( 'w3tc_flush_post' ) ) {
			w3tc_flush_post( $post_id );
			$done[] = 'W3 Total Cache (page)';
		} elseif ( ! $post_id && function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
			$done[] = 'W3 Total Cache (all)';
		}
		if ( function_exists( 'w3tc_dbcache_flush' ) && self::w3tc_dbcache_on() ) {
			w3tc_dbcache_flush();
			$done[] = 'W3 Total Cache (database)';
		}
		if ( ! $post_id && function_exists( 'w3tc_objectcache_flush' ) ) {
			w3tc_objectcache_flush();
		}


		if ( defined( 'LSCWP_V' ) ) {
			do_action( $post_id ? 'litespeed_purge_post' : 'litespeed_purge_all', $post_id );
			$done[] = 'LiteSpeed Cache';
		}


		if ( $post_id && function_exists( 'rocket_clean_post' ) ) {
			rocket_clean_post( $post_id );
			$done[] = 'WP Rocket';
		} elseif ( ! $post_id && function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
			$done[] = 'WP Rocket';
		}


		if ( $post_id && function_exists( 'wp_cache_post_change' ) ) {
			wp_cache_post_change( $post_id );
			$done[] = 'WP Super Cache';
		} elseif ( ! $post_id && function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$done[] = 'WP Super Cache';
		}


		if ( class_exists( 'Cache_Enabler' ) ) {
			do_action( $post_id ? 'cache_enabler_clear_page_cache_by_post' : 'cache_enabler_clear_complete_cache', $post_id );
			$done[] = 'Cache Enabler';
		}


		if ( class_exists( 'WpFastestCache' ) ) {
			if ( $post_id ) {
				do_action( 'wpfc_clear_post_cache_by_id', false, $post_id );
			} else {
				do_action( 'wpfc_clear_all_cache' );
			}
			$done[] = 'WP Fastest Cache';
		}


		if ( ! $post_id && did_action( 'elementor/loaded' ) && class_exists( '\Elementor\Plugin' ) ) {
			$plugin = \Elementor\Plugin::$instance;
			if ( isset( $plugin->files_manager ) && method_exists( $plugin->files_manager, 'clear_cache' ) ) {
				$plugin->files_manager->clear_cache();
				$done[] = 'Elementor CSS';
			}
		}


		if ( class_exists( '\RankMath\Sitemap\Cache' ) && method_exists( '\RankMath\Sitemap\Cache', 'invalidate_storage' ) ) {
			\RankMath\Sitemap\Cache::invalidate_storage();
			$done[] = 'Rank Math sitemap';
		}

		if ( $post_id ) {
			clean_post_cache( $post_id );
		} else {
			wp_cache_flush();
		}







		do_action( 'nas_purge_cache', $post_id, $done );

		return $done;
	}

	public static function w3tc_dbcache_on(): bool {
		if ( ! class_exists( '\W3TC\Dispatcher' ) ) {
			return false;
		}
		try {
			$config = \W3TC\Dispatcher::config();
			return (bool) $config->get_boolean( 'dbcache.enabled' );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	public static function w3tc_get( string $key ) {
		if ( ! class_exists( '\W3TC\Dispatcher' ) ) {
			return null;
		}
		try {
			return \W3TC\Dispatcher::config()->get( $key );
		} catch ( \Throwable $e ) {
			return null;
		}
	}


	public static function after_change( int $post_id = 0 ): array {
		if ( ! NAS_Settings::get( 'auto_purge' ) ) {
			return array();
		}
		return self::purge( $post_id );
	}

	public static function after_elementor_save( $post_id ): void {
		if ( NAS_Settings::get( 'auto_purge' ) ) {
			$post_id = (int) $post_id;
			$type    = get_post_type( $post_id );

			$global = in_array( $type, array( 'chf_template', 'elementor_library' ), true );
			self::purge( $global ? 0 : $post_id );
		}
	}



	public static function admin_bar( $bar ): void {
		if ( ! is_admin_bar_showing() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$back = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$url  = wp_nonce_url( admin_url( 'admin-post.php?action=nas_purge&back=' . rawurlencode( $back ) ), 'nas_purge' );
		$bar->add_node(
			array(
				'id'    => 'nas-purge',
				'title' => 'Navia: clear caches',
				'href'  => $url,
				'meta'  => array( 'title' => 'Page cache, database cache, Elementor CSS and Rank Math sitemap' ),
			)
		);
	}

	public static function handle_purge(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_purge' );
		$done = self::purge( 0 );
		set_transient( 'nas_notice_' . get_current_user_id(), 'Caches cleared: ' . ( $done ? implode( ', ', $done ) : 'no cache plugin found' ) . '.', 60 );
		$back = isset( $_GET['back'] ) ? esc_url_raw( wp_unslash( $_GET['back'] ) ) : '';
		wp_safe_redirect( $back ? $back : admin_url( 'admin.php?page=' . NAS_Admin::MENU ) );
		exit;
	}
}
