<?php








defined( 'ABSPATH' ) || exit;

class NAS_Checks {

	public static function run(): array {
		$c = array();
		self::platform( $c );
		self::stack( $c );
		self::elementor( $c );
		self::cache( $c );
		self::fonts_images( $c );
		self::email_forms( $c );
		self::seo( $c );
		self::automation( $c );
		return $c;
	}

	public static function counts( array $checks ): array {
		$n = array( 'ok' => 0, 'warn' => 0, 'fail' => 0, 'info' => 0 );
		foreach ( $checks as $ch ) {
			++$n[ $ch['status'] ];
		}
		return $n;
	}

	private static function add( array &$c, string $id, string $group, string $label, string $status, string $detail = '', string $fix = '', string $action = '' ): void {
		$c[] = compact( 'id', 'group', 'label', 'status', 'detail', 'fix', 'action' );
	}



	private static function platform( array &$c ): void {
		global $wp_version;
		$mcp_on = NAS_Settings::module_on( 'articles' ) || NAS_Settings::module_on( 'elementor_mcp' ) || NAS_Settings::module_on( 'suite_mcp' );
		if ( version_compare( $wp_version, '6.9', '<' ) ) {
			self::add( $c, 'wp_version', 'Platform', 'WordPress 6.9 or later', $mcp_on ? 'fail' : 'warn', 'This site runs WordPress ' . $wp_version . '. The MCP modules need the Abilities API (core since 6.9).', 'Update WordPress.' );
		} else {
			self::add( $c, 'wp_version', 'Platform', 'WordPress 6.9 or later', 'ok', 'WordPress ' . $wp_version . '.' );
		}
		self::add( $c, 'php', 'Platform', 'PHP 8.1 or later', version_compare( PHP_VERSION, '8.1', '>=' ) ? 'ok' : 'fail', 'PHP ' . PHP_VERSION . '.' );

		$tz = (string) get_option( 'timezone_string' );
		if ( '' === $tz ) {
			self::add( $c, 'timezone', 'Platform', 'Timezone set by city', 'warn', 'The timezone is a fixed UTC offset, which ignores summer time. Scheduled posts land an hour off half of the year.', 'Settings > General > Timezone: choose a city (Lisbon for Portugal).' );
		} else {
			self::add( $c, 'timezone', 'Platform', 'Timezone set by city', 'ok', $tz . '.' );
		}

		$structure = (string) get_option( 'permalink_structure' );
		self::add( $c, 'permalinks', 'Platform', 'Pretty permalinks', $structure ? 'ok' : 'fail', $structure ? $structure : 'Plain permalinks (?p=123).', 'Settings > Permalinks: Post name.' );

		$overdue = self::overdue_cron();
		$disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		if ( $overdue > 0 ) {
			self::add( $c, 'cron', 'Platform', 'Scheduled tasks run on time', 'warn', $overdue . ' scheduled task(s) are more than 15 minutes late. With a page cache, visits no longer reach WordPress, so its cron stalls and posts end in "missed schedule".', 'Add a real cron job every 5 minutes in cPanel (wp cron event run --due-now, or a curl to wp-cron.php for each site) and then define DISABLE_WP_CRON as true in wp-config.php.' );
		} else {
			self::add( $c, 'cron', 'Platform', 'Scheduled tasks run on time', $disabled ? 'ok' : 'info', $disabled ? 'DISABLE_WP_CRON is on and no task is late, so a real cron is running.' : 'No task is late now. WordPress cron still depends on visits.', $disabled ? '' : 'Before scheduling articles, set a real cron in cPanel and DISABLE_WP_CRON in wp-config.php.' );
		}

		if ( ! get_option( 'blog_public' ) ) {
			self::add( $c, 'blog_public', 'Platform', 'Visible to search engines', 'warn', '"Discourage search engines" is ticked. Fine while building, wrong at launch.', 'Settings > Reading: untick it at launch.' );
		}
	}

	private static function overdue_cron(): int {
		$crons = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
		$late  = 0;
		$limit = time() - 15 * MINUTE_IN_SECONDS;
		foreach ( (array) $crons as $ts => $hooks ) {
			if ( (int) $ts < $limit ) {
				$late += count( (array) $hooks );
			}
		}
		return $late;
	}



	private static function stack( array &$c ): void {
		foreach ( NAS_Env::stack_status() as $key => $s ) {
			if ( 'elementor_pro' === $key ) {
				continue;
			}
			if ( $s['active'] ) {
				$status = 'ok';
				$detail = $s['version'] ? 'Version ' . $s['version'] . '.' : 'Active.';
			} elseif ( $s['installed'] ) {
				$status = $s['required'] ? 'warn' : 'info';
				$detail = 'Installed but not active on this site.';
			} else {
				$status = $s['required'] ? 'warn' : 'info';
				$detail = 'Not installed.';
			}
			self::add( $c, 'plugin_' . $key, 'Stack', $s['label'], $status, $detail . ' ' . $s['role'] . '.', $s['active'] ? '' : 'Install and activate it (the Navia Suite Installer will do this in one click).' );
		}


		if ( is_multisite() && NAS_Env::active( 'webp_converter' ) && ! NAS_Env::network_activated( NAS_Env::STACK['webp_converter']['file'] ) ) {
			self::add( $c, 'webpc_network', 'Stack', 'Converter for Media network activated', 'warn', 'Activated per site, it does not find the uploads/sites/N folders of each subsite.', 'Network Admin > Plugins: Network Activate Converter for Media.' );
		}

		foreach ( NAS_Env::conflicts() as $file => $why ) {
			self::add( $c, 'conflict_' . sanitize_key( $file ), 'Stack', 'Conflict: ' . dirname( $file ), 'fail', $why . '.', 'Deactivate it. Settings and content of the old Navia plugins are read by the Suite as they are.' );
		}

		if ( NAS_Env::active( 'updraftplus' ) ) {
			$interval = (string) get_option( 'updraft_interval', 'manual' );
			self::add( $c, 'updraft_schedule', 'Stack', 'Backups scheduled', 'manual' === $interval ? 'warn' : 'ok', 'Files: ' . $interval . ', database: ' . get_option( 'updraft_interval_database', 'manual' ) . '.', 'manual' === $interval ? 'UpdraftPlus > Settings: weekly files, daily database, remote storage (Google Drive).' : '' );
		}
	}



	private static function elementor( array &$c ): void {
		if ( ! NAS_Env::elementor() ) {
			return;
		}
		self::add( $c, 'hello_theme', 'Elementor', 'Hello Elementor theme', NAS_Env::hello_theme() ? 'ok' : 'info', 'Theme: ' . get_template() . '.', NAS_Env::hello_theme() ? '' : 'The Theme Builder module also works with other themes, but Hello is the tested one.' );

		if ( NAS_Env::elementor_pro() && NAS_Settings::module_on( 'theme_builder' ) ) {
			self::add( $c, 'pro_theme_builder', 'Elementor', 'One theme builder only', 'warn', 'Elementor Pro is active and the Suite Theme Builder module is on.', 'Navia Suite > Modules: switch Theme Builder off, or do not use the Pro theme builder.' );
		}

		$want = self::elementor_perf_targets();
		$bad  = array();
		foreach ( $want as $opt => $val ) {
			$cur = (string) get_option( $opt, '' );
			if ( $cur !== $val ) {
				$bad[] = str_replace( 'elementor_', '', $opt ) . ' = ' . ( '' === $cur ? 'default' : $cur );
			}
		}
		self::add( $c, 'elementor_perf', 'Elementor', 'Elementor performance settings', $bad ? 'warn' : 'ok', $bad ? 'Different from the tested set: ' . implode( ', ', $bad ) . '.' : 'CSS embedded, optimised image and Gutenberg loading, background lazy load on, element cache one week, fonts with swap.', $bad ? 'One click applies the set that gave 90+ on mobile. Lazy load of background images must stay on.' : '', $bad ? 'elementor_perf' : '' );

		$roboto = self::kit_uses_roboto();
		if ( $roboto ) {
			self::add( $c, 'kit_roboto', 'Elementor', 'Global fonts are the brand fonts', 'warn', 'The kit still uses ' . $roboto . ' (Elementor default) in global fonts or theme style.', 'Set the Global Fonts and Theme Style typography to the brand fonts (navia-el/update-kit does it), then run the font plan.' );
		}

		$samples = self::sample_content();
		if ( $samples ) {
			self::add( $c, 'sample_content', 'Elementor', 'No sample content', 'warn', 'Still here: ' . implode( ', ', $samples ) . '. It shows as duplicate content across sites.', 'Move them to the trash.', 'trash_samples' );
		}
	}

	public static function elementor_perf_targets(): array {
		return array(
			'elementor_css_print_method'            => 'internal',
			'elementor_optimized_image_loading'     => '1',
			'elementor_optimized_gutenberg_loading' => '1',
			'elementor_lazy_load_background_images' => '1',
			'elementor_element_cache_ttl'           => '168',
			'elementor_font_display'                => 'swap',
		);
	}

	private static function kit_uses_roboto(): string {
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( ! $kit ) {
			return '';
		}
		$s = get_post_meta( $kit, '_elementor_page_settings', true );
		if ( ! is_array( $s ) ) {
			return '';
		}
		$json = wp_json_encode( array( $s['system_typography'] ?? array(), $s['body_typography_font_family'] ?? '' ) );
		foreach ( array( 'Roboto Slab', 'Roboto' ) as $f ) {
			if ( false !== stripos( (string) $json, '"' . $f . '"' ) ) {
				return $f;
			}
		}
		return '';
	}

	public static function sample_content(): array {
		$found = array();
		$hello = get_posts( array( 'name' => 'hello-world', 'post_type' => 'post', 'post_status' => 'any', 'numberposts' => 1 ) );
		if ( $hello ) {
			$found['post'] = (int) $hello[0]->ID;
		}
		$sample = get_posts( array( 'name' => 'sample-page', 'post_type' => 'page', 'post_status' => 'any', 'numberposts' => 1 ) );
		if ( $sample ) {
			$found['page'] = (int) $sample[0]->ID;
		}
		return array_map(
			static function ( $id ) {
				return '"' . get_the_title( $id ) . '" (' . $id . ')';
			},
			$found
		);
	}



	private static function cache( array &$c ): void {
		if ( ! NAS_Env::active( 'w3tc' ) ) {
			return;
		}
		$page = NAS_Cache::w3tc_get( 'pgcache.enabled' );
		$db   = NAS_Cache::w3tc_get( 'dbcache.enabled' );
		$min  = NAS_Cache::w3tc_get( 'minify.enabled' );
		$br   = NAS_Cache::w3tc_get( 'browsercache.enabled' );
		if ( null === $page ) {
			return;
		}
		self::add( $c, 'w3tc_page', 'Cache', 'W3TC page cache on', $page ? 'ok' : 'warn', $page ? 'On.' : 'Off.', $page ? '' : 'Performance > General Settings > Page Cache: on (disk enhanced).' );
		self::add( $c, 'w3tc_browser', 'Cache', 'W3TC browser cache on', $br ? 'ok' : 'warn', $br ? 'On.' : 'Off.', $br ? '' : 'Performance > General Settings > Browser Cache: on.' );
		self::add( $c, 'w3tc_db', 'Cache', 'W3TC database cache off', $db ? 'warn' : 'ok', $db ? 'On. During test B5 it returned old Rank Math meta for minutes and it can hide the cron list, which leaves posts in "missed schedule". On shared hosting it is usually slower than MariaDB.' : 'Off.', $db ? 'Performance > General Settings > Database Cache: off, then Empty all caches.' : '' );
		$perf_defers = function_exists( 'ts_perf_get' ) && ( ts_perf_get( 'defer_css' ) || ts_perf_get( 'delay_js' ) || ts_perf_get( 'defer_scripts' ) );
		if ( $min ) {
			self::add( $c, 'w3tc_minify', 'Cache', 'W3TC minify off', $perf_defers ? 'fail' : 'warn', 'Minify is on. The Performance module handles CSS and JS; two plugins doing the same work broke pages on the network.', 'Performance > General Settings > Minify: off. Let W3TC do page and browser cache only.' );
		}
	}



	private static function fonts_images( array &$c ): void {
		if ( NAS_Env::active( 'omgf' ) ) {
			$s       = get_option( 'omgf_settings', array() );
			$subsets = isset( $s['subsets'] ) ? (array) $s['subsets'] : array( 'latin', 'latin-ext' );
			$display = $s['display_option'] ?? 'swap';
			$unload  = get_option( 'omgf_unload_fonts', array() );
			$fonts   = get_option( 'omgf_optimized_fonts', array() );
			if ( empty( $fonts ) ) {
				self::add( $c, 'omgf_detected', 'Fonts', 'OMGF detected the fonts', 'warn', 'OMGF has no fonts yet.', 'Settings > Optimize Google Fonts > Save & Optimize, then open the homepage two or three times in a private window.' );
			} else {
				$has_unload = is_array( $unload ) && array_filter( $unload );
				self::add( $c, 'omgf_unload', 'Fonts', 'Only the fonts in use', $has_unload ? 'ok' : 'warn', $has_unload ? 'Unused fonts are unloaded.' : 'Every detected weight is loaded, usually Roboto and Roboto Slab too.', $has_unload ? '' : 'Navia Suite > Stack > Fonts: build the plan from the Elementor site and apply it.' );
			}
			self::add( $c, 'omgf_subsets', 'Fonts', 'Latin subset only', array( 'latin' ) === array_values( $subsets ) ? 'ok' : 'info', 'Subsets: ' . implode( ', ', $subsets ) . '. Portuguese fits in latin (ã, ç, õ).', '' );
			self::add( $c, 'omgf_display', 'Fonts', 'font-display swap', 'swap' === $display ? 'ok' : 'warn', 'Value: ' . $display . '.', 'swap' === $display ? '' : 'OMGF > Local Fonts > Font-Display: Swap.' );
		}
	}



	private static function email_forms( array &$c ): void {
		if ( NAS_Env::active( 'post_smtp' ) ) {
			$o    = get_option( 'postman_options', array() );
			$ok   = is_array( $o ) && 'smtp' === ( $o['transport_type'] ?? '' ) && ! empty( $o['hostname'] ) && ! empty( $o['basic_auth_username'] );
			$last = (string) ( NAS_Settings::get( 'smtp' )['last_test_result'] ?? '' );
			self::add( $c, 'smtp_config', 'Email', 'Post SMTP uses the site mailbox', $ok ? 'ok' : 'warn', $ok ? $o['basic_auth_username'] . ' at ' . $o['hostname'] . ':' . ( $o['port'] ?? '' ) . '.' : 'Not configured. PHP mail() on shared cPanel hosting lands in spam.', $ok ? '' : 'Navia Suite > Stack > Email: mailbox created in cPanel, then the test email.' );
			if ( $ok ) {
				self::add( $c, 'smtp_test', 'Email', 'Test email delivered', 'ok' === $last ? 'ok' : 'info', $last ? 'Last test: ' . $last . '.' : 'No test sent from the Suite yet.', 'ok' === $last ? '' : 'Send the test email from Navia Suite > Stack > Email.' );
			}
		}

		if ( NAS_Env::active( 'cf7' ) ) {
			$forms = get_posts( array( 'post_type' => 'wpcf7_contact_form', 'numberposts' => 50, 'post_status' => 'any' ) );
			if ( ! $forms ) {
				self::add( $c, 'cf7_forms', 'Forms', 'Contact form created', 'warn', 'No Contact Form 7 form.', 'Navia Suite > Stack > Forms: create the lead form for each language.' );
			}
			foreach ( $forms as $f ) {
				$mail = get_post_meta( $f->ID, '_mail', true );
				$to   = is_array( $mail ) ? (string) ( $mail['recipient'] ?? '' ) : '';
				if ( '' === $to || false !== strpos( $to, '[_site_admin_email]' ) ) {
					self::add( $c, 'cf7_to_' . $f->ID, 'Forms', 'Form "' . $f->post_title . '" goes to the client', 'warn', 'Recipient: ' . ( $to ? $to : 'empty' ) . ' (the WordPress admin address, not the client).', 'Navia Suite > Stack > Forms, or Contact > the form > Mail > To.' );
				}
			}
			$keys = class_exists( 'WPCF7' ) ? (array) WPCF7::get_option( 'recaptcha' ) : array();
			self::add( $c, 'cf7_recaptcha', 'Forms', 'reCAPTCHA keys in Contact Form 7', array_filter( $keys ) ? 'ok' : 'warn', array_filter( $keys ) ? 'Keys set.' : 'No keys: forms are open to spam.', array_filter( $keys ) ? '' : 'Navia Suite > Stack > Forms: paste the reCAPTCHA v3 site key and secret.' );
			if ( ! NAS_Env::active( 'flamingo' ) ) {
				self::add( $c, 'flamingo', 'Forms', 'Leads kept in the database', 'info', 'Without Flamingo a lead is only an email. If the email fails the lead is gone.', 'Install Flamingo (free, same author as CF7).' );
			}
		}

		if ( NAS_Env::active( 'cookie_notice' ) ) {
			$o = get_option( 'cookie_notice_options', array() );
			$msg = is_array( $o ) ? (string) ( $o['message_text'] ?? '' ) : '';
			$cookie_texts = NAS_Settings::get( 'cookies' )['texts'] ?? array();
			self::add( $c, 'cookie_notice', 'Forms', 'Cookie bar configured', ( $msg || $cookie_texts ) ? 'ok' : 'warn', ( $msg || $cookie_texts ) ? 'Configured.' : 'Default texts and colours.', ( $msg || $cookie_texts ) ? '' : 'Navia Suite > Stack > Cookies.' );
		}
	}



	private static function seo( array &$c ): void {
		if ( NAS_Env::active( 'rank_math' ) ) {
			self::add( $c, 'mcp_endpoint', 'SEO', 'MCP endpoint for the Claude connector', 'info', NAS_Env::mcp_endpoint(), 'Claude > Settings > Connectors > Add custom connector, with this URL. On a network every subsite is its own connector.' );
		}
		if ( function_exists( 'pll_languages_list' ) ) {
			$langs = (array) pll_languages_list( array( 'fields' => 'locale' ) );
			self::add( $c, 'languages', 'SEO', 'Polylang languages', $langs ? 'ok' : 'warn', $langs ? implode( ', ', $langs ) : 'No language yet.', $langs ? '' : 'navia-el/setup-languages creates them (for example en_GB main and pt_PT in /pt/).' );
		}
		$hy = NAS_Settings::get( 'hygiene' );
		if ( NAS_Settings::module_on( 'hygiene' ) && empty( $hy['feed_links_extra'] ) ) {
			self::add( $c, 'feeds', 'SEO', 'No feed per post and per tag', 'info', 'Google crawls dozens of /feed/ URLs and lists them as crawled, not indexed.', 'Navia Suite > Stack > SEO hygiene.', 'hygiene_on' );
		}
		if ( NAS_Env::active( 'rank_math' ) && class_exists( 'RankMath\\Helper' ) ) {
			$robots = (array) \RankMath\Helper::get_settings( 'titles.tax_post_tag_robots', array() );
			$custom = \RankMath\Helper::get_settings( 'titles.tax_post_tag_custom_robots' );
			if ( ! $custom || ! in_array( 'noindex', $robots, true ) ) {
				self::add( $c, 'tags_noindex', 'SEO', 'Tag archives noindex', 'info', 'Tags with one or two posts are thin, repeated pages.', 'Rank Math > Titles & Meta > Tags: custom robots, noindex (rank-math/set-post-type-seo-settings does it over MCP).' );
			}
		}
	}



	private static function automation( array &$c ): void {
		$u = NAS_Settings::automation_user();
		if ( ! $u ) {
			self::add( $c, 'automation_user', 'Automation', 'Automation user chosen', 'info', 'No automation user chosen for this site.', 'Navia Suite > Dashboard: choose the account the AI agent connects with (an administrator of this site, never a super admin).' );
			return;
		}
		$admin = user_can( $u, 'manage_options' );
		$super = is_multisite() && is_super_admin( $u->ID );
		$status = $admin && ! $super ? 'ok' : ( $super ? 'warn' : 'fail' );
		$detail = $u->user_login . ': ' . ( $super ? 'super admin of the network (too much power for an agent)' : ( $admin ? 'administrator of this site' : 'not an administrator of this site' ) ) . '.';
		self::add( $c, 'automation_user', 'Automation', 'Automation user', $status, $detail, $admin && ! $super ? '' : 'Give the account the Administrator role on this site only.' );
		if ( is_multisite() && $admin && ! user_can( $u, 'unfiltered_html' ) ) {
			self::add( $c, 'unfiltered_html', 'Automation', 'HTML widgets without scripts', 'info', 'On a network a site administrator has no unfiltered_html, so HTML widgets cannot carry script, style, form, iframe or svg. Expected: the Elementor module refuses those before WordPress strips them.', '' );
		}
	}



	public static function apply_fix( string $action ): string {
		switch ( $action ) {
			case 'elementor_perf':
				foreach ( self::elementor_perf_targets() as $opt => $val ) {
					update_option( $opt, $val );
				}
				NAS_Cache::purge( 0 );
				return 'Elementor performance settings applied and caches cleared.';
			case 'trash_samples':
				$n = 0;
				foreach ( array( array( 'hello-world', 'post' ), array( 'sample-page', 'page' ) ) as $pair ) {
					$p = get_posts( array( 'name' => $pair[0], 'post_type' => $pair[1], 'post_status' => 'any', 'numberposts' => 1 ) );
					if ( $p && wp_trash_post( $p[0]->ID ) ) {
						++$n;
					}
				}
				return $n . ' sample item(s) moved to the trash.';
			case 'hygiene_on':
				$h                     = NAS_Settings::get( 'hygiene' );
				$h['feed_links_extra'] = true;
				NAS_Settings::save_site( array( 'hygiene' => $h ) );
				return 'Feed links per post and per tag removed.';
		}
		return '';
	}
}
