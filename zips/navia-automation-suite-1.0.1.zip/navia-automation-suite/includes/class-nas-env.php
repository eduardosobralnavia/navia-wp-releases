<?php










defined( 'ABSPATH' ) || exit;

class NAS_Env {




	const STACK = array(
		'elementor'          => array( 'label' => 'Elementor', 'file' => 'elementor/elementor.php', 'check' => 'ELEMENTOR_VERSION', 'role' => 'Page builder (Free by default)', 'required' => true ),
		'elementor_pro'      => array( 'label' => 'Elementor Pro', 'file' => 'elementor-pro/elementor-pro.php', 'check' => 'ELEMENTOR_PRO_VERSION', 'role' => 'Only on some client sites. Turns the Theme Builder module off by default', 'required' => false ),
		'rank_math'          => array( 'label' => 'Rank Math SEO', 'file' => 'seo-by-rank-math/rank-math.php', 'check' => 'RANK_MATH_VERSION', 'role' => 'SEO, sitemap, schema, and the MCP OAuth server the Claude connector uses', 'required' => true ),
		'polylang'           => array( 'label' => 'Polylang', 'file' => 'polylang/polylang.php', 'check' => 'POLYLANG_VERSION', 'role' => 'Translations (Free)', 'required' => true ),
		'polylang_elementor' => array( 'label' => 'Connect Polylang for Elementor', 'file' => 'connect-polylang-elementor/connect-polylang-elementor.php', 'check' => 'class:ConnectPolylangElementor\\Plugin', 'role' => 'Elementor templates and language switcher with Polylang', 'required' => true ),
		'w3tc'               => array( 'label' => 'W3 Total Cache', 'file' => 'w3-total-cache/w3-total-cache.php', 'check' => 'W3TC', 'role' => 'Page cache and browser cache only', 'required' => true ),
		'webp_converter'     => array( 'label' => 'Converter for Media', 'file' => 'webp-converter-for-media/webp-converter-for-media.php', 'check' => 'WEBPC_VERSION', 'role' => 'WebP served behind the original image URLs', 'required' => true ),
		'omgf'               => array( 'label' => 'OMGF', 'file' => 'host-webfonts-local/host-webfonts-local.php', 'check' => 'OMGF_PLUGIN_FILE', 'role' => 'Google Fonts hosted locally, only the fonts in use', 'required' => true ),
		'cf7'                => array( 'label' => 'Contact Form 7', 'file' => 'contact-form-7/wp-contact-form-7.php', 'check' => 'WPCF7_VERSION', 'role' => 'Contact forms', 'required' => true ),
		'flamingo'           => array( 'label' => 'Flamingo', 'file' => 'flamingo/flamingo.php', 'check' => 'FLAMINGO_VERSION', 'role' => 'Keeps every CF7 submission in the database, so a lead survives a failed email', 'required' => false ),
		'post_smtp'          => array( 'label' => 'Post SMTP', 'file' => 'post-smtp/postman-smtp.php', 'check' => 'POST_SMTP_BASE', 'role' => 'Sends email through the cPanel mailbox of the site', 'required' => true ),
		'cookie_notice'      => array( 'label' => 'Cookie Notice', 'file' => 'cookie-notice/cookie-notice.php', 'check' => 'class:Cookie_Notice', 'role' => 'Cookie bar', 'required' => true ),
		'updraftplus'        => array( 'label' => 'UpdraftPlus', 'file' => 'updraftplus/updraftplus.php', 'check' => 'class:UpdraftPlus', 'role' => 'Backups', 'required' => true ),
		'wordfence'          => array( 'label' => 'Wordfence', 'file' => 'wordfence/wordfence.php', 'check' => 'WORDFENCE_VERSION', 'role' => 'Security', 'required' => true ),
	);


	const CONFLICTS = array(
		'header-footer-elementor/header-footer-elementor.php' => 'Elementor Header & Footer Builder: the Theme Builder module already does this',
		'amp/amp.php'                                         => 'AMP: the /amp/ versions lose the templates, the table styles and the index. Google no longer needs AMP',
		'wp-super-cache/wp-cache.php'                         => 'WP Super Cache together with W3 Total Cache: two page caches',
		'litespeed-cache/litespeed-cache.php'                 => 'LiteSpeed Cache together with W3 Total Cache: two page caches (choose one per server)',
		'autoptimize/autoptimize.php'                         => 'Autoptimize: competes with the Performance module for CSS and JS',
		'custom-hf-elementor/custom-hf-elementor.php'         => 'Custom Header & Footer for Elementor: now inside the Suite (Theme Builder and Widgets modules)',
		'navia-wp-mcp/navia-wp-mcp.php'                       => 'Navia WP MCP: now inside the Suite (Articles module)',
		'navia-elementor-mcp/navia-elementor-mcp.php'         => 'Navia Elementor MCP: now inside the Suite (Elementor MCP module)',
		'ts-performance-fixes/ts-performance-fixes.php'       => 'TS Performance: now inside the Suite (Performance module)',
	);

	private static $network_active = null;

	public static function basename(): string {
		return plugin_basename( NAS_FILE );
	}

	public static function network_active(): bool {
		if ( null === self::$network_active ) {
			if ( ! is_multisite() ) {
				self::$network_active = false;
			} else {
				$sitewide             = (array) get_site_option( 'active_sitewide_plugins', array() );
				self::$network_active = isset( $sitewide[ self::basename() ] );
			}
		}
		return self::$network_active;
	}


	public static function network_mode(): bool {
		return is_multisite() && self::network_active();
	}

	public static function mode(): string {
		if ( ! is_multisite() ) {
			return 'single';
		}
		return self::network_active() ? 'network' : 'subsite';
	}

	public static function mode_label(): string {
		switch ( self::mode() ) {
			case 'network':
				return 'Multisite network (Suite network activated)';
			case 'subsite':
				return 'Multisite, Suite activated on this site only (works as a single site)';
			default:
				return 'Single site';
		}
	}









	public static function module_site_enabled( string $module, array $legacy = array(), ?int $blog_id = null ): bool {
		unset( $legacy );
		return NAS_Settings::module_on( $module, $blog_id );
	}



	public static function check_passes( string $check ): bool {
		if ( 0 === strpos( $check, 'class:' ) ) {
			return class_exists( substr( $check, 6 ) );
		}
		if ( 0 === strpos( $check, 'function:' ) ) {
			return function_exists( substr( $check, 9 ) );
		}
		return defined( $check );
	}

	public static function installed( string $file ): bool {
		return file_exists( WP_PLUGIN_DIR . '/' . $file );
	}


	public static function active( string $key ): bool {
		if ( ! isset( self::STACK[ $key ] ) ) {
			return false;
		}
		if ( self::check_passes( self::STACK[ $key ]['check'] ) ) {
			return true;
		}
		$file = self::STACK[ $key ]['file'];
		if ( in_array( $file, (array) get_option( 'active_plugins', array() ), true ) ) {
			return true;
		}
		if ( is_multisite() ) {
			$sitewide = (array) get_site_option( 'active_sitewide_plugins', array() );
			return isset( $sitewide[ $file ] );
		}
		return false;
	}

	public static function network_activated( string $file ): bool {
		if ( ! is_multisite() ) {
			return false;
		}
		$sitewide = (array) get_site_option( 'active_sitewide_plugins', array() );
		return isset( $sitewide[ $file ] );
	}

	public static function plugin_version( string $file ): string {
		if ( ! self::installed( $file ) ) {
			return '';
		}
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$data = get_plugin_data( WP_PLUGIN_DIR . '/' . $file, false, false );
		return (string) ( $data['Version'] ?? '' );
	}

	public static function stack_status(): array {
		$out = array();
		foreach ( self::STACK as $key => $p ) {
			$out[ $key ] = array(
				'label'             => $p['label'],
				'role'              => $p['role'],
				'required'          => $p['required'],
				'installed'         => self::installed( $p['file'] ),
				'active'            => self::active( $key ),
				'network_activated' => self::network_activated( $p['file'] ),
				'version'           => self::plugin_version( $p['file'] ),
			);
		}
		return $out;
	}

	public static function conflicts(): array {
		$found = array();
		foreach ( self::CONFLICTS as $file => $why ) {
			$on = in_array( $file, (array) get_option( 'active_plugins', array() ), true ) || self::network_activated( $file );
			if ( $on ) {
				$found[ $file ] = $why;
			}
		}
		return $found;
	}



	public static function elementor(): bool {
		return defined( 'ELEMENTOR_VERSION' ) || did_action( 'elementor/loaded' );
	}

	public static function elementor_pro(): bool {
		return defined( 'ELEMENTOR_PRO_VERSION' ) || self::active( 'elementor_pro' );
	}

	public static function hello_theme(): bool {
		return 'hello-elementor' === get_template();
	}

	public static function abilities_api(): bool {
		return function_exists( 'wp_register_ability' );
	}


	public static function mcp_adapter(): bool {
		return class_exists( '\WP\MCP\Core\McpAdapter' ) || class_exists( 'WP\\MCP\\Plugin' ) || defined( 'WP_MCP_VERSION' ) || self::active( 'rank_math' );
	}

	public static function mcp_endpoint(): string {
		return rest_url( 'mcp/mcp-oauth-server' );
	}




	public static function summary(): array {
		global $wp_version;
		return array(
			'suite_version'   => NAS_VERSION,
			'mode'            => self::mode(),
			'mode_label'      => self::mode_label(),
			'blog_id'         => get_current_blog_id(),
			'site_url'        => home_url( '/' ),
			'wordpress'       => $wp_version,
			'php'             => PHP_VERSION,
			'theme'           => get_template(),
			'hello_elementor' => self::hello_theme(),
			'elementor'       => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '',
			'elementor_pro'   => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : '',
			'abilities_api'   => self::abilities_api(),
			'mcp_endpoint'    => self::mcp_endpoint(),
			'languages'       => function_exists( 'pll_languages_list' ) ? (array) pll_languages_list( array( 'fields' => 'locale' ) ) : array(),
			'default_lang'    => function_exists( 'pll_default_language' ) ? (string) pll_default_language( 'locale' ) : get_locale(),
		);
	}
}
