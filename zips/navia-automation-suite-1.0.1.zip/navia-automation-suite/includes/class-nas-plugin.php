<?php





defined( 'ABSPATH' ) || exit;

class NAS_Plugin {


	private static $own_constants = array();


	private static $loaded = array();


	private static $legacy = array();

	public static function bootstrap(): void {
		add_action( 'plugins_loaded', array( __CLASS__, 'load_modules' ), 1 );
		add_action( 'init', array( 'NAS_Updater', 'maybe_upgrade' ), 1 );
		NAS_Cache::init();
		NAS_Admin::init();
		NAS_Updater::init();
	}

	public static function define( string $name, $value ): void {
		if ( ! defined( $name ) ) {
			define( $name, $value );
			self::$own_constants[ $name ] = true;
		}
	}

	public static function defined_by_suite( string $name ): bool {
		return isset( self::$own_constants[ $name ] );
	}

	public static function loaded(): array {
		return self::$loaded;
	}

	public static function legacy(): array {
		return self::$legacy;
	}

	public static function is_loaded( string $key ): bool {
		return in_array( $key, self::$loaded, true );
	}






	public static function wanted(): array {
		$keys = array();
		foreach ( NAS_Settings::module_keys() as $key ) {
			if ( is_network_admin() || NAS_Settings::module_on( $key ) ) {
				$keys[] = $key;
			}
		}
		return $keys;
	}

	public static function load_modules(): void {
		foreach ( self::wanted() as $key ) {
			if ( NAS_Settings::legacy_active( $key ) ) {
				self::$legacy[] = $key;
				continue;
			}
			if ( ! self::requirements_for_loading( $key ) ) {
				continue;
			}
			self::load( $key );
		}

		if ( NAS_Settings::module_on( 'suite_mcp' ) && NAS_Env::abilities_api() ) {
			NAS_Abilities::init();
		}
	}





	private static function requirements_for_loading( string $key ): bool {
		$needs = NAS_Settings::modules()[ $key ]['needs'] ?? array();
		if ( in_array( 'elementor', $needs, true ) && ! NAS_Env::elementor() ) {
			return false;
		}
		if ( in_array( 'abilities', $needs, true ) && ! NAS_Env::abilities_api() ) {
			return false;
		}
		return true;
	}

	public static function load( string $key ): void {
		if ( in_array( $key, self::$loaded, true ) ) {
			return;
		}
		$map = array(
			'articles'      => 'modules/articles/module.php',
			'elementor_mcp' => 'modules/elementor-mcp/module.php',
			'theme_builder' => 'modules/theme-builder/module.php',
			'widgets'       => 'modules/widgets/module.php',
			'performance'   => 'modules/performance/module.php',
			'forms'         => 'modules/stack/class-nas-forms.php',
			'smtp'          => 'modules/stack/class-nas-smtp.php',
			'cookies'       => 'modules/stack/class-nas-cookies.php',
			'fonts'         => 'modules/stack/class-nas-fonts.php',
			'hygiene'       => 'modules/stack/class-nas-hygiene.php',
			'suite_mcp'     => '',
		);
		if ( empty( $map[ $key ] ) ) {
			self::$loaded[] = $key;
			return;
		}
		require_once NAS_DIR . $map[ $key ];
		self::$loaded[] = $key;
	}



	public static function activate( $network_wide = false ): void {

		foreach ( array( 'articles', 'elementor_mcp', 'theme_builder' ) as $key ) {
			if ( ! NAS_Settings::legacy_active( $key ) && self::requirements_for_loading( $key ) ) {
				self::load( $key );
			}
		}

		if ( class_exists( 'Navia_MCP_Settings' ) ) {
			Navia_MCP_Settings::on_activation( $network_wide );
		}
		if ( class_exists( 'Navia_EL_Unique' ) ) {
			Navia_EL_Unique::install();
		}
		if ( class_exists( 'CHF_Post_Type' ) ) {
			CHF_Post_Type::register_post_type();
		}

		NAS_Updater::record( 'activation', $network_wide ? 'Network activation' : 'Activation' );
		update_option( 'nas_flush_rewrite', 1, false );
	}

	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'navia_mcp_log_cleanup' );
		wp_clear_scheduled_hook( 'navia_mcp_fix_missed' );
		flush_rewrite_rules();
	}
}
