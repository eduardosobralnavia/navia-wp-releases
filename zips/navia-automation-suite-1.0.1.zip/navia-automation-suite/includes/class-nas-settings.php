<?php










defined( 'ABSPATH' ) || exit;

class NAS_Settings {

	const SITE_OPTION    = 'nas_site';
	const NETWORK_OPTION = 'nas_network';





	public static function modules(): array {
		return array(
			'articles'      => array(
				'label'  => 'Articles (MCP)',
				'desc'   => 'navia/ abilities: articles, categories and tags, Rank Math meta, Polylang, generated images (Cloudflare FLUX), scheduling, tables, table of contents switch, verification and audit log. Origin: Navia WP MCP 1.1.1.',
				'needs'  => array( 'abilities' ),
				'legacy' => 'NAVIA_MCP_VERSION',
				'group'  => 'automation',
			),
			'elementor_mcp' => array(
				'label'  => 'Elementor (MCP)',
				'desc'   => 'navia-el/ abilities: pages, kit, headers and footers, menus, translations, revisions, previews, checks, uniqueness and validate-site. Origin: Navia Elementor MCP 1.2.0.',
				'needs'  => array( 'abilities', 'elementor' ),
				'legacy' => 'NAVIA_EL_VERSION',
				'group'  => 'automation',
			),
			'suite_mcp'     => array(
				'label'  => 'Suite tools (MCP)',
				'desc'   => 'navia-suite/ abilities: environment and checks, cache purge, contact form setup, font plan for OMGF, cookie bar setup, update log.',
				'needs'  => array( 'abilities' ),
				'legacy' => '',
				'group'  => 'automation',
			),
			'theme_builder' => array(
				'label'  => 'Theme Builder (Header, Footer, Single Post)',
				'desc'   => 'Header, Footer and blog Single Post templates built with Elementor Free, per language with Polylang. Off by default when Elementor Pro is active. Origin: Custom Header & Footer for Elementor 1.2.',
				'needs'  => array( 'elementor' ),
				'legacy' => 'CHF_VERSION',
				'group'  => 'elementor',
			),
			'widgets'       => array(
				'label'  => 'Navia widgets for Elementor',
				'desc'   => 'Site Menu, Navia Posts (with load more), Loop Grid, Breadcrumbs, Post Title, Post Meta, Featured Image, Table of Contents, Post Content.',
				'needs'  => array( 'elementor' ),
				'legacy' => 'CHF_VERSION',
				'group'  => 'elementor',
			),
			'performance'   => array(
				'label'  => 'Performance',
				'desc'   => 'CLS of images above the fold, LCP preload, critical CSS with deferred styles, JavaScript delayed until interaction, defer of jQuery and Elementor core, delayed containers, CF7 only where a form exists, WordPress cleanup, automatic analysis. Every option starts off. Origin: TS Performance 4.1.',
				'needs'  => array(),
				'legacy' => 'TS_PERF_VERSION',
				'group'  => 'optimisation',
			),
			'forms'         => array(
				'label'  => 'Contact forms (CF7)',
				'desc'   => 'Creates the lead form per language with the right mail settings, styles it with the Elementor global colours and fonts, sets the reCAPTCHA keys.',
				'needs'  => array(),
				'legacy' => '',
				'group'  => 'stack',
			),
			'smtp'          => array(
				'label'  => 'Email (Post SMTP)',
				'desc'   => 'Writes the cPanel mailbox into Post SMTP and sends a test email.',
				'needs'  => array(),
				'legacy' => '',
				'group'  => 'stack',
			),
			'cookies'       => array(
				'label'  => 'Cookie bar (Cookie Notice)',
				'desc'   => 'Texts per language, colours from the Elementor kit, refuse and revoke buttons, privacy policy link per language.',
				'needs'  => array(),
				'legacy' => '',
				'group'  => 'stack',
			),
			'fonts'         => array(
				'label'  => 'Fonts (OMGF)',
				'desc'   => 'Reads the fonts and weights the Elementor site really uses and unloads everything else in OMGF, with preload of the kept weights.',
				'needs'  => array(),
				'legacy' => '',
				'group'  => 'optimisation',
			),
			'hygiene'       => array(
				'label'  => 'SEO hygiene',
				'desc'   => 'Templates out of sitemaps and search results, no per-post feed links, and the small fixes found in Search Console and Bing.',
				'needs'  => array(),
				'legacy' => '',
				'group'  => 'optimisation',
			),
		);
	}

	public static function module_keys(): array {
		return array_keys( self::modules() );
	}




	public static function module_default( string $key ): bool {
		if ( 'theme_builder' === $key ) {
			return NAS_Env::elementor() && ! NAS_Env::elementor_pro();
		}
		if ( in_array( $key, array( 'elementor_mcp', 'widgets' ), true ) ) {
			return NAS_Env::elementor();
		}
		return true;
	}

	public static function site_defaults(): array {
		return array(
			'modules'          => array(),
			'automation_user'  => 0,
			'auto_purge'       => true,
			'hygiene'          => array(
				'feed_links_extra'  => true,
				'templates_noindex' => true,
			),
			'forms'            => array(
				'style'       => 'light',
				'radius'      => 10,
				'button'      => 'pill',
				'forms'       => array(),
			),
			'cookies'          => array(
				'texts'  => array(),
				'colors' => 'kit',
				'bar'    => '',
				'text'   => '',
				'button' => '',
			),
			'smtp'             => array(
				'last_test'        => '',
				'last_test_result' => '',
			),
		);
	}

	public static function network_defaults(): array {
		return array(
			'channel'          => 'stable',
			'manifest_url'     => '',
			'new_site_modules' => array(),
			'migrated'         => false,
		);
	}



	public static function site( ?int $blog_id = null ): array {
		if ( null !== $blog_id && is_multisite() && $blog_id !== get_current_blog_id() ) {
			$saved = get_blog_option( $blog_id, self::SITE_OPTION, array() );
		} else {
			$saved = get_option( self::SITE_OPTION, array() );
		}
		$saved = is_array( $saved ) ? $saved : array();
		$out   = array_replace_recursive( self::site_defaults(), $saved );

		$out['modules'] = isset( $saved['modules'] ) && is_array( $saved['modules'] ) ? $saved['modules'] : array();
		return $out;
	}

	public static function save_site( array $values, ?int $blog_id = null ): void {
		$current = self::site( $blog_id );
		$new     = array_replace_recursive( $current, $values );
		if ( isset( $values['modules'] ) ) {
			$new['modules'] = $values['modules'];
		}
		if ( null !== $blog_id && is_multisite() && $blog_id !== get_current_blog_id() ) {
			update_blog_option( $blog_id, self::SITE_OPTION, $new );
		} else {
			update_option( self::SITE_OPTION, $new, false );
		}
	}

	public static function get( string $key, ?int $blog_id = null ) {
		$s = self::site( $blog_id );
		return $s[ $key ] ?? null;
	}

	public static function module_on( string $key, ?int $blog_id = null ): bool {
		$s = self::site( $blog_id );
		if ( array_key_exists( $key, $s['modules'] ) ) {
			return (bool) $s['modules'][ $key ];
		}
		if ( NAS_Env::network_mode() ) {
			$net = self::network();
			if ( isset( $net['new_site_modules'][ $key ] ) ) {
				return (bool) $net['new_site_modules'][ $key ];
			}
		}
		return self::module_default( $key );
	}


	public static function module_ready( string $key ): bool {
		$m = self::modules()[ $key ] ?? null;
		if ( ! $m ) {
			return false;
		}
		foreach ( $m['needs'] as $need ) {
			if ( 'elementor' === $need && ! NAS_Env::elementor() ) {
				return false;
			}
			if ( 'abilities' === $need && ! NAS_Env::abilities_api() ) {
				return false;
			}
		}
		return true;
	}

	public static function legacy_active( string $key ): bool {
		$m = self::modules()[ $key ] ?? null;
		return $m && $m['legacy'] && defined( $m['legacy'] ) && ! NAS_Plugin::defined_by_suite( $m['legacy'] );
	}



	public static function network(): array {
		$saved = is_multisite() ? get_site_option( self::NETWORK_OPTION, array() ) : get_option( self::NETWORK_OPTION, array() );
		return array_replace( self::network_defaults(), is_array( $saved ) ? $saved : array() );
	}

	public static function save_network( array $values ): void {
		$new = array_replace( self::network(), $values );
		if ( is_multisite() ) {
			update_site_option( self::NETWORK_OPTION, $new );
		} else {
			update_option( self::NETWORK_OPTION, $new, false );
		}
	}





	public static function set_module_sites( string $module, array $blog_ids ): void {
		$blog_ids = array_map( 'intval', $blog_ids );
		foreach ( get_sites( array( 'fields' => 'ids', 'number' => 1000 ) ) as $bid ) {
			$s                       = self::site( (int) $bid );
			$s['modules'][ $module ] = in_array( (int) $bid, $blog_ids, true );
			self::save_site( array( 'modules' => $s['modules'] ), (int) $bid );
		}
	}


	public static function automation_user(): ?WP_User {
		$id = (int) self::get( 'automation_user' );
		if ( ! $id ) {
			return null;
		}
		$u = get_userdata( $id );
		return $u ? $u : null;
	}
}
