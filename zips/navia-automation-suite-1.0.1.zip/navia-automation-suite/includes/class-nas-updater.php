<?php












defined( 'ABSPATH' ) || exit;

class NAS_Updater {

	const VERSION_OPTION = 'nas_version';


	const RELEASES_RAW = 'https://raw.githubusercontent.com/eduardosobralnavia/navia-wp-releases/main/';
	const RELEASES_URL = 'https://github.com/eduardosobralnavia/navia-wp-releases';
	const CHANNELS     = array( 'stable', 'beta', 'off' );
	const LOG_OPTION     = 'nas_update_log';
	const LOG_MAX        = 300;

	public static function init(): void {
		add_filter( 'update_plugins_github.com', array( __CLASS__, 'check_update' ), 10, 4 );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'after_upgrade' ), 10, 2 );
	}



	private static function get_store( string $key, $default ) {
		return is_multisite() ? get_site_option( $key, $default ) : get_option( $key, $default );
	}

	private static function set_store( string $key, $value ): void {
		if ( is_multisite() ) {
			update_site_option( $key, $value );
		} else {
			update_option( $key, $value, false );
		}
	}

	public static function log(): array {
		$log = self::get_store( self::LOG_OPTION, array() );
		return is_array( $log ) ? $log : array();
	}

	public static function record( string $type, string $summary, array $details = array() ): void {
		$log   = self::log();
		$user  = wp_get_current_user();
		$log[] = array(
			'time'    => gmdate( 'Y-m-d H:i:s' ),
			'type'    => $type,
			'version' => NAS_VERSION,
			'user'    => $user && $user->exists() ? $user->user_login : 'system',
			'site'    => home_url( '/' ),
			'summary' => $summary,
			'details' => $details,
		);
		if ( count( $log ) > self::LOG_MAX ) {
			$log = array_slice( $log, -self::LOG_MAX );
		}
		self::set_store( self::LOG_OPTION, $log );
	}



	public static function maybe_upgrade(): void {
		$installed = (string) self::get_store( self::VERSION_OPTION, '' );
		if ( NAS_VERSION === $installed ) {
			if ( get_option( 'nas_flush_rewrite' ) ) {
				delete_option( 'nas_flush_rewrite' );
				flush_rewrite_rules( false );
			}
			return;
		}

		$steps = array();
		if ( '' === $installed ) {
			$steps = array_merge( $steps, self::migrate_from_standalone() );
		}






		self::set_store( self::VERSION_OPTION, NAS_VERSION );
		update_option( 'nas_flush_rewrite', 1, false );

		self::record(
			'' === $installed ? 'install' : 'upgrade',
			'' === $installed ? 'Installed ' . NAS_VERSION : 'Upgraded from ' . $installed . ' to ' . NAS_VERSION,
			array(
				'from'      => $installed,
				'to'        => NAS_VERSION,
				'steps'     => $steps,
				'changelog' => self::changelog_entry( NAS_VERSION ),
			)
		);
	}






	private static function migrate_from_standalone(): array {
		$steps = array();
		if ( ! NAS_Env::network_mode() ) {
			if ( get_option( 'navia_mcp_site' ) || get_option( 'navia_el_site' ) || get_option( 'ts_perf_settings' ) ) {
				$steps[] = 'Single site: settings of the old Navia plugins are read as they are.';
			}
			return $steps;
		}

		$net = NAS_Settings::network();
		if ( ! empty( $net['migrated'] ) ) {
			return $steps;
		}

		$lists = array(
			'articles'      => get_site_option( 'navia_mcp_network', array() ),
			'elementor_mcp' => get_site_option( 'navia_el_network', array() ),
		);
		$sites = get_sites( array( 'fields' => 'ids', 'number' => 1000 ) );
		foreach ( $lists as $module => $opt ) {
			if ( ! is_array( $opt ) || ! isset( $opt['enabled_sites'] ) ) {
				continue;
			}
			$enabled = array_map( 'intval', (array) $opt['enabled_sites'] );
			foreach ( $sites as $blog_id ) {
				$s                       = NAS_Settings::site( (int) $blog_id );
				$s['modules'][ $module ] = in_array( (int) $blog_id, $enabled, true );
				NAS_Settings::save_site( array( 'modules' => $s['modules'] ), (int) $blog_id );
			}
			$steps[] = sprintf( 'Module %s: enabled on sites %s, as in the old plugin.', $module, $enabled ? implode( ', ', $enabled ) : 'none' );
		}

		NAS_Settings::save_network( array( 'migrated' => true ) );
		return $steps;
	}

	public static function after_upgrade( $upgrader, $options ): void {
		if ( ( $options['type'] ?? '' ) !== 'plugin' || ( $options['action'] ?? '' ) !== 'update' ) {
			return;
		}
		$plugins = (array) ( $options['plugins'] ?? array() );
		if ( in_array( NAS_Env::basename(), $plugins, true ) ) {

			delete_site_transient( self::cache_key() );
		}
	}







	public static function changelog(): string {
		$file = NAS_DIR . 'CHANGELOG.md';
		if ( file_exists( $file ) ) {
			return (string) file_get_contents( $file );
		}
		$m = self::manifest();
		return $m ? (string) ( $m['changelog'] ?? '' ) : '';
	}

	public static function changelog_entry( string $version ): string {
		$all = self::changelog();
		if ( ! preg_match( '/^## ' . preg_quote( $version, '/' ) . '\b.*?(?=^## |\z)/ms', $all, $m ) ) {
			return '';
		}
		return trim( $m[0] );
	}


	public static function export_markdown(): string {
		$env = NAS_Env::summary();
		$out = "# Navia Automation Suite, update log\n\n";
		$out .= '- Site: ' . $env['site_url'] . "\n";
		$out .= '- Suite: ' . NAS_VERSION . ' (' . $env['mode_label'] . '), channel ' . self::channel() . "\n";
		$out .= '- WordPress ' . $env['wordpress'] . ', PHP ' . $env['php'] . ', Elementor ' . ( $env['elementor'] ? $env['elementor'] : 'none' ) . ( $env['elementor_pro'] ? ' + Pro ' . $env['elementor_pro'] : '' ) . "\n";
		$out .= '- Modules loaded: ' . implode( ', ', NAS_Plugin::loaded() ) . "\n";
		if ( NAS_Plugin::legacy() ) {
			$out .= '- Skipped (old plugin still active): ' . implode( ', ', NAS_Plugin::legacy() ) . "\n";
		}
		$out .= "\n## Entries\n\n";
		foreach ( array_reverse( self::log() ) as $e ) {
			$out .= '### ' . $e['time'] . ' UTC, ' . $e['type'] . ', ' . $e['version'] . "\n";
			$out .= $e['summary'] . ' (' . $e['user'] . ")\n";
			if ( ! empty( $e['details']['steps'] ) ) {
				foreach ( (array) $e['details']['steps'] as $s ) {
					$out .= '- ' . $s . "\n";
				}
			}
			$out .= "\n";
		}
		$checks = NAS_Checks::run();
		$out   .= "## Checks now\n\n";
		foreach ( $checks as $ch ) {
			if ( 'ok' !== $ch['status'] ) {
				$out .= '- [' . $ch['status'] . '] ' . $ch['label'] . ': ' . $ch['detail'] . "\n";
			}
		}
		return $out;
	}



	public static function channel(): string {
		$c = (string) ( NAS_Settings::network()['channel'] ?? 'stable' );
		return in_array( $c, self::CHANNELS, true ) ? $c : 'stable';
	}


	public static function manifest_url(): string {
		$custom = (string) NAS_Settings::network()['manifest_url'];
		if ( $custom ) {
			return $custom;
		}
		$channel = self::channel();
		return 'off' === $channel ? '' : self::RELEASES_RAW . $channel . '.json';
	}

	public static function cache_key(): string {
		return 'nas_manifest_' . substr( md5( self::manifest_url() ), 0, 12 );
	}

	public static function flush_manifest(): void {
		delete_site_transient( self::cache_key() );
		delete_site_transient( 'update_plugins' );
	}

	public static function manifest(): ?array {
		$url = self::manifest_url();
		if ( ! $url ) {
			return null;
		}
		$cached = get_site_transient( self::cache_key() );
		if ( is_array( $cached ) ) {
			return $cached ? $cached : null;
		}
		$res = wp_remote_get( add_query_arg( 'nocache', time(), $url ), array( 'timeout' => 10 ) );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			set_site_transient( self::cache_key(), array(), HOUR_IN_SECONDS );
			return null;
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$data = is_array( $data ) && ! empty( $data['version'] ) && ! empty( $data['package'] ) ? $data : array();

		set_site_transient( self::cache_key(), $data, 'beta' === self::channel() ? HOUR_IN_SECONDS : 6 * HOUR_IN_SECONDS );
		return $data ? $data : null;
	}




	public static function check_update( $update, $plugin_data, $plugin_file, $locales ) {
		if ( NAS_Env::basename() !== $plugin_file ) {
			return $update;
		}
		$m = self::manifest();
		if ( ! $m || version_compare( $m['version'], NAS_VERSION, '<=' ) ) {
			return $update;
		}
		$known = (array) self::get_store( 'nas_seen_versions', array() );
		if ( ! in_array( $m['version'], $known, true ) ) {
			$known[] = $m['version'];
			self::set_store( 'nas_seen_versions', $known );
			self::record( 'update-available', 'Version ' . $m['version'] . ' available on the ' . self::channel() . ' channel', array( 'changelog' => (string) ( $m['changelog'] ?? '' ) ) );
		}
		return array(
			'id'           => self::RELEASES_URL,
			'slug'         => 'navia-automation-suite',
			'plugin'       => $plugin_file,
			'version'      => $m['version'],
			'new_version'  => $m['version'],
			'url'          => self::RELEASES_URL,
			'package'      => (string) ( $m['package'] ?? '' ),
			'requires'     => (string) ( $m['requires'] ?? '6.5' ),
			'requires_php' => (string) ( $m['requires_php'] ?? '8.1' ),
			'tested'       => (string) ( $m['tested'] ?? '' ),
		);
	}

	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ( $args->slug ?? '' ) !== 'navia-automation-suite' ) {
			return $result;
		}
		$m = self::manifest();
		return (object) array(
			'name'          => 'Navia Automation Suite',
			'slug'          => 'navia-automation-suite',
			'version'       => $m['version'] ?? NAS_VERSION,
			'author'        => 'Navia Digital',
			'requires'      => $m['requires'] ?? '6.5',
			'requires_php'  => $m['requires_php'] ?? '8.1',
			'download_link' => $m['package'] ?? '',
			'sections'      => array(
				'changelog' => wpautop( esc_html( $m['changelog'] ?? self::changelog() ) ),
			),
		);
	}
}
