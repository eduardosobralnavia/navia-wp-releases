<?php






defined( 'ABSPATH' ) || exit;

class Navia_MCP_Abilities {

	const CATEGORY = 'navia';

	public static function init() {
		add_action( 'wp_abilities_api_categories_init', array( __CLASS__, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( __CLASS__, 'register_all' ) );
	}

	public static function register_category() {
		if ( ! function_exists( 'wp_register_ability_category' ) || ! Navia_MCP_Settings::site_enabled() ) {
			return;
		}
		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => 'Navia Suite: Articles',
				'description' => 'Articles, terms, SEO meta, translations, images, scheduling and verification for this site.',
			)
		);
	}



	private static function schema( array $props, array $required = array() ) {
		$s = array(
			'type'                 => 'object',
			'properties'           => $props,
			'additionalProperties' => false,
		);
		if ( $required ) {
			$s['required'] = $required;
		} else {
			$s['default'] = array();
		}
		return $s;
	}

	private static function reg( $name, $label, $description, $module, $cap, array $schema, $callback, array $annotations = array() ) {
		wp_register_ability(
			'navia/' . $name,
			array(
				'label'               => $label,
				'description'         => $description,
				'category'            => self::CATEGORY,
				'input_schema'        => $schema,
				'execute_callback'    => $callback,
				'permission_callback' => Navia_MCP_Guard::permission( $module, $cap ),
				'meta'                => array(
					'annotations'  => wp_parse_args(
						$annotations,
						array(
							'readonly'    => false,
							'destructive' => false,
							'idempotent'  => false,
						)
					),
					'public'       => true,
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
				),
			)
		);
	}

	private static function ro() {
		return array(
			'readonly'   => true,
			'idempotent' => true,
		);
	}

	public static function register_all() {
		if ( ! function_exists( 'wp_register_ability' ) || ! Navia_MCP_Settings::site_enabled() ) {
			return;
		}

		$int     = array( 'type' => 'integer', 'minimum' => 1 );
		$ints    = array( 'type' => 'array', 'items' => array( 'type' => 'integer', 'minimum' => 1 ) );
		$str     = array( 'type' => 'string' );
		$bool    = array( 'type' => 'boolean' );
		$lang    = array( 'type' => 'string', 'description' => 'Polylang language slug, for example "en" or "pt".' );
		$objtype = array( 'type' => 'string', 'enum' => array( 'post', 'term' ) );
		$seo     = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'title'          => $str,
				'description'    => $str,
				'focus_keyword'  => $str,
				'og_title'       => $str,
				'og_description' => $str,
			),
		);


		self::reg(
			'get-site-context',
			'Get site context',
			'Start here. Returns languages, categories and tags with their translations, authors, the publishing mode, scheduling and image settings, modules, timezone and current time.',
			'',
			'edit_posts',
			self::schema( array() ),
			array( __CLASS__, 'site_context' ),
			self::ro()
		);

		self::reg(
			'get-log',
			'Get audit log',
			'Returns the latest writes made through these abilities on this site.',
			'',
			'edit_posts',
			self::schema(
				array(
					'limit'     => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ),
					'ability'   => $str,
					'object_id' => $int,
				)
			),
			array( __CLASS__, 'get_log' ),
			self::ro()
		);


		self::reg(
			'list-terms',
			'List categories or tags',
			'Lists categories or tags with ID, slug, count, language and translations. Use it before creating any term, to reuse existing ones.',
			'terms',
			'edit_posts',
			self::schema(
				array(
					'taxonomy' => array( 'type' => 'string', 'enum' => array( 'category', 'post_tag' ) ),
					'lang'     => $lang,
					'search'   => $str,
				),
				array( 'taxonomy' )
			),
			array( __CLASS__, 'list_terms' ),
			self::ro()
		);

		self::reg(
			'create-term',
			'Create a category or tag',
			'Creates a category or tag in one language and optionally links it as the translation of an existing term. Refuses duplicates by slug or name in the same language.',
			'terms',
			'manage_categories',
			self::schema(
				array(
					'taxonomy'       => array( 'type' => 'string', 'enum' => array( 'category', 'post_tag' ) ),
					'name'           => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 100 ),
					'slug'           => $str,
					'description'    => $str,
					'lang'           => $lang,
					'translation_of' => $int,
					'parent'         => $int,
				),
				array( 'taxonomy', 'name' )
			),
			array( __CLASS__, 'create_term' )
		);


		self::reg(
			'list-content',
			'List articles',
			'Lists posts with status, dates (local and GMT), language, translations, categories, tags, author and URLs.',
			'content',
			'edit_posts',
			self::schema(
				array(
					'status'   => array( 'type' => 'array', 'items' => array( 'type' => 'string', 'enum' => array( 'publish', 'future', 'draft', 'pending', 'private', 'trash' ) ) ),
					'lang'     => $lang,
					'category' => $int,
					'search'   => $str,
					'per_page' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ),
					'page'     => $int,
				)
			),
			array( __CLASS__, 'list_content' ),
			self::ro()
		);

		self::reg(
			'get-content',
			'Get an article',
			'Returns one post with its HTML content, excerpt, featured image, Rank Math meta, language, translations, index setting and remaining image markers.',
			'content',
			'edit_posts',
			self::schema(
				array(
					'id'              => $int,
					'include_content' => $bool,
				),
				array( 'id' )
			),
			array( __CLASS__, 'get_content' ),
			self::ro()
		);

		self::reg(
			'create-post',
			'Create an article',
			'Creates a post as draft (or pending). Content is HTML without H1. Image markers <!-- navia:img prompt="..." alt="..." --> are kept for generate-post-images. Tables are normalised. Sets language, categories and tags by ID, author, table of contents switch, optional Rank Math meta and translation link. Never publishes.',
			'content',
			'edit_posts',
			self::schema(
				array(
					'title'          => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 200 ),
					'content'        => array( 'type' => 'string', 'minLength' => 1 ),
					'slug'           => $str,
					'excerpt'        => $str,
					'status'         => array( 'type' => 'string', 'enum' => array( 'draft', 'pending' ) ),
					'lang'           => $lang,
					'categories'     => $ints,
					'tags'           => $ints,
					'author'         => $int,
					'featured_media' => $int,
					'toc'            => array( 'type' => 'boolean', 'description' => 'true shows the Navia table of contents on this post, false hides it.' ),
					'translation_of' => array( 'type' => 'integer', 'minimum' => 1, 'description' => 'ID of the post in another language that this one translates.' ),
					'seo'            => $seo,
				),
				array( 'title', 'content' )
			),
			array( __CLASS__, 'create_post' )
		);

		self::reg(
			'update-post',
			'Update an article',
			'Changes any field of a post. status "draft" on a scheduled post unschedules it. Published posts can only be edited, not unpublished, unless the publishing mode is "all". The previous version stays as a revision and in the log.',
			'content',
			'edit_posts',
			self::schema(
				array(
					'id'             => $int,
					'title'          => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 200 ),
					'content'        => array( 'type' => 'string', 'minLength' => 1 ),
					'slug'           => $str,
					'excerpt'        => $str,
					'status'         => array( 'type' => 'string', 'enum' => array( 'draft', 'pending' ) ),
					'categories'     => $ints,
					'tags'           => $ints,
					'author'         => $int,
					'featured_media' => array( 'type' => 'integer', 'minimum' => 0 ),
					'toc'            => $bool,
					'seo'            => $seo,
				),
				array( 'id' )
			),
			array( __CLASS__, 'update_post' )
		);

		self::reg(
			'trash-content',
			'Move an article to the trash',
			'Moves a post to the trash (never deletes permanently). Only posts created through the Navia Suite Articles module, unless the site setting allows any post.',
			'content',
			'delete_posts',
			self::schema( array( 'id' => $int ), array( 'id' ) ),
			array( __CLASS__, 'trash_content' ),
			array( 'destructive' => true )
		);


		self::reg(
			'normalize-tables',
			'Normalise tables in an article',
			'Rewrites the tables of a post with thead, scope, no inline styles, the navia-table class and a scroll wrapper. create-post and update-post already do this.',
			'tables',
			'edit_posts',
			self::schema( array( 'id' => $int ), array( 'id' ) ),
			array( __CLASS__, 'normalize_tables' ),
			array( 'idempotent' => true )
		);


		self::reg(
			'set-seo-meta',
			'Set Rank Math meta',
			'Sets Rank Math title, description, focus keyword (comma separated, first is primary), robots, canonical and social title and description for a post. Warns on title over 60, description over 158, dashes, and focus keyword already used in the same language.',
			'seo',
			'edit_posts',
			self::schema(
				array(
					'id'             => $int,
					'title'          => $str,
					'description'    => $str,
					'focus_keyword'  => $str,
					'robots'         => array( 'type' => 'array', 'items' => array( 'type' => 'string', 'enum' => array( 'index', 'noindex', 'follow', 'nofollow', 'noarchive', 'noimageindex', 'nosnippet' ) ) ),
					'canonical'      => array( 'type' => 'string', 'format' => 'uri' ),
					'og_title'       => $str,
					'og_description' => $str,
				),
				array( 'id' )
			),
			array( __CLASS__, 'set_seo' ),
			array( 'idempotent' => true )
		);

		self::reg(
			'get-seo-meta',
			'Get Rank Math meta',
			'Reads the Rank Math meta of a post.',
			'seo',
			'edit_posts',
			self::schema( array( 'id' => $int ), array( 'id' ) ),
			array( __CLASS__, 'get_seo' ),
			self::ro()
		);


		self::reg(
			'set-language',
			'Set language',
			'Sets the Polylang language of a post or term.',
			'i18n',
			'edit_posts',
			self::schema(
				array(
					'object_type' => $objtype,
					'id'          => $int,
					'lang'        => $lang,
				),
				array( 'object_type', 'id', 'lang' )
			),
			array( __CLASS__, 'set_language' ),
			array( 'idempotent' => true )
		);

		self::reg(
			'link-translations',
			'Link translations',
			'Links posts or terms as translations of each other, for example {"en": 123, "pt": 456}. Each object must already be in the language of its key, or have no language yet.',
			'i18n',
			'edit_posts',
			self::schema(
				array(
					'object_type'  => $objtype,
					'translations' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'integer', 'minimum' => 1 ),
					),
				),
				array( 'object_type', 'translations' )
			),
			array( __CLASS__, 'link_translations' ),
			array( 'idempotent' => true )
		);

		self::reg(
			'get-translations',
			'Get translations',
			'Returns the linked translations of a post or term.',
			'i18n',
			'edit_posts',
			self::schema(
				array(
					'object_type' => $objtype,
					'id'          => $int,
				),
				array( 'object_type', 'id' )
			),
			array( __CLASS__, 'get_translations' ),
			self::ro()
		);


		self::reg(
			'generate-image',
			'Generate one image',
			'Generates one image from a scene description with the site style, saves it as WebP in the media library with alt text, and returns its ID. kind "featured" is 1200x630, "inline" is 1200x800.',
			'images',
			'upload_files',
			self::schema(
				array(
					'prompt'       => array( 'type' => 'string', 'minLength' => 5, 'maxLength' => 1500 ),
					'alt'          => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 250 ),
					'kind'         => array( 'type' => 'string', 'enum' => array( 'featured', 'inline' ) ),
					'filename'     => $str,
					'post_id'      => $int,
					'set_featured' => $bool,
				),
				array( 'prompt', 'alt' )
			),
			array( __CLASS__, 'generate_image' )
		);

		self::reg(
			'generate-post-images',
			'Generate the images of an article',
			'For one post: generates the featured image (featured_prompt and featured_alt, or the first marker) and draws a random number of inline images between min and max (site defaults otherwise). Picks markers after the first H2, never two close together, never next to a table. Replaces the chosen markers and removes the rest. Falls back to library images of the same category, then to fewer images.',
			'images',
			'upload_files',
			self::schema(
				array(
					'post_id'          => $int,
					'min'              => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 8 ),
					'max'              => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 8 ),
					'featured'         => $bool,
					'featured_prompt'  => $str,
					'featured_alt'     => $str,
					'replace_featured' => $bool,
				),
				array( 'post_id' )
			),
			array( __CLASS__, 'generate_post_images' )
		);

		self::reg(
			'get-image-usage',
			'Get image usage',
			'Images generated per provider today and over the last 30 days, the daily limit, and whether the provider is paused.',
			'images',
			'edit_posts',
			self::schema( array() ),
			array( __CLASS__, 'image_usage' ),
			self::ro()
		);


		self::reg(
			'schedule-posts',
			'Schedule articles',
			'Schedules posts in the given order with a random gap of min_days to max_days, a random minute inside the time window, on allowed weekdays (1 Monday to 7 Sunday), in the scheduling timezone, or at an exact date per item. Translations go out translation_offset_minutes after their main post; if not given they are read from Polylang. With allow_past=true (and the site setting on), dates in the past are allowed and those posts are published with that date. Without confirm=true it only returns the plan and a plan_token; calling again with confirm=true and that plan_token applies exactly those dates. Refuses posts that still have image markers or are already published.',
			'schedule',
			'publish_posts',
			self::schema(
				array(
					'items'                      => array(
						'type'     => 'array',
						'minItems' => 1,
						'items'    => array(
							'type'                 => 'object',
							'additionalProperties' => false,
							'required'             => array( 'id' ),
							'properties'           => array(
								'id'           => $int,
								'translations' => $ints,
								'date'         => array( 'type' => 'string', 'description' => 'Optional exact local date and time for this item, "YYYY-MM-DD HH:MM". Translations follow after translation_offset_minutes.' ),
							),
						),
					),
					'start_date'                 => array( 'type' => 'string', 'description' => 'YYYY-MM-DD. Default: tomorrow.' ),
					'min_days'                   => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 30 ),
					'max_days'                   => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 30 ),
					'window_start'               => array( 'type' => 'string', 'description' => 'HH:MM' ),
					'window_end'                 => array( 'type' => 'string', 'description' => 'HH:MM' ),
					'days'                       => array( 'type' => 'array', 'items' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 7 ) ),
					'translation_offset_minutes' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 1440 ),
					'confirm'                    => $bool,
					'plan_token'                 => array( 'type' => 'string', 'description' => 'Token returned by a plan-only call, to apply exactly that plan.' ),
					'allow_past'                 => array( 'type' => 'boolean', 'description' => 'Allow dates in the past (backdating). Posts with a past date are published with that date. Needs "Allow past dates" ticked in the site settings.' ),
				),
				array( 'items' )
			),
			array( __CLASS__, 'schedule_posts' )
		);

		self::reg(
			'get-calendar',
			'Get the publishing calendar',
			'Lists scheduled posts (and posts that missed their schedule) with local and GMT dates, language and translations.',
			'schedule',
			'edit_posts',
			self::schema(
				array(
					'from' => array( 'type' => 'string', 'description' => 'YYYY-MM-DD' ),
					'to'   => array( 'type' => 'string', 'description' => 'YYYY-MM-DD' ),
				)
			),
			array( __CLASS__, 'calendar' ),
			self::ro()
		);

		self::reg(
			'fix-missed-schedule',
			'Publish missed schedules',
			'Publishes posts whose scheduled time passed more than five minutes ago. Also runs every hour.',
			'schedule',
			'publish_posts',
			self::schema( array() ),
			array( __CLASS__, 'fix_missed' ),
			array( 'idempotent' => true )
		);

		self::reg(
			'set-post-dates',
			'Set post dates',
			'Sets the publication date and/or the last modified date of a published or scheduled post, local "YYYY-MM-DD HH:MM" in the scheduling timezone. modified must be after the publication date and not in the future. Rank Math uses the modified date for dateModified and the sitemap lastmod; the page cache and the sitemap cache are cleared. Moving a publication date into the past needs "Allow past dates" in the settings. Saving the post again in the editor resets the modified date.',
			'schedule',
			'publish_posts',
			self::schema(
				array(
					'id'        => $int,
					'published' => array( 'type' => 'string', 'description' => 'YYYY-MM-DD HH:MM' ),
					'modified'  => array( 'type' => 'string', 'description' => 'YYYY-MM-DD HH:MM' ),
				),
				array( 'id' )
			),
			array( __CLASS__, 'set_post_dates' ),
			array( 'idempotent' => true )
		);

		self::reg(
			'move-media-folder',
			'Move an image to another uploads folder',
			'Moves an attachment and all its generated sizes to uploads/YYYY/MM, updates the attachment record and rewrites every reference to the old file URLs in post content and post meta (both languages). Optional date sets the attachment upload date, which must be inside that month. Refuses if a file with the same name already exists in the target folder; if a file cannot be moved, everything is put back.',
			'images',
			'upload_files',
			self::schema(
				array(
					'attachment_id' => $int,
					'year'          => array( 'type' => 'integer', 'minimum' => 2000, 'maximum' => 2100 ),
					'month'         => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 12 ),
					'date'          => array( 'type' => 'string', 'description' => 'Optional upload date for the attachment, YYYY-MM-DD HH:MM, inside year and month.' ),
				),
				array( 'attachment_id', 'year', 'month' )
			),
			array( __CLASS__, 'move_media_folder' )
		);


		self::reg(
			'purge-cache',
			'Purge cache',
			'Purges the page cache for one post, or the whole site (plus Elementor CSS) without post_id.',
			'cache',
			'edit_posts',
			self::schema( array( 'post_id' => $int ) ),
			array( __CLASS__, 'purge_cache' ),
			array( 'idempotent' => true )
		);


		self::reg(
			'verify-url',
			'Verify a published page',
			'Loads a published page of this site without cache and checks status, one H1, title, description, robots, canonical, hreflang with x-default, JSON-LD, image alts, tables, table of contents, leftover markers and internal links (including subdomains).',
			'verify',
			'edit_posts',
			self::schema(
				array(
					'url'         => array( 'type' => 'string', 'format' => 'uri' ),
					'post_id'     => $int,
					'check_links' => $bool,
				)
			),
			array( __CLASS__, 'verify' ),
			self::ro()
		);
	}





	private static function terms_by_lang( $taxonomy ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'lang'       => '',
				'number'     => 500,
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		return array_map( array( 'Navia_MCP_Helpers', 'term_summary' ), $terms );
	}

	public static function site_context( $input = array() ) {
		$s     = Navia_MCP_Settings::site();
		$langs = array();
		if ( Navia_MCP_Helpers::pll() ) {
			foreach ( pll_languages_list( array( 'fields' => '' ) ) as $l ) {
				$langs[] = array(
					'slug'       => $l->slug,
					'name'       => $l->name,
					'locale'     => $l->locale,
					'is_default' => Navia_MCP_Helpers::default_language() === $l->slug,
					'home_url'   => $l->get_home_url(),
				);
			}
		}
		$authors = array();
		foreach ( get_users( array( 'capability' => array( 'edit_posts' ), 'fields' => array( 'ID', 'display_name', 'user_nicename' ) ) ) as $u ) {
			$user      = get_userdata( $u->ID );
			$authors[] = array(
				'id'           => (int) $u->ID,
				'display_name' => $u->display_name,
				'nicename'     => $u->user_nicename,
				'roles'        => $user ? array_values( $user->roles ) : array(),
				'is_default'   => (int) $s['default_author'] === (int) $u->ID,
			);
		}
		$tz  = Navia_MCP_Settings::schedule_tz();
		$now = new DateTime( 'now', $tz );

		return array(
			'site'            => array(
				'name'          => get_bloginfo( 'name' ),
				'url'           => home_url( '/' ),
				'blog_id'       => (int) get_current_blog_id(),
				'permalinks'    => (string) get_option( 'permalink_structure' ),
				'wp_timezone'   => wp_timezone_string(),
				'schedule_timezone' => $tz->getName(),
				'now_local'     => $now->format( 'Y-m-d H:i' ),
				'rank_math'     => defined( 'RANK_MATH_VERSION' ) ? RANK_MATH_VERSION : false,
				'polylang'      => defined( 'POLYLANG_VERSION' ) ? POLYLANG_VERSION : false,
			),
			'languages'       => $langs,
			'categories'      => self::terms_by_lang( 'category' ),
			'tags'            => self::terms_by_lang( 'post_tag' ),
			'authors'         => $authors,
			'publish_mode'    => $s['publish_mode'],
			'allowed_statuses' => Navia_MCP_Guard::allowed_statuses(),
			'modules'         => $s['modules'],
			'schedule'        => array(
				'min_days'                   => (int) $s['sched_min_days'],
				'max_days'                   => (int) $s['sched_max_days'],
				'window_start'               => $s['sched_window_start'],
				'window_end'                 => $s['sched_window_end'],
				'days'                       => array_map( 'intval', (array) $s['sched_days'] ),
				'translation_offset_minutes' => (int) $s['sched_tr_offset'],
				'allow_past'                 => ! empty( $s['sched_allow_past'] ),
			),
			'images'          => array(
				'min'             => (int) $s['img_min'],
				'max'             => (int) $s['img_max'],
				'style'           => $s['img_style'],
				'no_people'       => (bool) $s['img_no_people'],
				'provider_ready'  => Navia_MCP_Cloudflare::configured(),
				'used_today'      => Navia_MCP_Cloudflare::used_today(),
				'marker_format'   => '<!-- navia:img prompt="scene description" alt="alt text" -->',
			),
		);
	}

	public static function get_log( $input = array() ) {
		return array(
			'entries' => Navia_MCP_Log::query( $input['limit'] ?? 50, $input['ability'] ?? '', $input['object_id'] ?? 0 ),
		);
	}



	public static function list_terms( $input ) {
		$args = array(
			'taxonomy'   => $input['taxonomy'],
			'hide_empty' => false,
			'number'     => 500,
			'lang'       => isset( $input['lang'] ) ? $input['lang'] : '',
		);
		if ( ! empty( $input['search'] ) ) {
			$args['search'] = $input['search'];
		}
		$terms = get_terms( $args );
		if ( is_wp_error( $terms ) ) {
			return $terms;
		}
		return array( 'terms' => array_map( array( 'Navia_MCP_Helpers', 'term_summary' ), $terms ) );
	}

	public static function create_term( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$tax  = $input['taxonomy'];
		$lang = isset( $input['lang'] ) ? (string) $input['lang'] : '';
		if ( ! Navia_MCP_Helpers::valid_lang( $lang ) ) {
			return new WP_Error( 'navia_bad_lang', 'Unknown language: ' . $lang );
		}
		$name = trim( wp_strip_all_tags( $input['name'] ) );
		$slug = isset( $input['slug'] ) ? sanitize_title( $input['slug'] ) : sanitize_title( $name );


		$existing = get_terms(
			array(
				'taxonomy'   => $tax,
				'hide_empty' => false,
				'lang'       => $lang,
				'number'     => 1000,
			)
		);
		if ( ! is_wp_error( $existing ) ) {
			foreach ( $existing as $t ) {
				if ( $t->slug === $slug || 0 === strcasecmp( $t->name, $name ) ) {
					return new WP_Error( 'navia_term_exists', sprintf( 'A %s "%s" already exists (ID %d, slug %s). Reuse it.', $tax, $t->name, $t->term_id, $t->slug ) );
				}
			}
		}

		if ( ! empty( $input['translation_of'] ) ) {
			$src = get_term( (int) $input['translation_of'], $tax );
			if ( ! $src || is_wp_error( $src ) ) {
				return new WP_Error( 'navia_not_found', 'translation_of term not found in ' . $tax . '.' );
			}
			if ( $lang && Navia_MCP_Helpers::term_lang( $src->term_id ) === $lang ) {
				return new WP_Error( 'navia_bad_lang', 'translation_of is already in ' . $lang . '.' );
			}
		}

		$args = array(
			'slug'        => $slug,
			'description' => isset( $input['description'] ) ? wp_kses_post( $input['description'] ) : '',
		);
		if ( ! empty( $input['parent'] ) && 'category' === $tax ) {
			$args['parent'] = (int) $input['parent'];
		}


		$res = wp_insert_term( $name, $tax, $args );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$term_id = (int) $res['term_id'];

		if ( $lang && Navia_MCP_Helpers::pll() ) {
			pll_set_term_language( $term_id, $lang );
			if ( ! empty( $input['translation_of'] ) ) {
				$tr          = Navia_MCP_Helpers::term_translations( (int) $input['translation_of'] );
				$src_lang    = Navia_MCP_Helpers::term_lang( (int) $input['translation_of'] );
				if ( $src_lang ) {
					$tr[ $src_lang ] = (int) $input['translation_of'];
				}
				$tr[ $lang ] = $term_id;
				pll_save_term_translations( $tr );
			}
		}

		$term = get_term( $term_id, $tax );
		Navia_MCP_Log::add( 'navia/create-term', $term_id, sprintf( 'Created %s "%s" (%s)', $tax, $term->name, $lang ? $lang : 'no language' ) );
		return Navia_MCP_Helpers::term_summary( $term );
	}



	public static function list_content( $input = array() ) {
		$args = array(
			'post_type'      => 'post',
			'post_status'    => ! empty( $input['status'] ) ? $input['status'] : array( 'publish', 'future', 'draft', 'pending' ),
			'posts_per_page' => isset( $input['per_page'] ) ? (int) $input['per_page'] : 50,
			'paged'          => isset( $input['page'] ) ? (int) $input['page'] : 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'lang'           => isset( $input['lang'] ) ? $input['lang'] : '',
		);
		if ( ! empty( $input['category'] ) ) {
			$args['cat'] = (int) $input['category'];
		}
		if ( ! empty( $input['search'] ) ) {
			$args['s'] = $input['search'];
		}
		$q = new WP_Query( $args );
		return array(
			'total' => (int) $q->found_posts,
			'pages' => (int) $q->max_num_pages,
			'items' => array_map( array( 'Navia_MCP_Helpers', 'post_summary' ), $q->posts ),
		);
	}

	private static function get_post_or_error( $id, $cap = 'edit_post' ) {
		$post = get_post( (int) $id );
		if ( ! $post || 'post' !== $post->post_type ) {
			return new WP_Error( 'navia_not_found', sprintf( 'Post %d not found.', (int) $id ) );
		}
		if ( ! current_user_can( $cap, $post->ID ) ) {
			return new WP_Error( 'navia_forbidden', sprintf( 'The connected user cannot edit post %d.', $post->ID ) );
		}
		return $post;
	}

	private static function seo_values( $post_id ) {
		$robots = get_post_meta( $post_id, 'rank_math_robots', true );
		return array(
			'title'          => (string) get_post_meta( $post_id, 'rank_math_title', true ),
			'description'    => (string) get_post_meta( $post_id, 'rank_math_description', true ),
			'focus_keyword'  => (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true ),
			'robots'         => is_array( $robots ) ? array_values( $robots ) : array(),
			'canonical'      => (string) get_post_meta( $post_id, 'rank_math_canonical_url', true ),
			'og_title'       => (string) get_post_meta( $post_id, 'rank_math_facebook_title', true ),
			'og_description' => (string) get_post_meta( $post_id, 'rank_math_facebook_description', true ),
		);
	}

	public static function get_content( $input ) {
		$post = self::get_post_or_error( $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$out            = Navia_MCP_Helpers::post_summary( $post );
		$out['excerpt'] = $post->post_excerpt;
		if ( ! isset( $input['include_content'] ) || $input['include_content'] ) {
			$out['content'] = $post->post_content;
		}
		$fid             = (int) get_post_thumbnail_id( $post );
		$out['featured'] = $fid ? array(
			'id'  => $fid,
			'url' => wp_get_attachment_url( $fid ),
			'alt' => (string) get_post_meta( $fid, '_wp_attachment_image_alt', true ),
		) : null;
		$out['seo']             = self::seo_values( $post->ID );
		$out['image_markers']   = Navia_MCP_Helpers::count_markers( $post->post_content );
		$out['word_count']      = str_word_count( wp_strip_all_tags( $post->post_content ) );
		$out['h2_count']        = preg_match_all( '/<h2[\s>]/i', $post->post_content );
		$out['content_warnings'] = Navia_MCP_Helpers::content_warnings( $post->post_content );
		return $out;
	}




	private static function check_terms( array $ids, $taxonomy, $lang ) {
		$warnings = array();
		foreach ( $ids as $id ) {
			$t = get_term( (int) $id, $taxonomy );
			if ( ! $t || is_wp_error( $t ) ) {
				return new WP_Error( 'navia_bad_term', sprintf( '%s ID %d does not exist.', $taxonomy, (int) $id ) );
			}
			$tl = Navia_MCP_Helpers::term_lang( $t->term_id );
			if ( $lang && $tl && $tl !== $lang ) {
				$warnings[] = sprintf( '%s "%s" (ID %d) is in %s, the post is in %s.', $taxonomy, $t->name, $t->term_id, $tl, $lang );
			}
		}
		return $warnings;
	}

	private static function apply_seo( $post_id, array $seo, $lang = '' ) {
		$warnings = array();
		if ( ! defined( 'RANK_MATH_VERSION' ) ) {
			return array( 'Rank Math is not active: SEO meta not saved.' );
		}
		$map = array(
			'title'          => 'rank_math_title',
			'description'    => 'rank_math_description',
			'focus_keyword'  => 'rank_math_focus_keyword',
			'canonical'      => 'rank_math_canonical_url',
			'og_title'       => 'rank_math_facebook_title',
			'og_description' => 'rank_math_facebook_description',
		);
		foreach ( $map as $k => $meta ) {
			if ( ! array_key_exists( $k, $seo ) ) {
				continue;
			}
			$v = 'canonical' === $k ? esc_url_raw( (string) $seo[ $k ] ) : sanitize_text_field( (string) $seo[ $k ] );
			if ( '' === $v ) {
				delete_post_meta( $post_id, $meta );
			} else {
				update_post_meta( $post_id, $meta, $v );
			}
		}
		if ( isset( $seo['robots'] ) && is_array( $seo['robots'] ) ) {
			update_post_meta( $post_id, 'rank_math_robots', array_values( array_unique( $seo['robots'] ) ) );
		}

		if ( isset( $seo['title'] ) && Navia_MCP_Helpers::len( $seo['title'] ) > 60 ) {
			$warnings[] = sprintf( 'Meta title has %d characters (limit 60).', Navia_MCP_Helpers::len( $seo['title'] ) );
		}
		if ( isset( $seo['description'] ) && Navia_MCP_Helpers::len( $seo['description'] ) > 158 ) {
			$warnings[] = sprintf( 'Meta description has %d characters (limit 158).', Navia_MCP_Helpers::len( $seo['description'] ) );
		}
		foreach ( array( 'title', 'description', 'og_title', 'og_description' ) as $k ) {
			if ( isset( $seo[ $k ] ) && Navia_MCP_Helpers::has_dash( $seo[ $k ] ) ) {
				$warnings[] = 'Dash found in ' . $k . '.';
			}
		}
		if ( ! empty( $seo['focus_keyword'] ) ) {
			$primary = trim( strtok( (string) $seo['focus_keyword'], ',' ) );
			global $wpdb;
			$others = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT pm.post_id FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id
					 WHERE pm.meta_key = 'rank_math_focus_keyword' AND pm.post_id <> %d AND p.post_status IN ('publish','future','draft','pending')
					 AND ( pm.meta_value = %s OR pm.meta_value LIKE %s )",
					$post_id,
					$primary,
					$wpdb->esc_like( $primary ) . ',%'
				)
			);
			foreach ( array_map( 'intval', $others ) as $oid ) {
				if ( ! $lang || Navia_MCP_Helpers::post_lang( $oid ) === $lang ) {
					$warnings[] = sprintf( 'Focus keyword "%s" is already used by post %d.', $primary, $oid );
				}
			}
		}
		return $warnings;
	}

	public static function create_post( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$status = isset( $input['status'] ) ? $input['status'] : 'draft';
		$lang   = isset( $input['lang'] ) ? (string) $input['lang'] : '';
		if ( ! Navia_MCP_Helpers::valid_lang( $lang ) ) {
			return new WP_Error( 'navia_bad_lang', 'Unknown language: ' . $lang . '. Known: ' . implode( ', ', Navia_MCP_Helpers::languages() ) );
		}
		$content = (string) $input['content'];
		if ( preg_match( '/<h1[\s>]/i', $content ) ) {
			return new WP_Error( 'navia_h1', 'Remove the H1 from the content: the post template prints the title as H1. Use H2 and H3.' );
		}
		if ( Navia_MCP_Settings::module_on( 'tables' ) ) {
			$content = Navia_MCP_Tables::normalize( $content );
		}

		$warnings = array();
		$cats     = isset( $input['categories'] ) ? array_map( 'intval', $input['categories'] ) : array();
		$tags     = isset( $input['tags'] ) ? array_map( 'intval', $input['tags'] ) : array();
		foreach ( array( 'category' => $cats, 'post_tag' => $tags ) as $tax => $ids ) {
			$w = self::check_terms( $ids, $tax, $lang );
			if ( is_wp_error( $w ) ) {
				return $w;
			}
			$warnings = array_merge( $warnings, $w );
		}

		$author = Navia_MCP_Helpers::resolve_author( $input['author'] ?? 0 );
		if ( is_wp_error( $author ) ) {
			return $author;
		}

		if ( ! empty( $input['translation_of'] ) ) {
			$src = get_post( (int) $input['translation_of'] );
			if ( ! $src || 'post' !== $src->post_type ) {
				return new WP_Error( 'navia_not_found', 'translation_of post not found.' );
			}
			if ( $lang && Navia_MCP_Helpers::post_lang( $src->ID ) === $lang ) {
				return new WP_Error( 'navia_bad_lang', 'translation_of is already in ' . $lang . '. A translation must be in another language.' );
			}
			$existing = Navia_MCP_Helpers::post_translations( $src->ID );
			if ( $lang && ! empty( $existing[ $lang ] ) && (int) $existing[ $lang ] !== (int) $src->ID ) {
				return new WP_Error( 'navia_translation_exists', sprintf( 'Post %d already has a %s translation (ID %d). Update that one instead.', $src->ID, $lang, $existing[ $lang ] ) );
			}
		}

		$featured = isset( $input['featured_media'] ) ? (int) $input['featured_media'] : 0;
		if ( $featured && 'attachment' !== get_post_type( $featured ) ) {
			return new WP_Error( 'navia_bad_media', sprintf( 'featured_media %d is not an attachment.', $featured ) );
		}

		$postarr = array(
			'post_type'    => 'post',
			'post_status'  => $status,
			'post_title'   => wp_strip_all_tags( $input['title'] ),
			'post_content' => $content,
			'post_excerpt' => isset( $input['excerpt'] ) ? wp_strip_all_tags( $input['excerpt'] ) : '',
			'post_author'  => $author,
		);
		if ( ! empty( $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $input['slug'] );
		}

		$post_id = wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( $lang && Navia_MCP_Helpers::pll() ) {
			pll_set_post_language( $post_id, $lang );
		}
		wp_set_object_terms( $post_id, $cats ? $cats : array( (int) get_option( 'default_category' ) ), 'category' );
		if ( $tags ) {
			wp_set_object_terms( $post_id, $tags, 'post_tag' );
		}
		if ( $featured ) {
			set_post_thumbnail( $post_id, $featured );
		}
		Navia_MCP_TOC::set( $post_id, isset( $input['toc'] ) ? (bool) $input['toc'] : null );
		update_post_meta( $post_id, '_navia_created', 1 );

		if ( ! empty( $input['translation_of'] ) && $lang && Navia_MCP_Helpers::pll() ) {
			$src_id   = (int) $input['translation_of'];
			$tr       = Navia_MCP_Helpers::post_translations( $src_id );
			$src_lang = Navia_MCP_Helpers::post_lang( $src_id );
			if ( $src_lang ) {
				$tr[ $src_lang ] = $src_id;
			}
			$tr[ $lang ] = $post_id;
			pll_save_post_translations( $tr );
		}

		if ( ! empty( $input['seo'] ) && Navia_MCP_Settings::module_on( 'seo' ) ) {
			$warnings = array_merge( $warnings, self::apply_seo( $post_id, $input['seo'], $lang ) );
		}

		$post = get_post( $post_id );
		if ( ! empty( $postarr['post_name'] ) && $post->post_name !== $postarr['post_name'] ) {
			$warnings[] = sprintf( 'Slug "%s" was taken, WordPress used "%s".', $postarr['post_name'], $post->post_name );
		}
		if ( Navia_MCP_Helpers::has_dash( wp_strip_all_tags( $post->post_content ) . ' ' . $post->post_title ) ) {
			$warnings[] = 'Title or content contains en or em dashes.';
		}
		if ( ! preg_match( '/<table[\s>]/i', $post->post_content ) ) {
			$warnings[] = 'Content has no table.';
		}
		$markers = Navia_MCP_Helpers::count_markers( $post->post_content );
		if ( $markers !== Navia_MCP_Helpers::count_markers( $content ) ) {
			$warnings[] = 'Some image markers were altered on save. Check them with get-content.';
		}

		Navia_MCP_Log::add( 'navia/create-post', $post_id, sprintf( 'Created %s "%s" (%s)', $status, $post->post_title, $lang ? $lang : 'no language' ), array( 'length' => strlen( $post->post_content ) ) );

		$out                  = Navia_MCP_Helpers::post_summary( $post );
		$out['image_markers'] = $markers;
		$out['warnings']      = $warnings;
		return $out;
	}

	public static function update_post( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$post = self::get_post_or_error( $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$lang     = Navia_MCP_Helpers::post_lang( $post->ID );
		$warnings = array();
		$before   = array(
			'title'   => $post->post_title,
			'status'  => $post->post_status,
			'slug'    => $post->post_name,
			'excerpt' => $post->post_excerpt,
			'content_md5'    => md5( $post->post_content ),
			'content_length' => strlen( $post->post_content ),
		);

		$postarr = array( 'ID' => $post->ID );
		if ( isset( $input['title'] ) ) {
			$postarr['post_title'] = wp_strip_all_tags( $input['title'] );
		}
		if ( isset( $input['content'] ) ) {
			$content = (string) $input['content'];
			if ( preg_match( '/<h1[\s>]/i', $content ) ) {
				return new WP_Error( 'navia_h1', 'Remove the H1 from the content: the post template prints the title as H1.' );
			}
			if ( Navia_MCP_Settings::module_on( 'tables' ) ) {
				$content = Navia_MCP_Tables::normalize( $content );
			}
			$postarr['post_content'] = $content;
		}
		if ( isset( $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $input['slug'] );
		}
		if ( isset( $input['excerpt'] ) ) {
			$postarr['post_excerpt'] = wp_strip_all_tags( $input['excerpt'] );
		}
		if ( isset( $input['status'] ) && $input['status'] !== $post->post_status ) {
			if ( 'publish' === $post->post_status && 'all' !== Navia_MCP_Settings::get( 'publish_mode' ) ) {
				return new WP_Error( 'navia_published', 'This post is published. Unpublishing it needs the publishing mode "all", or do it in WordPress.' );
			}
			$postarr['post_status'] = $input['status'];
			if ( 'future' === $post->post_status ) {

				$postarr['post_date_gmt'] = '0000-00-00 00:00:00';
				$postarr['edit_date']     = true;
			}
		}
		if ( isset( $input['author'] ) ) {
			$author = Navia_MCP_Helpers::resolve_author( $input['author'] );
			if ( is_wp_error( $author ) ) {
				return $author;
			}
			$postarr['post_author'] = $author;
		}

		if ( count( $postarr ) > 1 ) {
			$res = wp_update_post( wp_slash( $postarr ), true );
			if ( is_wp_error( $res ) ) {
				return $res;
			}
		}

		foreach ( array( 'categories' => 'category', 'tags' => 'post_tag' ) as $key => $tax ) {
			if ( isset( $input[ $key ] ) ) {
				$ids = array_map( 'intval', $input[ $key ] );
				$w   = self::check_terms( $ids, $tax, $lang );
				if ( is_wp_error( $w ) ) {
					return $w;
				}
				$warnings = array_merge( $warnings, $w );
				wp_set_object_terms( $post->ID, $ids, $tax );
			}
		}
		if ( isset( $input['featured_media'] ) ) {
			if ( 0 === (int) $input['featured_media'] ) {
				delete_post_thumbnail( $post->ID );
			} elseif ( 'attachment' === get_post_type( (int) $input['featured_media'] ) ) {
				set_post_thumbnail( $post->ID, (int) $input['featured_media'] );
			} else {
				$warnings[] = 'featured_media is not an attachment, ignored.';
			}
		}
		if ( isset( $input['toc'] ) ) {
			Navia_MCP_TOC::set( $post->ID, (bool) $input['toc'] );
		}
		if ( ! empty( $input['seo'] ) && Navia_MCP_Settings::module_on( 'seo' ) ) {
			$warnings = array_merge( $warnings, self::apply_seo( $post->ID, $input['seo'], $lang ) );
		}

		$post  = get_post( $post->ID );
		$after = array(
			'title'          => $post->post_title,
			'status'         => $post->post_status,
			'slug'           => $post->post_name,
			'excerpt'        => $post->post_excerpt,
			'content_md5'    => md5( $post->post_content ),
			'content_length' => strlen( $post->post_content ),
		);
		$purged = 'publish' === $post->post_status ? Navia_MCP_Cache::after_write( $post->ID ) : array();
		Navia_MCP_Log::add( 'navia/update-post', $post->ID, 'Updated "' . $post->post_title . '"', array( 'before' => $before, 'after' => $after ) );

		$out             = Navia_MCP_Helpers::post_summary( $post );
		$out['warnings'] = $warnings;
		$out['purged']   = $purged;
		return $out;
	}

	public static function trash_content( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$post = self::get_post_or_error( $input['id'], 'delete_post' );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		if ( ! get_post_meta( $post->ID, '_navia_created', true ) && ! Navia_MCP_Settings::get( 'allow_trash_any' ) ) {
			return new WP_Error( 'navia_trash_refused', 'This post was not created through the Navia Suite Articles module. Trash it in WordPress, or allow it in Navia Suite > Articles (MCP).' );
		}
		$res = wp_trash_post( $post->ID );
		if ( ! $res ) {
			return new WP_Error( 'navia_trash_failed', 'WordPress could not move the post to the trash.' );
		}
		Navia_MCP_Log::add( 'navia/trash-content', $post->ID, 'Moved "' . $post->post_title . '" to the trash' );
		return array(
			'id'     => (int) $post->ID,
			'status' => get_post_status( $post->ID ),
		);
	}

	public static function normalize_tables( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$post = self::get_post_or_error( $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$new = Navia_MCP_Tables::normalize( $post->post_content );
		$changed = $new !== $post->post_content;
		if ( $changed ) {
			wp_update_post( wp_slash( array( 'ID' => $post->ID, 'post_content' => $new ) ) );
			Navia_MCP_Log::add( 'navia/normalize-tables', $post->ID, 'Normalised tables' );
		}
		return array(
			'id'      => (int) $post->ID,
			'changed' => $changed,
			'tables'  => preg_match_all( '/<table[\s>]/i', $new ),
		);
	}



	public static function set_seo( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$post = self::get_post_or_error( $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		if ( ! defined( 'RANK_MATH_VERSION' ) ) {
			return new WP_Error( 'navia_no_rank_math', 'Rank Math is not active on this site.' );
		}
		$seo = $input;
		unset( $seo['id'] );
		$warnings = self::apply_seo( $post->ID, $seo, Navia_MCP_Helpers::post_lang( $post->ID ) );
		if ( 'publish' === $post->post_status ) {
			Navia_MCP_Cache::after_write( $post->ID );
		}
		Navia_MCP_Log::add( 'navia/set-seo-meta', $post->ID, 'Set Rank Math meta for "' . $post->post_title . '"', $seo );
		return array(
			'id'       => (int) $post->ID,
			'seo'      => self::seo_values( $post->ID ),
			'warnings' => $warnings,
		);
	}

	public static function get_seo( $input ) {
		$post = self::get_post_or_error( $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		return array(
			'id'  => (int) $post->ID,
			'seo' => self::seo_values( $post->ID ),
		);
	}



	private static function need_pll() {
		return Navia_MCP_Helpers::pll() ? true : new WP_Error( 'navia_no_polylang', 'Polylang is not active on this site.' );
	}

	public static function set_language( $input ) {
		$ok = self::need_pll();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( ! Navia_MCP_Helpers::valid_lang( $input['lang'] ) || '' === $input['lang'] ) {
			return new WP_Error( 'navia_bad_lang', 'Unknown language: ' . $input['lang'] );
		}
		$id = (int) $input['id'];
		if ( 'post' === $input['object_type'] ) {
			$post = self::get_post_or_error( $id );
			if ( is_wp_error( $post ) ) {
				return $post;
			}
			pll_set_post_language( $id, $input['lang'] );
			$lang = Navia_MCP_Helpers::post_lang( $id );
		} else {
			if ( ! current_user_can( 'manage_categories' ) ) {
				return new WP_Error( 'navia_forbidden', 'Setting a term language needs manage_categories.' );
			}
			if ( ! term_exists( $id ) ) {
				return new WP_Error( 'navia_not_found', 'Term not found.' );
			}
			pll_set_term_language( $id, $input['lang'] );
			$lang = Navia_MCP_Helpers::term_lang( $id );
		}
		Navia_MCP_Log::add( 'navia/set-language', $id, sprintf( 'Language of %s %d set to %s', $input['object_type'], $id, $lang ) );
		return array(
			'id'   => $id,
			'lang' => $lang,
		);
	}

	public static function link_translations( $input ) {
		$ok = self::need_pll();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$is_post = 'post' === $input['object_type'];
		$tr      = array();
		foreach ( (array) $input['translations'] as $lang => $id ) {
			$id = (int) $id;
			if ( ! Navia_MCP_Helpers::valid_lang( $lang ) || '' === $lang ) {
				return new WP_Error( 'navia_bad_lang', 'Unknown language key: ' . $lang );
			}
			if ( $is_post ) {
				$p = self::get_post_or_error( $id );
				if ( is_wp_error( $p ) ) {
					return $p;
				}
				$current = Navia_MCP_Helpers::post_lang( $id );
			} else {
				if ( ! current_user_can( 'manage_categories' ) ) {
					return new WP_Error( 'navia_forbidden', 'Linking term translations needs manage_categories.' );
				}
				if ( ! term_exists( $id ) ) {
					return new WP_Error( 'navia_not_found', sprintf( 'Term %d not found.', $id ) );
				}
				$current = Navia_MCP_Helpers::term_lang( $id );
			}
			if ( $current && $current !== $lang ) {
				return new WP_Error( 'navia_bad_lang', sprintf( '%s %d is in %s, not %s.', $input['object_type'], $id, $current, $lang ) );
			}
			if ( ! $current ) {
				$is_post ? pll_set_post_language( $id, $lang ) : pll_set_term_language( $id, $lang );
			}
			$tr[ $lang ] = $id;
		}
		if ( count( $tr ) < 2 ) {
			return new WP_Error( 'navia_tr_count', 'Give at least two languages to link.' );
		}
		$is_post ? pll_save_post_translations( $tr ) : pll_save_term_translations( $tr );
		$first = reset( $tr );
		Navia_MCP_Log::add( 'navia/link-translations', $first, 'Linked translations ' . wp_json_encode( $tr ), $tr );
		return array(
			'object_type'  => $input['object_type'],
			'translations' => (object) ( $is_post ? Navia_MCP_Helpers::post_translations( $first ) : Navia_MCP_Helpers::term_translations( $first ) ),
		);
	}

	public static function get_translations( $input ) {
		$ok = self::need_pll();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$id = (int) $input['id'];
		if ( 'post' === $input['object_type'] ) {
			return array(
				'id'           => $id,
				'lang'         => Navia_MCP_Helpers::post_lang( $id ),
				'translations' => (object) Navia_MCP_Helpers::post_translations( $id ),
			);
		}
		return array(
			'id'           => $id,
			'lang'         => Navia_MCP_Helpers::term_lang( $id ),
			'translations' => (object) Navia_MCP_Helpers::term_translations( $id ),
		);
	}



	public static function generate_image( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$post_id = isset( $input['post_id'] ) ? (int) $input['post_id'] : 0;
		if ( $post_id ) {
			$post = self::get_post_or_error( $post_id );
			if ( is_wp_error( $post ) ) {
				return $post;
			}
		}
		$res = Navia_MCP_Images::generate_attachment( $input );
		if ( is_wp_error( $res ) ) {
			Navia_MCP_Log::add( 'navia/generate-image', $post_id, 'Image generation failed: ' . $res->get_error_message(), array(), 'error' );
			return $res;
		}
		if ( $post_id && ! empty( $input['set_featured'] ) ) {
			set_post_thumbnail( $post_id, $res['id'] );
			$res['set_as_featured'] = true;
		}
		Navia_MCP_Log::add( 'navia/generate-image', $res['id'], 'Generated image "' . $res['alt'] . '"', array( 'post_id' => $post_id ) );
		return $res;
	}

	public static function generate_post_images( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$post = self::get_post_or_error( $input['post_id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$res = Navia_MCP_Images::process_post( $post->ID, $input );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		Navia_MCP_Log::add(
			'navia/generate-post-images',
			$post->ID,
			sprintf( 'Images for "%s": %d inline, featured %s, %d fallback', $post->post_title, count( $res['inline_placed'] ), $res['featured'] ? 'yes' : 'no', $res['fallbacks_used'] ),
			$res,
			$res['errors'] ? 'warning' : 'ok'
		);
		if ( 'publish' === $post->post_status ) {
			Navia_MCP_Cache::after_write( $post->ID );
		}
		return $res;
	}

	public static function image_usage( $input = array() ) {
		$usage = Navia_MCP_Cloudflare::usage();
		krsort( $usage );
		$paused = Navia_MCP_Cloudflare::paused_until();
		return array(
			'configured'   => Navia_MCP_Cloudflare::configured(),
			'today'        => Navia_MCP_Cloudflare::used_today(),
			'daily_limit'  => (int) Navia_MCP_Settings::network()['cf_daily_limit'],
			'paused_until' => $paused > time() ? gmdate( 'c', $paused ) : null,
			'by_day'       => (object) array_slice( $usage, 0, 30, true ),
		);
	}



	public static function schedule_posts( $input ) {
		if ( ! Navia_MCP_Guard::can_schedule() ) {
			return new WP_Error( 'navia_mode', 'The publishing mode on this site is "drafts only". Change it in Navia Suite > Articles (MCP) to allow scheduling.' );
		}
		$confirm = ! empty( $input['confirm'] );
		if ( $confirm ) {
			$ok = Navia_MCP_Guard::write_allowed();
			if ( is_wp_error( $ok ) ) {
				return $ok;
			}
		}

		$groups   = array();
		$problems = array();
		$warnings = array();
		$seen     = array();
		foreach ( $input['items'] as $item ) {
			$main = (int) $item['id'];
			$ids  = array( $main );
			if ( isset( $item['translations'] ) ) {
				$trs = array_map( 'intval', $item['translations'] );
			} else {
				$trs = array_values( array_diff( Navia_MCP_Helpers::post_translations( $main ), array( $main ) ) );
			}
			$ids = array_merge( $ids, $trs );
			foreach ( $ids as $id ) {
				if ( isset( $seen[ $id ] ) ) {
					$problems[] = sprintf( 'Post %d appears twice.', $id );
					continue;
				}
				$seen[ $id ] = true;
				$p = self::get_post_or_error( $id, 'publish_post' );
				if ( is_wp_error( $p ) ) {
					$problems[] = $p->get_error_message();
					continue;
				}
				if ( 'publish' === $p->post_status ) {
					$problems[] = sprintf( 'Post %d "%s" is already published.', $id, $p->post_title );
				}
				if ( 'trash' === $p->post_status ) {
					$problems[] = sprintf( 'Post %d is in the trash.', $id );
				}
				if ( Navia_MCP_Helpers::count_markers( $p->post_content ) ) {
					$problems[] = sprintf( 'Post %d "%s" still has image markers. Run generate-post-images first.', $id, $p->post_title );
				}
				if ( ! has_post_thumbnail( $p ) ) {
					$warnings[] = sprintf( 'Post %d has no featured image.', $id );
				}
				if ( defined( 'RANK_MATH_VERSION' ) && ! get_post_meta( $id, 'rank_math_description', true ) ) {
					$warnings[] = sprintf( 'Post %d has no Rank Math description.', $id );
				}
			}
			if ( $trs && Navia_MCP_Helpers::pll() ) {
				$linked = Navia_MCP_Helpers::post_translations( $main );
				foreach ( $trs as $t ) {
					if ( ! in_array( $t, $linked, true ) ) {
						$warnings[] = sprintf( 'Post %d is not linked as a translation of %d in Polylang.', $t, $main );
					}
				}
			}
			$groups[] = array(
				'main'         => $main,
				'translations' => $trs,
				'date'         => isset( $item['date'] ) ? trim( (string) $item['date'] ) : '',
			);
		}
		if ( $problems ) {
			return new WP_Error( 'navia_sched_blocked', 'Nothing was scheduled. ' . implode( ' ', $problems ) );
		}

		$ids_key = md5( wp_json_encode( $groups ) );


		if ( $confirm && ! empty( $input['plan_token'] ) ) {
			$stored = get_transient( 'navia_mcp_plan_' . get_current_user_id() . '_' . sanitize_key( $input['plan_token'] ) );
			if ( ! is_array( $stored ) || $stored['ids_key'] !== $ids_key ) {
				return new WP_Error( 'navia_plan_expired', 'The plan_token is unknown, expired (1 hour) or was made for other items. Ask for a new plan.' );
			}
			delete_transient( 'navia_mcp_plan_' . get_current_user_id() . '_' . sanitize_key( $input['plan_token'] ) );
			return array(
				'applied'  => true,
				'slots'    => Navia_MCP_Scheduler::apply( $stored['plan'] ),
				'warnings' => $warnings,
			);
		}

		$plan = Navia_MCP_Scheduler::plan(
			$groups,
			array(
				'start_date'   => $input['start_date'] ?? '',
				'min_days'     => $input['min_days'] ?? null,
				'max_days'     => $input['max_days'] ?? null,
				'window_start' => $input['window_start'] ?? null,
				'window_end'   => $input['window_end'] ?? null,
				'days'         => $input['days'] ?? null,
				'tr_offset'    => $input['translation_offset_minutes'] ?? null,
				'allow_past'   => ! empty( $input['allow_past'] ),
			)
		);
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}
		if ( ! $confirm ) {
			$token = strtolower( wp_generate_password( 12, false ) );
			set_transient(
				'navia_mcp_plan_' . get_current_user_id() . '_' . $token,
				array(
					'ids_key' => $ids_key,
					'plan'    => $plan,
				),
				HOUR_IN_SECONDS
			);
			return array(
				'applied'    => false,
				'plan_token' => $token,
				'note'       => 'Plan only, nothing changed. To apply exactly these dates, call again with the same items, confirm=true and this plan_token (valid 1 hour).',
				'plan'       => $plan,
				'warnings'   => $warnings,
			);
		}
		$applied = Navia_MCP_Scheduler::apply( $plan );
		return array(
			'applied'  => true,
			'slots'    => $applied,
			'warnings' => $warnings,
		);
	}

	public static function calendar( $input = array() ) {
		$tz   = Navia_MCP_Settings::schedule_tz();
		$args = array(
			'post_type'      => 'post',
			'post_status'    => array( 'future' ),
			'posts_per_page' => 200,
			'orderby'        => 'date',
			'order'          => 'ASC',
			'lang'           => '',
		);
		$range = array();
		if ( ! empty( $input['from'] ) ) {
			$range['after'] = $input['from'];
		}
		if ( ! empty( $input['to'] ) ) {
			$range['before'] = $input['to'] . ' 23:59:59';
		}
		if ( $range ) {
			$range['inclusive'] = true;
			$range['column']    = 'post_date_gmt';
			$args['date_query'] = array( $range );
		}
		$q      = new WP_Query( $args );
		$items  = array_map( array( 'Navia_MCP_Helpers', 'post_summary' ), $q->posts );
		$missed = array_values(
			array_filter(
				$items,
				function ( $i ) {
					return strtotime( $i['date_gmt'] . ' UTC' ) < time() - 300;
				}
			)
		);
		return array(
			'timezone' => $tz->getName(),
			'count'    => count( $items ),
			'items'    => $items,
			'missed'   => $missed,
		);
	}

	public static function fix_missed( $input = array() ) {
		$ids = Navia_MCP_Scheduler::fix_missed();
		return array( 'published' => $ids );
	}



	public static function set_post_dates( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return new WP_Error( 'navia_forbidden', 'Changing post dates needs the edit_others_posts capability.' );
		}
		return Navia_MCP_Dates::set_post_dates( $input );
	}

	public static function move_media_folder( $input ) {
		$ok = Navia_MCP_Guard::write_allowed();
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return new WP_Error( 'navia_forbidden', 'Moving media needs the edit_others_posts capability.' );
		}
		return Navia_MCP_Dates::move_media( $input );
	}



	public static function purge_cache( $input = array() ) {
		$post_id = isset( $input['post_id'] ) ? (int) $input['post_id'] : 0;
		if ( ! $post_id && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'navia_forbidden', 'A full purge needs manage_options. Give a post_id instead.' );
		}
		$done = Navia_MCP_Cache::purge( $post_id );
		Navia_MCP_Log::add( 'navia/purge-cache', $post_id, $post_id ? 'Purged cache for post ' . $post_id : 'Purged the whole cache', $done );
		return array(
			'post_id' => $post_id,
			'purged'  => $done,
		);
	}



	public static function verify( $input = array() ) {
		$url = isset( $input['url'] ) ? $input['url'] : '';
		if ( ! $url && ! empty( $input['post_id'] ) ) {
			$p = get_post( (int) $input['post_id'] );
			if ( ! $p || 'publish' !== $p->post_status ) {
				return new WP_Error( 'navia_not_published', 'The post is not published yet, so it cannot be verified as a visitor sees it.' );
			}
			$url = get_permalink( $p );
		}
		if ( ! $url ) {
			return new WP_Error( 'navia_verify_input', 'Give url or post_id.' );
		}
		return Navia_MCP_Verify::url( $url, ! isset( $input['check_links'] ) || $input['check_links'] );
	}
}
