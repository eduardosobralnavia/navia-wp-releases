<?php




defined( 'ABSPATH' ) || exit;

class Navia_MCP_Admin {

	const SLUG = 'navia-wp-mcp';

	public static function init() {
		add_action( 'network_admin_menu', array( __CLASS__, 'network_menu' ) );
		add_action( 'admin_menu', array( __CLASS__, 'site_menu' ) );
		add_action( 'admin_post_navia_mcp_export_log', array( __CLASS__, 'export_log' ) );
					}

	public static function network_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( network_admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Settings</a>' );
		return $links;
	}

	public static function site_links( $links ) {
		if ( Navia_MCP_Settings::site_enabled() ) {
			array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Settings</a>' );
		}
		return $links;
	}

	public static function network_menu() {
		add_submenu_page( NAS_Admin::MENU, 'Articles (MCP)', 'Articles (MCP)', 'manage_network_options', self::SLUG, array( __CLASS__, 'network_page' ) );
	}

	public static function site_menu() {
		if ( ! Navia_MCP_Settings::site_enabled() ) {
			return;
		}
		add_submenu_page( NAS_Admin::MENU, 'Articles (MCP)', 'Articles (MCP)', 'manage_options', self::SLUG, array( __CLASS__, 'site_page' ) );
	}



	private static function notice( $msg, $type = 'success' ) {
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), wp_kses_post( $msg ) );
	}

	private static function provider_fields( array $net ) {
		?>
		<h2>Image provider: Cloudflare Workers AI</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="cf_account_id">Account ID</label></th>
				<td><input type="text" class="regular-text code" id="cf_account_id" name="cf_account_id" value="<?php echo esc_attr( $net['cf_account_id'] ); ?>" autocomplete="off" />
				<p class="description">The 32 character code after <code>dash.cloudflare.com/</code> in the dashboard address.</p></td>
			</tr>
			<tr>
				<th scope="row"><label for="cf_token">API token</label></th>
				<td><input type="password" class="regular-text code" id="cf_token" name="cf_token" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( Navia_MCP_Crypto::mask( $net['cf_token'] ) ? Navia_MCP_Crypto::mask( $net['cf_token'] ) . ' (saved)' : 'not set' ); ?>" />
				<p class="description">Token from the "Workers AI" template. Leave empty to keep the saved one. Stored encrypted with the wp-config.php salts.</p>
				<label><input type="checkbox" name="cf_token_clear" value="1" /> Remove the saved token</label></td>
			</tr>
			<tr>
				<th scope="row"><label for="cf_model">Model</label></th>
				<td><input type="text" class="regular-text code" id="cf_model" name="cf_model" value="<?php echo esc_attr( $net['cf_model'] ); ?>" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="cf_steps">Steps</label></th>
				<td><input type="number" min="1" max="8" id="cf_steps" name="cf_steps" value="<?php echo esc_attr( $net['cf_steps'] ); ?>" class="small-text" />
				<p class="description">FLUX.1 schnell: 4 is the default. More steps cost more of the daily quota.</p></td>
			</tr>
			<tr>
				<th scope="row"><label for="cf_daily_limit">Daily limit</label></th>
				<td><input type="number" min="1" max="10000" id="cf_daily_limit" name="cf_daily_limit" value="<?php echo esc_attr( $net['cf_daily_limit'] ); ?>" class="small-text" /> images per day, across all sites
				<p class="description">Used today: <?php echo (int) Navia_MCP_Cloudflare::used_today(); ?>. The free quota is about 170 images a day at 4 steps.</p></td>
			</tr>
			<tr>
				<th scope="row"><label for="log_retention_days">Log retention</label></th>
				<td><input type="number" min="7" max="3650" id="log_retention_days" name="log_retention_days" value="<?php echo esc_attr( $net['log_retention_days'] ); ?>" class="small-text" /> days</td>
			</tr>
		</table>
		<p><button type="submit" name="navia_test_cf" value="1" class="button">Save and test (generates one image)</button></p>
		<?php
	}

	private static function save_provider_fields( array $post ) {
		$net                       = Navia_MCP_Settings::network();
		$net['cf_account_id']      = preg_replace( '/[^a-f0-9]/i', '', (string) ( $post['cf_account_id'] ?? '' ) );
		$net['cf_model']           = sanitize_text_field( (string) ( $post['cf_model'] ?? $net['cf_model'] ) );
		$net['cf_steps']           = max( 1, min( 8, (int) ( $post['cf_steps'] ?? 4 ) ) );
		$net['cf_daily_limit']     = max( 1, min( 10000, (int) ( $post['cf_daily_limit'] ?? 150 ) ) );
		$net['log_retention_days'] = max( 7, min( 3650, (int) ( $post['log_retention_days'] ?? 365 ) ) );
		$token                     = trim( (string) ( $post['cf_token'] ?? '' ) );
		if ( ! empty( $post['cf_token_clear'] ) ) {
			$net['cf_token'] = '';
		} elseif ( '' !== $token ) {
			$net['cf_token'] = Navia_MCP_Crypto::encrypt( $token );
		}
		return $net;
	}

	private static function test_provider() {
		$res = Navia_MCP_Cloudflare::generate( 'A whitewashed house with a terracotta roof under a clear blue sky, documentary photograph, no people, no text.' );
		if ( is_wp_error( $res ) ) {
			self::notice( 'Test failed: ' . esc_html( $res->get_error_message() ), 'error' );
			return;
		}
		self::notice( 'Cloudflare works. Test image (not saved):<br><img alt="Test image" style="max-width:320px;height:auto;margin-top:8px;border-radius:8px" src="data:' . esc_attr( $res['mime'] ) . ';base64,' . base64_encode( $res['bytes'] ) . '" />' );
	}



	public static function network_page() {
		if ( ! current_user_can( 'manage_network_options' ) ) {
			return;
		}
		$test = false;
		if ( isset( $_POST['navia_mcp_network_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['navia_mcp_network_nonce'] ), 'navia_mcp_network' ) ) {
			$post                 = wp_unslash( $_POST );
			$net                  = self::save_provider_fields( $post );
			$net['enabled_sites'] = array_map( 'intval', (array) ( $post['enabled_sites'] ?? array() ) );
			Navia_MCP_Settings::save_network( $net );
			NAS_Settings::set_module_sites( 'articles', $net['enabled_sites'] );
			$test = ! empty( $post['navia_test_cf'] );
			self::notice( 'Settings saved.' );
		}
		$net = Navia_MCP_Settings::network();
		echo '<div class="wrap"><h1>Navia Suite: Articles (MCP), network settings</h1>';
		if ( $test ) {
			self::test_provider();
		}
		echo '<form method="post">';
		wp_nonce_field( 'navia_mcp_network', 'navia_mcp_network_nonce' );
		?>
		<h2>Sites</h2>
		<p>Abilities and the settings page appear only on the sites ticked here.</p>
		<fieldset>
		<?php
		foreach ( get_sites( array( 'number' => 200 ) ) as $site ) {
			$id      = (int) $site->blog_id;
			$details = get_blog_details( $id );
			printf(
				'<label style="display:block;margin:4px 0"><input type="checkbox" name="enabled_sites[]" value="%1$d" %2$s /> %3$s <code>%4$s</code></label>',
				$id,
				checked( NAS_Settings::module_on( 'articles', (int) $id ), true, false ),
				esc_html( $details ? $details->blogname : '' ),
				esc_html( $site->domain . $site->path )
			);
		}
		?>
		</fieldset>
		<?php
		self::provider_fields( $net );
		submit_button( 'Save settings' );
		echo '</form></div>';
	}



	public static function site_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab = isset( $_GET['tab'] ) && 'log' === $_GET['tab'] ? 'log' : 'settings';
		echo '<div class="wrap"><h1>Navia Suite: Articles (MCP)</h1>';
		printf(
			'<nav class="nav-tab-wrapper"><a class="nav-tab %s" href="%s">Settings</a><a class="nav-tab %s" href="%s">Log</a></nav>',
			'settings' === $tab ? 'nav-tab-active' : '',
			esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ),
			'log' === $tab ? 'nav-tab-active' : '',
			esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=log' ) )
		);
		if ( 'log' === $tab ) {
			self::log_tab();
		} else {
			self::settings_tab();
		}
		echo '</div>';
	}

	private static function settings_tab() {
		$test = false;
		if ( isset( $_POST['navia_mcp_site_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['navia_mcp_site_nonce'] ), 'navia_mcp_site' ) ) {
			$p = wp_unslash( $_POST );
			$s = Navia_MCP_Settings::site();

			$mods = array();
			foreach ( array_keys( Navia_MCP_Settings::MODULES ) as $m ) {
				$mods[ $m ] = ! empty( $p['modules'][ $m ] );
			}
			$s['modules']         = $mods;
			$s['publish_mode']    = in_array( $p['publish_mode'] ?? '', array( 'drafts', 'schedule', 'all' ), true ) ? $p['publish_mode'] : 'schedule';
			$s['default_author']  = (int) ( $p['default_author'] ?? 0 );
			$s['rate_limit']      = max( 1, min( 500, (int) ( $p['rate_limit'] ?? 40 ) ) );
			$s['allow_trash_any'] = ! empty( $p['allow_trash_any'] );

			$s['sched_min_days']     = max( 0, min( 30, (int) ( $p['sched_min_days'] ?? 1 ) ) );
			$s['sched_max_days']     = max( $s['sched_min_days'], min( 30, (int) ( $p['sched_max_days'] ?? 3 ) ) );
			$s['sched_window_start'] = preg_match( '/^\d{1,2}:\d{2}$/', $p['sched_window_start'] ?? '' ) ? $p['sched_window_start'] : '08:30';
			$s['sched_window_end']   = preg_match( '/^\d{1,2}:\d{2}$/', $p['sched_window_end'] ?? '' ) ? $p['sched_window_end'] : '10:30';
			$s['sched_days']         = array_values( array_intersect( array( 1, 2, 3, 4, 5, 6, 7 ), array_map( 'intval', (array) ( $p['sched_days'] ?? array() ) ) ) );
			$s['sched_tr_offset']    = max( 0, min( 1440, (int) ( $p['sched_tr_offset'] ?? 120 ) ) );
			$tzs                     = timezone_identifiers_list();
			$s['sched_timezone']     = in_array( $p['sched_timezone'] ?? '', $tzs, true ) ? $p['sched_timezone'] : 'Europe/Lisbon';
			$s['sched_allow_past']   = ! empty( $p['sched_allow_past'] );

			$s['img_min']              = max( 0, min( 8, (int) ( $p['img_min'] ?? 1 ) ) );
			$s['img_max']              = max( $s['img_min'], min( 8, (int) ( $p['img_max'] ?? 4 ) ) );
			$s['img_style']            = sanitize_textarea_field( $p['img_style'] ?? '' );
			$s['img_palette']          = sanitize_text_field( $p['img_palette'] ?? '' );
			$s['img_avoid']            = sanitize_text_field( $p['img_avoid'] ?? '' );
			$s['img_no_people']        = ! empty( $p['img_no_people'] );
			$s['img_fallback_library'] = ! empty( $p['img_fallback_library'] );

			foreach ( array( 'tbl_head_bg', 'tbl_head_color', 'tbl_stripe', 'tbl_border' ) as $k ) {
				$c       = sanitize_hex_color( $p[ $k ] ?? '' );
				$s[ $k ] = $c ? $c : Navia_MCP_Settings::site_defaults()[ $k ];
			}
			$s['tbl_radius']       = max( 0, min( 40, (int) ( $p['tbl_radius'] ?? 12 ) ) );
			$s['cache_auto_purge'] = ! empty( $p['cache_auto_purge'] );

			Navia_MCP_Settings::save_site( $s );

			if ( ! NAS_Env::network_mode() ) {
				Navia_MCP_Settings::save_network( self::save_provider_fields( $p ) );
				$test = ! empty( $p['navia_test_cf'] );
			}
			self::notice( 'Settings saved.' );
		}

		$s = Navia_MCP_Settings::site();
		if ( $test ) {
			self::test_provider();
		}
		if ( NAS_Env::network_mode() && ! Navia_MCP_Cloudflare::configured() ) {
			self::notice( 'The image provider is not configured yet. A super admin sets it in Network Admin > Navia Suite > Articles (MCP).', 'warning' );
		}
		$days = array( 1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun' );

		echo '<form method="post">';
		wp_nonce_field( 'navia_mcp_site', 'navia_mcp_site_nonce' );
		?>
		<h2>Modules</h2>
		<fieldset>
		<?php foreach ( Navia_MCP_Settings::MODULES as $key => $label ) : ?>
			<label style="display:block;margin:4px 0"><input type="checkbox" name="modules[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! empty( $s['modules'][ $key ] ) ); ?> /> <?php echo esc_html( $label ); ?></label>
		<?php endforeach; ?>
		</fieldset>

		<h2>Publishing</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">Mode</th>
				<td>
					<label style="display:block"><input type="radio" name="publish_mode" value="drafts" <?php checked( $s['publish_mode'], 'drafts' ); ?> /> Drafts only</label>
					<label style="display:block"><input type="radio" name="publish_mode" value="schedule" <?php checked( $s['publish_mode'], 'schedule' ); ?> /> Drafts and scheduling (recommended)</label>
					<label style="display:block"><input type="radio" name="publish_mode" value="all" <?php checked( $s['publish_mode'], 'all' ); ?> /> Everything, including unpublishing</label>
					<p class="description">No ability ever publishes immediately. Scheduling is the only way a post goes live.</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="default_author">Default author</label></th>
				<td><select id="default_author" name="default_author">
					<option value="0">The connected user</option>
					<?php foreach ( get_users( array( 'capability' => array( 'edit_posts' ) ) ) as $u ) : ?>
						<option value="<?php echo (int) $u->ID; ?>" <?php selected( (int) $s['default_author'], (int) $u->ID ); ?>><?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?></option>
					<?php endforeach; ?>
				</select></td>
			</tr>
			<tr>
				<th scope="row"><label for="rate_limit">Write limit</label></th>
				<td><input type="number" min="1" max="500" id="rate_limit" name="rate_limit" value="<?php echo esc_attr( $s['rate_limit'] ); ?>" class="small-text" /> writes per minute</td>
			</tr>
			<tr>
				<th scope="row">Trash</th>
				<td><label><input type="checkbox" name="allow_trash_any" value="1" <?php checked( $s['allow_trash_any'] ); ?> /> Allow moving any post to the trash (default: only posts created through Navia WP MCP)</label></td>
			</tr>
		</table>

		<h2>Scheduling</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">Gap between articles</th>
				<td><input type="number" min="0" max="30" name="sched_min_days" value="<?php echo esc_attr( $s['sched_min_days'] ); ?>" class="small-text" /> to <input type="number" min="0" max="30" name="sched_max_days" value="<?php echo esc_attr( $s['sched_max_days'] ); ?>" class="small-text" /> days, drawn at random</td>
			</tr>
			<tr>
				<th scope="row">Time window</th>
				<td><input type="time" name="sched_window_start" value="<?php echo esc_attr( $s['sched_window_start'] ); ?>" /> to <input type="time" name="sched_window_end" value="<?php echo esc_attr( $s['sched_window_end'] ); ?>" />, random minute</td>
			</tr>
			<tr>
				<th scope="row">Weekdays</th>
				<td><?php foreach ( $days as $n => $d ) : ?>
					<label style="margin-right:10px"><input type="checkbox" name="sched_days[]" value="<?php echo (int) $n; ?>" <?php checked( in_array( $n, array_map( 'intval', (array) $s['sched_days'] ), true ) ); ?> /> <?php echo esc_html( $d ); ?></label>
				<?php endforeach; ?></td>
			</tr>
			<tr>
				<th scope="row">Translations</th>
				<td><input type="number" min="0" max="1440" name="sched_tr_offset" value="<?php echo esc_attr( $s['sched_tr_offset'] ); ?>" class="small-text" /> minutes after the main post</td>
			</tr>
			<tr>
				<th scope="row">Past dates</th>
				<td><label><input type="checkbox" name="sched_allow_past" value="1" <?php checked( ! empty( $s['sched_allow_past'] ) ); ?> /> Allow past dates</label>
				<p class="description">When ticked, schedule-posts called with allow_past=true publishes posts with a date in the past, and set-post-dates can move a publication date back. Without allow_past in the call, scheduling works as before.</p></td>
			</tr>
			<tr>
				<th scope="row"><label for="sched_timezone">Timezone</label></th>
				<td><select id="sched_timezone" name="sched_timezone">
					<?php foreach ( timezone_identifiers_list() as $tz ) : ?>
						<option value="<?php echo esc_attr( $tz ); ?>" <?php selected( $s['sched_timezone'], $tz ); ?>><?php echo esc_html( $tz ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description">WordPress timezone on this site: <?php echo esc_html( wp_timezone_string() ); ?>.</p></td>
			</tr>
		</table>

		<h2>Images</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">Inline images per article</th>
				<td><input type="number" min="0" max="8" name="img_min" value="<?php echo esc_attr( $s['img_min'] ); ?>" class="small-text" /> to <input type="number" min="0" max="8" name="img_max" value="<?php echo esc_attr( $s['img_max'] ); ?>" class="small-text" />, drawn at random, plus the featured image</td>
			</tr>
			<tr>
				<th scope="row"><label for="img_style">Base style</label></th>
				<td><textarea id="img_style" name="img_style" rows="3" class="large-text"><?php echo esc_textarea( $s['img_style'] ); ?></textarea></td>
			</tr>
			<tr>
				<th scope="row"><label for="img_palette">Palette</label></th>
				<td><input type="text" id="img_palette" name="img_palette" value="<?php echo esc_attr( $s['img_palette'] ); ?>" class="large-text" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="img_avoid">Avoid</label></th>
				<td><input type="text" id="img_avoid" name="img_avoid" value="<?php echo esc_attr( $s['img_avoid'] ); ?>" class="large-text" /></td>
			</tr>
			<tr>
				<th scope="row">People</th>
				<td><label><input type="checkbox" name="img_no_people" value="1" <?php checked( $s['img_no_people'] ); ?> /> No realistic people in generated images</label></td>
			</tr>
			<tr>
				<th scope="row">Fallback</th>
				<td><label><input type="checkbox" name="img_fallback_library" value="1" <?php checked( $s['img_fallback_library'] ); ?> /> When generation fails, use library images whose alt text or title matches the post's category</label>
				<p class="description">If none match, the article gets fewer images, or only the featured image.</p></td>
			</tr>
		</table>

		<h2>Tables</h2>
		<table class="form-table" role="presentation">
			<tr><th scope="row">Header</th><td><input type="color" name="tbl_head_bg" value="<?php echo esc_attr( $s['tbl_head_bg'] ); ?>" /> background <input type="color" name="tbl_head_color" value="<?php echo esc_attr( $s['tbl_head_color'] ); ?>" /> text</td></tr>
			<tr><th scope="row">Rows</th><td><input type="color" name="tbl_stripe" value="<?php echo esc_attr( $s['tbl_stripe'] ); ?>" /> stripe <input type="color" name="tbl_border" value="<?php echo esc_attr( $s['tbl_border'] ); ?>" /> border</td></tr>
			<tr><th scope="row">Corners</th><td><input type="number" min="0" max="40" name="tbl_radius" value="<?php echo esc_attr( $s['tbl_radius'] ); ?>" class="small-text" /> px</td></tr>
		</table>

		<h2>Cache</h2>
		<p><label><input type="checkbox" name="cache_auto_purge" value="1" <?php checked( $s['cache_auto_purge'] ); ?> /> Purge the page cache of a published post after every write to it</label></p>
		<?php
		if ( ! NAS_Env::network_mode() ) {
			self::provider_fields( Navia_MCP_Settings::network() );
		}
		submit_button( 'Save settings' );
		echo '</form>';
	}

	private static function log_tab() {
		$rows = Navia_MCP_Log::query( 200 );
		printf(
			'<p><a class="button" href="%s">Export CSV (last 1000)</a></p>',
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=navia_mcp_export_log' ), 'navia_mcp_export_log' ) )
		);
		echo '<table class="widefat striped"><thead><tr><th>Date (UTC)</th><th>User</th><th>Ability</th><th>Object</th><th>Result</th><th>Summary</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="6">No entries yet.</td></tr>';
		}
		foreach ( $rows as $r ) {
			$user = get_userdata( (int) $r['user_id'] );
			$obj  = (int) $r['object_id'];
			$link = $obj && get_post( $obj ) ? '<a href="' . esc_url( get_edit_post_link( $obj ) ) . '">' . $obj . '</a>' : ( $obj ? $obj : '' );
			printf(
				'<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( $r['created_at'] ),
				esc_html( $user ? $user->user_login : '' ),
				esc_html( $r['ability'] ),
				wp_kses_post( (string) $link ),
				esc_html( $r['result'] ),
				esc_html( $r['summary'] )
			);
		}
		echo '</tbody></table>';
	}

	public static function export_log() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'navia_mcp_export_log' ) ) {
			wp_die( 'Not allowed.' );
		}
		$rows = Navia_MCP_Log::query( 1000 );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=navia-mcp-log-' . gmdate( 'Ymd-His' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'id', 'created_at_utc', 'user', 'ability', 'object_id', 'result', 'summary' ) );
		foreach ( $rows as $r ) {
			$user = get_userdata( (int) $r['user_id'] );
			fputcsv( $out, array( $r['id'], $r['created_at'], $user ? $user->user_login : '', $r['ability'], $r['object_id'], $r['result'], $r['summary'] ) );
		}
		fclose( $out );
		exit;
	}
}
