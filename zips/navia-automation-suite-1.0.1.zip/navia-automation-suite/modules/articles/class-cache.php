<?php




defined( 'ABSPATH' ) || exit;

class Navia_MCP_Cache {





	public static function purge( $post_id = 0 ) {
		if ( class_exists( 'NAS_Cache' ) ) {
			return NAS_Cache::purge( (int) $post_id );
		}
		$done    = array();
		$post_id = (int) $post_id;


		if ( $post_id && function_exists( 'w3tc_flush_post' ) ) {
			w3tc_flush_post( $post_id );
			$done[] = 'W3 Total Cache';
		} elseif ( ! $post_id && function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
			$done[] = 'W3 Total Cache';
		}


		if ( defined( 'LSCWP_V' ) ) {
			if ( $post_id ) {
				do_action( 'litespeed_purge_post', $post_id );
			} else {
				do_action( 'litespeed_purge_all' );
			}
			$done[] = 'LiteSpeed Cache';
		}


		if ( $post_id && function_exists( 'rocket_clean_post' ) ) {
			rocket_clean_post( $post_id );
			$done[] = 'WP Rocket';
		} elseif ( ! $post_id && function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
			$done[] = 'WP Rocket';
		}


		if ( $post_id && function_exists( 'wp_cache_post_change' ) ) {
			wp_cache_post_change( $post_id );
			$done[] = 'WP Super Cache';
		} elseif ( ! $post_id && function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$done[] = 'WP Super Cache';
		}


		if ( class_exists( 'Cache_Enabler' ) ) {
			if ( $post_id ) {
				do_action( 'cache_enabler_clear_page_cache_by_post', $post_id );
			} else {
				do_action( 'cache_enabler_clear_complete_cache' );
			}
			$done[] = 'Cache Enabler';
		}


		if ( class_exists( 'WpFastestCache' ) ) {
			if ( $post_id ) {
				do_action( 'wpfc_clear_post_cache_by_id', false, $post_id );
			} else {
				do_action( 'wpfc_clear_all_cache' );
			}
			$done[] = 'WP Fastest Cache';
		}


		if ( ! $post_id && did_action( 'elementor/loaded' ) && class_exists( '\Elementor\Plugin' ) ) {
			$plugin = \Elementor\Plugin::$instance;
			if ( isset( $plugin->files_manager ) && method_exists( $plugin->files_manager, 'clear_cache' ) ) {
				$plugin->files_manager->clear_cache();
				$done[] = 'Elementor CSS';
			}
		}

		if ( $post_id ) {
			clean_post_cache( $post_id );
		}

		return $done;
	}




	public static function after_write( $post_id ) {
		if ( ! Navia_MCP_Settings::get( 'cache_auto_purge' ) || ! Navia_MCP_Settings::module_on( 'cache' ) ) {
			return array();
		}
		return self::purge( $post_id );
	}
}
