<?php





defined( 'ABSPATH' ) || exit;

class Navia_MCP_Crypto {

	const PREFIX = 'nvx1:';

	private static function key() {
		return sodium_crypto_generichash( wp_salt( 'auth' ) . '|navia-wp-mcp', '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
	}

	public static function available() {
		return function_exists( 'sodium_crypto_secretbox' );
	}

	public static function encrypt( $plain ) {
		$plain = (string) $plain;
		if ( '' === $plain ) {
			return '';
		}
		if ( ! self::available() ) {
			return 'b64:' . base64_encode( $plain );
		}
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return self::PREFIX . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, self::key() ) );
	}

	public static function decrypt( $stored ) {
		$stored = (string) $stored;
		if ( '' === $stored ) {
			return '';
		}
		if ( 0 === strpos( $stored, 'b64:' ) ) {
			return (string) base64_decode( substr( $stored, 4 ) );
		}
		if ( 0 !== strpos( $stored, self::PREFIX ) || ! self::available() ) {
			return '';
		}
		$raw = base64_decode( substr( $stored, strlen( self::PREFIX ) ), true );
		if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$nonce  = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$cipher = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$plain  = sodium_crypto_secretbox_open( $cipher, $nonce, self::key() );
		return false === $plain ? '' : $plain;
	}




	public static function mask( $stored ) {
		$plain = self::decrypt( $stored );
		if ( '' === $plain ) {
			return '';
		}
		return str_repeat( '•', 8 ) . substr( $plain, -4 );
	}
}
