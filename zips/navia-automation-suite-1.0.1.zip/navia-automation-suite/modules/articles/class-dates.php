<?php












defined( 'ABSPATH' ) || exit;

class Navia_MCP_Dates {






	public static function parse_local( $value, $field ) {
		$tz = Navia_MCP_Settings::schedule_tz();
		$v  = trim( (string) $value );
		foreach ( array( '!Y-m-d H:i:s', '!Y-m-d H:i' ) as $fmt ) {
			$d = DateTime::createFromFormat( $fmt, $v, $tz );
			if ( $d && $d->format( substr( $fmt, 1 ) ) === $v ) {
				return $d;
			}
		}
		return new WP_Error( 'navia_bad_date', sprintf( '%s must be "YYYY-MM-DD HH:MM" in %s.', $field, $tz->getName() ) );
	}




	private static function wp_pair( DateTime $when ) {
		$wp  = ( clone $when )->setTimezone( wp_timezone() );
		$utc = ( clone $when )->setTimezone( new DateTimeZone( 'UTC' ) );
		return array( $wp->format( 'Y-m-d H:i:s' ), $utc->format( 'Y-m-d H:i:s' ) );
	}

	private static function to_local( $gmt ) {
		$d = new DateTime( $gmt, new DateTimeZone( 'UTC' ) );
		return $d->setTimezone( Navia_MCP_Settings::schedule_tz() )->format( 'Y-m-d H:i' );
	}




	public static function flush_sitemap() {
		if ( class_exists( '\RankMath\Sitemap\Cache' ) && method_exists( '\RankMath\Sitemap\Cache', 'invalidate_storage' ) ) {
			\RankMath\Sitemap\Cache::invalidate_storage();
			return true;
		}
		return false;
	}





	public static function set_post_dates( array $input ) {
		global $wpdb;
		$post = get_post( (int) $input['id'] );
		if ( ! $post || 'post' !== $post->post_type ) {
			return new WP_Error( 'navia_not_found', sprintf( 'Post %d not found.', (int) $input['id'] ) );
		}
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new WP_Error( 'navia_forbidden', sprintf( 'The connected user cannot edit post %d.', $post->ID ) );
		}
		if ( ! in_array( $post->post_status, array( 'publish', 'future' ), true ) ) {
			return new WP_Error( 'navia_not_published', 'Dates can only be set on published or scheduled posts.' );
		}
		if ( empty( $input['published'] ) && empty( $input['modified'] ) ) {
			return new WP_Error( 'navia_dates_input', 'Give published, modified, or both.' );
		}

		$now    = new DateTime( 'now', Navia_MCP_Settings::schedule_tz() );
		$before = array(
			'published' => self::to_local( $post->post_date_gmt ),
			'modified'  => self::to_local( $post->post_modified_gmt ),
		);

		$published = null;
		if ( ! empty( $input['published'] ) ) {
			$published = self::parse_local( $input['published'], 'published' );
			if ( is_wp_error( $published ) ) {
				return $published;
			}
			if ( 'publish' === $post->post_status && $published > $now ) {
				return new WP_Error( 'navia_future_date', 'A published post cannot get a publication date in the future. Use schedule-posts.' );
			}
			if ( $published < $now && ! Navia_MCP_Settings::get( 'sched_allow_past' ) ) {
				return new WP_Error( 'navia_past_off', 'Past publication dates are off. Tick "Allow past dates" in Navia Suite > Articles (MCP) > Scheduling.' );
			}
		} else {
			$published = new DateTime( $post->post_date_gmt, new DateTimeZone( 'UTC' ) );
			$published->setTimezone( Navia_MCP_Settings::schedule_tz() );
		}

		$modified = null;
		if ( ! empty( $input['modified'] ) ) {
			$modified = self::parse_local( $input['modified'], 'modified' );
			if ( is_wp_error( $modified ) ) {
				return $modified;
			}
			if ( $modified < $published ) {
				return new WP_Error( 'navia_modified_before', sprintf( 'modified (%s) cannot be before the publication date (%s).', $modified->format( 'Y-m-d H:i' ), $published->format( 'Y-m-d H:i' ) ) );
			}
			if ( $modified > $now ) {
				return new WP_Error( 'navia_modified_future', 'modified cannot be in the future.' );
			}
		} else {

			$modified = new DateTime( $post->post_modified_gmt, new DateTimeZone( 'UTC' ) );
			$modified->setTimezone( Navia_MCP_Settings::schedule_tz() );
			if ( $modified < $published ) {
				$modified = clone $published;
			}
		}

		list( $p_local, $p_gmt ) = self::wp_pair( $published );
		list( $m_local, $m_gmt ) = self::wp_pair( $modified );

		$wpdb->update(
			$wpdb->posts,
			array(
				'post_date'         => $p_local,
				'post_date_gmt'     => $p_gmt,
				'post_modified'     => $m_local,
				'post_modified_gmt' => $m_gmt,
			),
			array( 'ID' => $post->ID ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
		clean_post_cache( $post->ID );

		$purged = Navia_MCP_Cache::purge( $post->ID );
		if ( self::flush_sitemap() ) {
			$purged[] = 'Rank Math sitemap';
		}

		$after = array(
			'published' => $published->format( 'Y-m-d H:i' ),
			'modified'  => $modified->format( 'Y-m-d H:i' ),
		);
		Navia_MCP_Log::add( 'navia/set-post-dates', $post->ID, sprintf( 'Dates of "%s": published %s, modified %s', $post->post_title, $after['published'], $after['modified'] ), array( 'before' => $before, 'after' => $after ) );

		return array(
			'id'       => (int) $post->ID,
			'title'    => get_the_title( $post->ID ),
			'timezone' => Navia_MCP_Settings::schedule_tz()->getName(),
			'before'   => $before,
			'after'    => $after,
			'purged'   => $purged,
			'note'     => 'Saving this post again in the editor sets the modified date to that moment.',
		);
	}







	public static function move_media( array $input ) {
		global $wpdb;
		$id  = (int) $input['attachment_id'];
		$att = get_post( $id );
		if ( ! $att || 'attachment' !== $att->post_type ) {
			return new WP_Error( 'navia_not_found', sprintf( 'Attachment %d not found.', $id ) );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'navia_forbidden', sprintf( 'The connected user cannot edit attachment %d.', $id ) );
		}
		$year  = (int) $input['year'];
		$month = (int) $input['month'];
		if ( $year < 2000 || $year > 2100 || $month < 1 || $month > 12 ) {
			return new WP_Error( 'navia_bad_folder', 'year must be 2000 to 2100 and month 1 to 12.' );
		}

		$att_date = null;
		if ( ! empty( $input['date'] ) ) {
			$att_date = self::parse_local( $input['date'], 'date' );
			if ( is_wp_error( $att_date ) ) {
				return $att_date;
			}
			if ( (int) $att_date->format( 'Y' ) !== $year || (int) $att_date->format( 'n' ) !== $month ) {
				return new WP_Error( 'navia_bad_date', 'date must be inside the target year and month.' );
			}
		}

		$uploads = wp_get_upload_dir();
		$old_rel = (string) get_post_meta( $id, '_wp_attached_file', true );
		if ( '' === $old_rel || 0 === strpos( $old_rel, '/' ) || preg_match( '#^[a-z]+://#i', $old_rel ) ) {
			return new WP_Error( 'navia_media_path', 'This attachment is not stored inside the uploads folder.' );
		}
		$old_dir_rel = trim( dirname( $old_rel ), '/.' );
		$new_dir_rel = sprintf( '%04d/%02d', $year, $month );
		if ( $old_dir_rel === $new_dir_rel ) {
			return array(
				'attachment_id' => $id,
				'moved'         => false,
				'folder'        => $new_dir_rel,
				'note'          => 'Already in that folder.',
			);
		}

		$old_dir = trailingslashit( $uploads['basedir'] ) . ( '' !== $old_dir_rel ? $old_dir_rel . '/' : '' );
		$new_dir = trailingslashit( $uploads['basedir'] ) . $new_dir_rel . '/';
		if ( ! wp_mkdir_p( $new_dir ) ) {
			return new WP_Error( 'navia_mkdir', 'Could not create ' . $new_dir_rel . ' in uploads.' );
		}

		$meta  = wp_get_attachment_metadata( $id );
		$meta  = is_array( $meta ) ? $meta : array();
		$files = array( basename( $old_rel ) );
		if ( ! empty( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
			foreach ( $meta['sizes'] as $size ) {
				if ( ! empty( $size['file'] ) ) {
					$files[] = basename( $size['file'] );
				}
			}
		}
		if ( ! empty( $meta['original_image'] ) ) {
			$files[] = basename( $meta['original_image'] );
		}
		$files = array_values( array_unique( $files ) );


		foreach ( $files as $f ) {
			if ( ! file_exists( $old_dir . $f ) ) {
				return new WP_Error( 'navia_media_missing', sprintf( 'File %s is missing from %s. Nothing was moved.', $f, $old_dir_rel ) );
			}
			if ( file_exists( $new_dir . $f ) ) {
				return new WP_Error( 'navia_media_exists', sprintf( 'A file named %s already exists in %s. Nothing was moved.', $f, $new_dir_rel ) );
			}
		}

		$moved = array();
		foreach ( $files as $f ) {
			if ( ! @rename( $old_dir . $f, $new_dir . $f ) ) {
				foreach ( $moved as $m ) {
					@rename( $new_dir . $m, $old_dir . $m );
				}
				return new WP_Error( 'navia_media_move', sprintf( 'Could not move %s. Everything was put back.', $f ) );
			}
			$moved[] = $f;
		}


		$new_rel = $new_dir_rel . '/' . basename( $old_rel );
		update_post_meta( $id, '_wp_attached_file', $new_rel );
		if ( isset( $meta['file'] ) ) {
			$meta['file'] = $new_rel;
			wp_update_attachment_metadata( $id, $meta );
		}
		$old_base = trailingslashit( $uploads['baseurl'] ) . ( '' !== $old_dir_rel ? $old_dir_rel . '/' : '' );
		$new_base = trailingslashit( $uploads['baseurl'] ) . $new_dir_rel . '/';
		$att_row  = array( 'guid' => $new_base . basename( $old_rel ) );
		$formats  = array( '%s' );
		if ( $att_date ) {
			list( $a_local, $a_gmt ) = self::wp_pair( $att_date );
			$att_row += array(
				'post_date'         => $a_local,
				'post_date_gmt'     => $a_gmt,
				'post_modified'     => $a_local,
				'post_modified_gmt' => $a_gmt,
			);
			$formats = array( '%s', '%s', '%s', '%s', '%s' );
		}
		$wpdb->update( $wpdb->posts, $att_row, array( 'ID' => $id ), $formats, array( '%d' ) );
		clean_post_cache( $id );



		$same_length   = strlen( $old_base ) === strlen( $new_base );
		$touched_posts = array();
		$meta_rows     = 0;
		foreach ( $files as $f ) {
			$pairs = array(
				array( $old_base . $f, $new_base . $f ),
				array( str_replace( '/', '\/', $old_base . $f ), str_replace( '/', '\/', $new_base . $f ) ),
			);
			foreach ( $pairs as $pair ) {
				list( $from, $to ) = $pair;
				$like = '%' . $wpdb->esc_like( $from ) . '%';
				$ids  = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s", $like ) );
				if ( $ids ) {
					$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s) WHERE post_content LIKE %s", $from, $to, $like ) );
					$touched_posts = array_merge( $touched_posts, array_map( 'intval', $ids ) );
				}
				$sql = "UPDATE {$wpdb->postmeta} SET meta_value = REPLACE(meta_value, %s, %s) WHERE meta_value LIKE %s";
				if ( ! $same_length ) {
					$sql .= " AND meta_value NOT LIKE 'a:%%' AND meta_value NOT LIKE 'O:%%' AND meta_value NOT LIKE 's:%%'";
				}
				$meta_rows += (int) $wpdb->query( $wpdb->prepare( $sql, $from, $to, $like ) );
			}
		}
		$touched_posts = array_values( array_unique( $touched_posts ) );
		foreach ( $touched_posts as $pid ) {
			clean_post_cache( $pid );
		}
		if ( function_exists( 'wp_cache_supports' ) && wp_cache_supports( 'flush_group' ) ) {
			wp_cache_flush_group( 'post_meta' );
		}

		$purged = Navia_MCP_Cache::purge( 0 );
		if ( self::flush_sitemap() ) {
			$purged[] = 'Rank Math sitemap';
		}

		Navia_MCP_Log::add(
			'navia/move-media-folder',
			$id,
			sprintf( 'Moved attachment %d from %s to %s', $id, $old_dir_rel, $new_dir_rel ),
			array(
				'files'         => $files,
				'posts_updated' => $touched_posts,
				'meta_rows'     => $meta_rows,
			)
		);

		return array(
			'attachment_id' => $id,
			'moved'         => true,
			'from'          => $old_dir_rel,
			'to'            => $new_dir_rel,
			'files'         => $files,
			'url'           => wp_get_attachment_url( $id ),
			'posts_updated' => $touched_posts,
			'meta_rows'     => $meta_rows,
			'purged'        => $purged,
		);
	}
}
