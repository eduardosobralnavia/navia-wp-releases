<?php





defined( 'ABSPATH' ) || exit;

class Navia_MCP_Guard {








	public static function permission( $module, $cap ) {
		return function () use ( $module, $cap ) {
			if ( ! is_user_logged_in() ) {
				return new WP_Error( 'navia_not_logged_in', 'The request is not authenticated as a WordPress user.' );
			}
			if ( ! Navia_MCP_Settings::site_enabled() ) {
				return new WP_Error( 'navia_site_disabled', 'The Articles module of Navia Automation Suite is not enabled for this site. A super admin enables it in Network Admin > Navia Suite > Articles (MCP), or the site admin in Navia Suite > Modules.' );
			}
			if ( $module && ! Navia_MCP_Settings::module_on( $module ) ) {
				return new WP_Error( 'navia_module_off', sprintf( 'The "%s" option is switched off in Navia Suite > Articles (MCP) on this site.', $module ) );
			}
			if ( $cap && ! current_user_can( $cap ) ) {
				return new WP_Error( 'navia_forbidden', sprintf( 'The connected user lacks the "%s" capability on this site.', $cap ) );
			}
			return true;
		};
	}






	public static function write_allowed() {
		$limit = max( 1, (int) Navia_MCP_Settings::get( 'rate_limit' ) );
		$key   = 'navia_mcp_rl_' . get_current_user_id() . '_' . gmdate( 'YmdHi' );
		$count = (int) get_transient( $key );
		if ( $count >= $limit ) {
			return new WP_Error( 'navia_rate_limited', sprintf( 'Write limit of %d per minute reached. Wait a minute and retry. The limit is set in Navia Suite > Articles (MCP).', $limit ) );
		}
		set_transient( $key, $count + 1, 2 * MINUTE_IN_SECONDS );
		return true;
	}




	public static function allowed_statuses() {
		$mode = Navia_MCP_Settings::get( 'publish_mode' );
		if ( 'all' === $mode ) {
			return array( 'draft', 'pending', 'future', 'publish' );
		}
		if ( 'schedule' === $mode ) {
			return array( 'draft', 'pending', 'future' );
		}
		return array( 'draft', 'pending' );
	}

	public static function can_schedule() {
		return in_array( 'future', self::allowed_statuses(), true );
	}
}
