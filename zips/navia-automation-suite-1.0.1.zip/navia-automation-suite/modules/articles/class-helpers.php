<?php




defined( 'ABSPATH' ) || exit;

class Navia_MCP_Helpers {



	public static function pll() {
		return function_exists( 'pll_set_post_language' ) && function_exists( 'pll_languages_list' );
	}

	public static function languages() {
		if ( ! self::pll() ) {
			return array();
		}
		return (array) pll_languages_list( array( 'fields' => 'slug' ) );
	}

	public static function default_language() {
		return function_exists( 'pll_default_language' ) ? (string) pll_default_language() : '';
	}

	public static function valid_lang( $lang ) {
		return '' === $lang || in_array( $lang, self::languages(), true );
	}

	public static function post_lang( $post_id ) {
		return function_exists( 'pll_get_post_language' ) ? (string) pll_get_post_language( $post_id ) : '';
	}

	public static function post_translations( $post_id ) {
		return function_exists( 'pll_get_post_translations' ) ? array_map( 'intval', (array) pll_get_post_translations( $post_id ) ) : array();
	}

	public static function term_lang( $term_id ) {
		return function_exists( 'pll_get_term_language' ) ? (string) pll_get_term_language( $term_id ) : '';
	}

	public static function term_translations( $term_id ) {
		return function_exists( 'pll_get_term_translations' ) ? array_map( 'intval', (array) pll_get_term_translations( $term_id ) ) : array();
	}



	public static function term_summary( $term ) {
		return array(
			'id'           => (int) $term->term_id,
			'name'         => $term->name,
			'slug'         => $term->slug,
			'taxonomy'     => $term->taxonomy,
			'count'        => (int) $term->count,
			'parent'       => (int) $term->parent,
			'description'  => $term->description,
			'lang'         => self::term_lang( $term->term_id ),
			'translations' => (object) self::term_translations( $term->term_id ),
			'url'          => get_term_link( $term ),
		);
	}

	public static function post_terms( $post_id, $taxonomy ) {
		$terms = wp_get_object_terms( $post_id, $taxonomy );
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		return array_map(
			function ( $t ) {
				return array(
					'id'   => (int) $t->term_id,
					'name' => $t->name,
					'slug' => $t->slug,
				);
			},
			$terms
		);
	}

	public static function post_summary( WP_Post $post ) {
		$tz = Navia_MCP_Settings::schedule_tz();
		$gmt = ( '0000-00-00 00:00:00' !== $post->post_date_gmt ) ? $post->post_date_gmt : get_gmt_from_date( $post->post_date );
		$local = new DateTime( $gmt, new DateTimeZone( 'UTC' ) );
		$local->setTimezone( $tz );
		return array(
			'id'            => (int) $post->ID,
			'type'          => $post->post_type,
			'title'         => get_the_title( $post ),
			'slug'          => $post->post_name,
			'status'        => $post->post_status,
			'date_local'    => $local->format( 'Y-m-d H:i' ),
			'date_timezone' => $tz->getName(),
			'date_gmt'      => $gmt,
			'modified_local' => ( '0000-00-00 00:00:00' !== $post->post_modified_gmt ) ? ( new DateTime( $post->post_modified_gmt, new DateTimeZone( 'UTC' ) ) )->setTimezone( $tz )->format( 'Y-m-d H:i' ) : '',
			'author'        => array(
				'id'   => (int) $post->post_author,
				'name' => get_the_author_meta( 'display_name', $post->post_author ),
			),
			'lang'          => self::post_lang( $post->ID ),
			'translations'  => (object) self::post_translations( $post->ID ),
			'categories'    => 'post' === $post->post_type ? self::post_terms( $post->ID, 'category' ) : array(),
			'tags'          => 'post' === $post->post_type ? self::post_terms( $post->ID, 'post_tag' ) : array(),
			'featured_id'   => (int) get_post_thumbnail_id( $post ),
			'toc'           => (string) get_post_meta( $post->ID, '_navia_toc', true ),
			'url'           => 'publish' === $post->post_status ? get_permalink( $post ) : '',
			'preview_url'   => 'publish' === $post->post_status ? '' : get_preview_post_link( $post ),
			'edit_url'      => get_edit_post_link( $post->ID, 'raw' ),
			'created_by_navia' => (bool) get_post_meta( $post->ID, '_navia_created', true ),
		);
	}



	public static function has_dash( $text ) {
		return (bool) preg_match( '/[\x{2013}\x{2014}]/u', (string) $text );
	}

	public static function len( $text ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $text, 'UTF-8' ) : strlen( (string) $text );
	}




	public static function content_warnings( $html ) {
		$w = array();
		if ( preg_match( '/<h1[\s>]/i', $html ) ) {
			$w[] = 'Content contains an H1. The post template already prints the title as H1.';
		}
		if ( self::has_dash( wp_strip_all_tags( $html ) ) ) {
			$w[] = 'Content contains en or em dashes.';
		}
		if ( ! preg_match( '/<table[\s>]/i', $html ) ) {
			$w[] = 'Content has no table.';
		}
		return $w;
	}

	public static function count_markers( $html ) {
		return preg_match_all( '/<!--\s*navia:img\b/i', (string) $html );
	}






	public static function resolve_author( $author_id ) {
		$author_id = (int) $author_id;
		if ( ! $author_id ) {
			$author_id = (int) Navia_MCP_Settings::get( 'default_author' );
		}
		if ( ! $author_id ) {
			return get_current_user_id();
		}
		$user = get_userdata( $author_id );
		if ( ! $user ) {
			return new WP_Error( 'navia_bad_author', sprintf( 'User %d does not exist.', $author_id ) );
		}
		if ( is_multisite() && ! is_user_member_of_blog( $author_id ) ) {
			return new WP_Error( 'navia_bad_author', sprintf( 'User %d is not a member of this site.', $author_id ) );
		}
		if ( ! user_can( $author_id, 'edit_posts' ) ) {
			return new WP_Error( 'navia_bad_author', sprintf( 'User %d cannot write posts on this site (needs at least the Author role).', $author_id ) );
		}
		if ( $author_id !== get_current_user_id() && ! current_user_can( 'edit_others_posts' ) ) {
			return new WP_Error( 'navia_forbidden', 'The connected user cannot assign posts to another author.' );
		}
		return $author_id;
	}
}
