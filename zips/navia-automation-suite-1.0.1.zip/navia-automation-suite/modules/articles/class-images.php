<?php








defined( 'ABSPATH' ) || exit;

class Navia_MCP_Images {

	const SIZES = array(
		'featured' => array( 1200, 630 ),
		'inline'   => array( 1200, 800 ),
	);

	const MARKER_RE = '/<!--\s*navia:img\b(.*?)-->/is';



	public static function compose_prompt( $scene ) {
		$s     = Navia_MCP_Settings::site();
		$parts = array( rtrim( trim( (string) $scene ), '.' ) . '.' );
		if ( trim( $s['img_style'] ) ) {
			$parts[] = trim( $s['img_style'] );
		}
		if ( trim( $s['img_palette'] ) ) {
			$parts[] = 'Colour palette: ' . trim( $s['img_palette'] ) . '.';
		}
		if ( ! empty( $s['img_no_people'] ) ) {
			$parts[] = 'The scene is empty of people: no humans, no faces, no hands, no silhouettes.';
		}
		if ( trim( $s['img_avoid'] ) ) {
			$parts[] = 'No ' . trim( $s['img_avoid'] ) . '.';
		}
		return implode( ' ', $parts );
	}









	public static function generate_attachment( array $args ) {
		$prompt = trim( (string) ( $args['prompt'] ?? '' ) );
		$alt    = trim( (string) ( $args['alt'] ?? '' ) );
		$kind   = isset( self::SIZES[ $args['kind'] ?? '' ] ) ? $args['kind'] : 'inline';
		if ( '' === $prompt ) {
			return new WP_Error( 'navia_img_prompt', 'An image prompt is required.' );
		}
		if ( '' === $alt ) {
			return new WP_Error( 'navia_img_alt', 'Alt text is required for every image.' );
		}

		$result = Navia_MCP_Cloudflare::generate( self::compose_prompt( $prompt ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$base = sanitize_title( (string) ( $args['filename'] ?? '' ) );
		if ( '' === $base ) {
			$base = sanitize_title( wp_trim_words( $alt, 6, '' ) );
		}
		if ( '' === $base ) {
			$base = 'image';
		}

		$saved = self::save_bytes( $result['bytes'], $base, self::SIZES[ $kind ] );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$id = self::insert_attachment( $saved, $alt, (int) ( $args['post_id'] ?? 0 ) );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		update_post_meta( $id, '_navia_generated', array( 'provider' => Navia_MCP_Cloudflare::ID, 'prompt' => $prompt, 'kind' => $kind ) );

		return array(
			'id'       => (int) $id,
			'url'      => wp_get_attachment_url( $id ),
			'width'    => (int) $saved['width'],
			'height'   => (int) $saved['height'],
			'alt'      => $alt,
			'provider' => Navia_MCP_Cloudflare::ID,
			'fallback' => false,
		);
	}




	private static function save_bytes( $bytes, $base, array $size ) {
		$tmp = wp_tempnam( 'navia-img' );
		if ( ! $tmp || false === file_put_contents( $tmp, $bytes ) ) {
			return new WP_Error( 'navia_img_tmp', 'Could not write a temporary file.' );
		}

		$editor = wp_get_image_editor( $tmp );
		if ( is_wp_error( $editor ) ) {
			wp_delete_file( $tmp );
			return $editor;
		}

		list( $tw, $th ) = $size;
		$src = $editor->get_size();
		$sw  = (int) $src['width'];
		$sh  = (int) $src['height'];
		if ( $sw < 10 || $sh < 10 ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'navia_img_size', 'The generated image has no usable size.' );
		}

		$target_ratio = $tw / $th;
		if ( $sw / $sh > $target_ratio ) {
			$cw = (int) round( $sh * $target_ratio );
			$ch = $sh;
		} else {
			$cw = $sw;
			$ch = (int) round( $sw / $target_ratio );
		}
		$cx   = (int) floor( ( $sw - $cw ) / 2 );
		$cy   = (int) floor( ( $sh - $ch ) / 2 );
		$crop = $editor->crop( $cx, $cy, $cw, $ch, $tw, $th );
		if ( is_wp_error( $crop ) ) {
			wp_delete_file( $tmp );
			return $crop;
		}
		$editor->set_quality( 82 );

		$mime = $editor::supports_mime_type( 'image/webp' ) ? 'image/webp' : 'image/jpeg';
		$ext  = 'image/webp' === $mime ? 'webp' : 'jpg';

		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'navia_img_uploads', $uploads['error'] );
		}
		$filename = wp_unique_filename( $uploads['path'], $base . '.' . $ext );
		$saved    = $editor->save( trailingslashit( $uploads['path'] ) . $filename, $mime );
		wp_delete_file( $tmp );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return $saved;
	}

	private static function insert_attachment( array $saved, $alt, $parent ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$path = $saved['path'];
		$id   = wp_insert_attachment(
			array(
				'post_mime_type' => $saved['mime-type'],
				'post_title'     => wp_trim_words( $alt, 12, '' ),
				'post_content'   => '',
				'post_status'    => 'inherit',
			),
			$path,
			$parent,
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$meta = wp_generate_attachment_metadata( $id, $path );
		wp_update_attachment_metadata( $id, $meta );
		update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
		return (int) $id;
	}








	public static function library_pool( $post_id, array $extra_keywords = array() ) {
		$keywords = $extra_keywords;
		foreach ( wp_get_object_terms( $post_id, 'category' ) as $term ) {
			if ( ! is_wp_error( $term ) && 'uncategorized' !== $term->slug && 0 !== strpos( $term->slug, 'uncategorized' ) ) {
				$keywords[] = $term->name;
				$keywords[] = str_replace( '-', ' ', $term->slug );
			}
		}
		$keywords = array_values( array_unique( array_filter( array_map( 'trim', $keywords ) ) ) );
		if ( ! $keywords ) {
			return array();
		}

		$ids = array();

		$meta_query = array( 'relation' => 'OR' );
		foreach ( $keywords as $kw ) {
			$meta_query[] = array(
				'key'     => '_wp_attachment_image_alt',
				'value'   => $kw,
				'compare' => 'LIKE',
			);
		}
		$base_args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'posts_per_page' => 200,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'lang'           => '',
		);
		$ids = array_merge( $ids, get_posts( $base_args + array( 'meta_query' => $meta_query ) ) );
		foreach ( $keywords as $kw ) {
			$ids = array_merge( $ids, get_posts( $base_args + array( 's' => $kw ) ) );
		}
		$ids = array_values( array_unique( array_map( 'intval', $ids ) ) );


		$ids = array_values(
			array_filter(
				$ids,
				function ( $id ) {
					$m = wp_get_attachment_metadata( $id );
					return ! empty( $m['width'] ) && (int) $m['width'] >= 700;
				}
			)
		);
		if ( ! $ids ) {
			return array();
		}


		$recent = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'future', 'draft', 'pending' ),
				'posts_per_page' => 12,
				'post__not_in'   => array( (int) $post_id ),
				'lang'           => '',
			)
		);
		$used = array();
		foreach ( $recent as $p ) {
			$used[] = (int) get_post_thumbnail_id( $p );
			if ( preg_match_all( '/wp-image-(\d+)/', $p->post_content, $m ) ) {
				$used = array_merge( $used, array_map( 'intval', $m[1] ) );
			}
		}
		$fresh = array_values( array_diff( $ids, $used ) );
		$stale = array_values( array_intersect( $ids, $used ) );
		shuffle( $fresh );
		shuffle( $stale );
		return array_merge( $fresh, $stale );
	}

	public static function attachment_result( $id ) {
		$meta = wp_get_attachment_metadata( $id );
		return array(
			'id'       => (int) $id,
			'url'      => wp_get_attachment_url( $id ),
			'width'    => (int) ( $meta['width'] ?? 0 ),
			'height'   => (int) ( $meta['height'] ?? 0 ),
			'alt'      => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'provider' => 'library',
			'fallback' => true,
		);
	}

	public static function figure_html( array $img ) {
		$alt = '' !== $img['alt'] ? $img['alt'] : '';
		$wh  = $img['width'] && $img['height'] ? sprintf( ' width="%d" height="%d"', $img['width'], $img['height'] ) : '';
		return sprintf(
			'<figure class="navia-figure"><img class="wp-image-%1$d" src="%2$s" alt="%3$s"%4$s loading="lazy" decoding="async" /></figure>',
			(int) $img['id'],
			esc_url( $img['url'] ),
			esc_attr( $alt ),
			$wh
		);
	}



	public static function parse_markers( $html ) {
		$out = array();
		if ( ! preg_match_all( self::MARKER_RE, $html, $m, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			return $out;
		}
		foreach ( $m as $i => $match ) {
			$attrs = html_entity_decode( $match[1][0], ENT_QUOTES, 'UTF-8' );
			$get   = function ( $name ) use ( $attrs ) {
				return preg_match( '/' . $name . '\s*=\s*"([^"]*)"/i', $attrs, $mm ) ? trim( $mm[1] ) : '';
			};
			$out[] = array(
				'index'  => $i,
				'offset' => $match[0][1],
				'length' => strlen( $match[0][0] ),
				'prompt' => $get( 'prompt' ),
				'alt'    => $get( 'alt' ),
			);
		}
		return $out;
	}




	private static function valid_markers( $html, array $markers ) {
		$first_h2 = stripos( $html, '<h2' );
		$spans    = array();
		if ( preg_match_all( '#<table\b.*?</table>#is', $html, $tm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $tm[0] as $t ) {
				$spans[] = array( $t[1], $t[1] + strlen( $t[0] ) );
			}
		}
		$valid = array();
		foreach ( $markers as $mk ) {
			if ( '' === $mk['prompt'] || '' === $mk['alt'] ) {
				continue;
			}
			if ( false === $first_h2 || $mk['offset'] < $first_h2 ) {
				continue;
			}
			$ok = true;
			foreach ( $spans as $sp ) {
				if ( $mk['offset'] >= $sp[0] && $mk['offset'] <= $sp[1] ) {
					$ok = false;
					break;
				}

				$near = $mk['offset'] < $sp[0] ? substr( $html, $mk['offset'] + $mk['length'], max( 0, $sp[0] - $mk['offset'] - $mk['length'] ) ) : substr( $html, $sp[1], max( 0, $mk['offset'] - $sp[1] ) );
				if ( Navia_MCP_Helpers::len( preg_replace( '/\s+/u', '', wp_strip_all_tags( $near ) ) ) < 40 ) {
					$ok = false;
					break;
				}
			}
			if ( $ok ) {
				$valid[] = $mk;
			}
		}
		return $valid;
	}

	private static function far_enough( $html, $a, $b ) {
		$start   = min( $a['offset'], $b['offset'] );
		$end     = max( $a['offset'], $b['offset'] );
		$between = substr( $html, $start, $end - $start );
		if ( preg_match( '/<h2[\s>]/i', $between ) ) {
			return true;
		}
		return Navia_MCP_Helpers::len( trim( wp_strip_all_tags( preg_replace( self::MARKER_RE, '', $between ) ) ) ) >= 600;
	}








	public static function process_post( $post_id, array $args ) {
		$post = get_post( $post_id );
		if ( ! $post || 'post' !== $post->post_type ) {
			return new WP_Error( 'navia_not_found', 'Post not found.' );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 );
		}

		$s        = Navia_MCP_Settings::site();
		$min      = isset( $args['min'] ) ? (int) $args['min'] : (int) $s['img_min'];
		$max      = isset( $args['max'] ) ? (int) $args['max'] : (int) $s['img_max'];
		$min      = max( 0, min( 8, $min ) );
		$max      = max( $min, min( 8, $max ) );
		$html     = $post->post_content;
		$markers  = self::parse_markers( $html );
		$valid    = self::valid_markers( $html, $markers );
		$warnings = array();
		$log      = array();

		if ( count( $markers ) && count( $valid ) < $max ) {
			$warnings[] = sprintf( 'Only %d of %d markers are in valid positions (after the first H2, away from tables).', count( $valid ), count( $markers ) );
		}


		$target = wp_rand( $min, $max );
		$pool   = $valid;
		shuffle( $pool );
		$chosen = array();
		foreach ( $pool as $cand ) {
			if ( count( $chosen ) >= $target ) {
				break;
			}
			$fits = true;
			foreach ( $chosen as $c ) {
				if ( ! self::far_enough( $html, $cand, $c ) ) {
					$fits = false;
					break;
				}
			}
			if ( $fits ) {
				$chosen[] = $cand;
			}
		}
		if ( count( $chosen ) < $target ) {
			$warnings[] = sprintf( 'Drew %d inline images but only %d markers are far enough apart.', $target, count( $chosen ) );
		}
		usort(
			$chosen,
			function ( $a, $b ) {
				return $a['offset'] <=> $b['offset'];
			}
		);

		$library     = null;
		$library_pos = 0;
		$take_library = function () use ( &$library, &$library_pos, $post_id, $s ) {
			if ( empty( $s['img_fallback_library'] ) ) {
				return null;
			}
			if ( null === $library ) {
				$library = self::library_pool( $post_id );
			}
			if ( ! $library ) {
				return null;
			}
			$id = $library[ $library_pos % count( $library ) ];
			++$library_pos;
			return self::attachment_result( $id );
		};

		$slug = $post->post_name ? $post->post_name : sanitize_title( $post->post_title );


		$featured = null;
		$want_featured = ! isset( $args['featured'] ) || $args['featured'];
		if ( $want_featured && ( ! has_post_thumbnail( $post ) || ! empty( $args['replace_featured'] ) ) ) {
			$fp = trim( (string) ( $args['featured_prompt'] ?? '' ) );
			$fa = trim( (string) ( $args['featured_alt'] ?? '' ) );
			if ( '' === $fp && $markers ) {
				$fp = $markers[0]['prompt'];
				$fa = '' === $fa ? $markers[0]['alt'] : $fa;
			}
			if ( '' === $fa ) {
				$fa = get_the_title( $post );
			}
			if ( '' !== $fp ) {
				$res = self::generate_attachment(
					array(
						'prompt'   => $fp,
						'alt'      => $fa,
						'kind'     => 'featured',
						'filename' => $slug,
						'post_id'  => $post_id,
					)
				);
				if ( is_wp_error( $res ) ) {
					$log[] = 'Featured: ' . $res->get_error_message();
					$res   = $take_library();
				}
				if ( $res ) {
					$featured = $res;
					set_post_thumbnail( $post_id, $res['id'] );
				} else {
					$warnings[] = 'No featured image: generation failed and no library image matched.';
				}
			} else {
				$warnings[] = 'No featured image: give featured_prompt or add markers.';
			}
		}


		$placed = array();
		$n      = 1;
		foreach ( $chosen as $mk ) {
			$res = self::generate_attachment(
				array(
					'prompt'   => $mk['prompt'],
					'alt'      => $mk['alt'],
					'kind'     => 'inline',
					'filename' => $slug . '-' . ( ++$n ),
					'post_id'  => $post_id,
				)
			);
			if ( is_wp_error( $res ) ) {
				$log[] = 'Marker ' . $mk['index'] . ': ' . $res->get_error_message();
				$res   = $take_library();
			}
			if ( $res ) {
				$placed[ $mk['index'] ] = $res;
			}
		}


		if ( $want_featured && ! $featured && ! has_post_thumbnail( $post ) && $placed ) {
			$first = reset( $placed );
			set_post_thumbnail( $post_id, $first['id'] );
			$featured   = $first;
			$warnings[] = 'Featured image reused from the first inline image.';
		}


		$new = $html;
		foreach ( array_reverse( $markers ) as $mk ) {
			$replacement = isset( $placed[ $mk['index'] ] ) ? self::figure_html( $placed[ $mk['index'] ] ) : '';
			$new         = substr_replace( $new, $replacement, $mk['offset'], $mk['length'] );
		}
		$new = preg_replace( '#<p>\s*(<figure class="navia-figure">.*?</figure>)\s*</p>#is', '$1', $new );
		$new = preg_replace( '#<p>\s*</p>#i', '', $new );

		if ( $new !== $html ) {
			wp_update_post(
				array(
					'ID'           => $post_id,
					'post_content' => wp_slash( $new ),
				)
			);
		}

		$fallbacks = count(
			array_filter(
				$placed,
				function ( $p ) {
					return ! empty( $p['fallback'] );
				}
			)
		) + ( $featured && ! empty( $featured['fallback'] ) ? 1 : 0 );

		return array(
			'post_id'        => (int) $post_id,
			'featured'       => $featured,
			'inline_drawn'   => $target,
			'inline_placed'  => array_values( $placed ),
			'markers_found'  => count( $markers ),
			'markers_valid'  => count( $valid ),
			'fallbacks_used' => $fallbacks,
			'warnings'       => $warnings,
			'errors'         => $log,
		);
	}
}
