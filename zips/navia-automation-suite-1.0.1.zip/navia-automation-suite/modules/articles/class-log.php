<?php




defined( 'ABSPATH' ) || exit;

class Navia_MCP_Log {

	const DB_VERSION = '1';
	const CRON_HOOK  = 'navia_mcp_log_cleanup';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'maybe_install' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'cleanup' ) );
		add_action(
			'init',
			function () {
				if ( Navia_MCP_Settings::site_enabled() && ! wp_next_scheduled( self::CRON_HOOK ) ) {
					wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
				}
			}
		);
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'navia_mcp_log';
	}

	public static function maybe_install() {
		if ( get_option( 'navia_mcp_db_version' ) === self::DB_VERSION ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				created_at datetime NOT NULL,
				user_id bigint(20) unsigned NOT NULL DEFAULT 0,
				ability varchar(80) NOT NULL DEFAULT '',
				object_id bigint(20) unsigned NOT NULL DEFAULT 0,
				result varchar(20) NOT NULL DEFAULT 'ok',
				summary text NOT NULL,
				details longtext NULL,
				PRIMARY KEY  (id),
				KEY created_at (created_at),
				KEY ability (ability),
				KEY object_id (object_id)
			) {$charset};"
		);
		update_option( 'navia_mcp_db_version', self::DB_VERSION, false );
	}








	public static function add( $ability, $object_id, $summary, $details = array(), $result = 'ok' ) {
		global $wpdb;
		self::maybe_install();
		$json = wp_json_encode( $details );
		if ( strlen( (string) $json ) > 60000 ) {
			$json = substr( $json, 0, 60000 );
		}
		$wpdb->insert(
			self::table(),
			array(
				'created_at' => current_time( 'mysql', true ),
				'user_id'    => get_current_user_id(),
				'ability'    => substr( (string) $ability, 0, 80 ),
				'object_id'  => (int) $object_id,
				'result'     => substr( (string) $result, 0, 20 ),
				'summary'    => (string) $summary,
				'details'    => $json,
			),
			array( '%s', '%d', '%s', '%d', '%s', '%s', '%s' )
		);
	}

	public static function query( $limit = 100, $ability = '', $object_id = 0 ) {
		global $wpdb;
		self::maybe_install();
		$table = self::table();
		$where = '1=1';
		$args  = array();
		if ( $ability ) {
			$where .= ' AND ability = %s';
			$args[] = $ability;
		}
		if ( $object_id ) {
			$where .= ' AND object_id = %d';
			$args[] = (int) $object_id;
		}
		$args[] = max( 1, min( 1000, (int) $limit ) );
		$sql    = "SELECT id, created_at, user_id, ability, object_id, result, summary FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d";
		return $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
	}

	public static function cleanup() {
		global $wpdb;
		$days  = max( 7, (int) Navia_MCP_Settings::network()['log_retention_days'] );
		$table = self::table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
}
