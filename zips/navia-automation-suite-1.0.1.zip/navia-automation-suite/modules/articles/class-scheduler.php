<?php






defined( 'ABSPATH' ) || exit;

class Navia_MCP_Scheduler {

	const CRON_HOOK = 'navia_mcp_fix_missed';

	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'fix_missed' ) );
		add_action(
			'init',
			function () {
				if ( Navia_MCP_Settings::site_enabled() && ! wp_next_scheduled( self::CRON_HOOK ) ) {
					wp_schedule_event( time() + 300, 'hourly', self::CRON_HOOK );
				}
			}
		);
	}

	public static function on_deactivation() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		wp_clear_scheduled_hook( Navia_MCP_Log::CRON_HOOK );
	}

	private static function hm_to_minutes( $hm, $fallback ) {
		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', (string) $hm, $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ) {
			return (int) $m[1] * 60 + (int) $m[2];
		}
		return $fallback;
	}








	public static function plan( array $groups, array $o ) {
		$s   = Navia_MCP_Settings::site();
		$tz  = Navia_MCP_Settings::schedule_tz();
		$min = max( 0, (int) ( $o['min_days'] ?? $s['sched_min_days'] ) );
		$max = max( $min, (int) ( $o['max_days'] ?? $s['sched_max_days'] ) );
		$w1  = self::hm_to_minutes( $o['window_start'] ?? $s['sched_window_start'], 510 );
		$w2  = self::hm_to_minutes( $o['window_end'] ?? $s['sched_window_end'], 630 );
		if ( $w2 < $w1 ) {
			list( $w1, $w2 ) = array( $w2, $w1 );
		}
		$days = array_values( array_unique( array_filter( array_map( 'intval', (array) ( $o['days'] ?? $s['sched_days'] ) ), function ( $d ) {
			return $d >= 1 && $d <= 7;
		} ) ) );
		if ( ! $days ) {
			return new WP_Error( 'navia_sched_days', 'No allowed weekdays.' );
		}
		$offset = max( 0, (int) ( $o['tr_offset'] ?? $s['sched_tr_offset'] ) );


		$allow_past = ! empty( $o['allow_past'] );
		if ( $allow_past && empty( $s['sched_allow_past'] ) ) {
			return new WP_Error( 'navia_past_off', 'Past dates are off. Tick "Allow past dates" in Navia Suite > Articles (MCP) > Scheduling.' );
		}

		$now       = new DateTime( 'now', $tz );
		$earliest  = ( clone $now )->modify( '+15 minutes' );
		if ( ! empty( $o['start_date'] ) ) {
			$day = DateTime::createFromFormat( '!Y-m-d', (string) $o['start_date'], $tz );
			if ( ! $day ) {
				return new WP_Error( 'navia_sched_date', 'start_date must be YYYY-MM-DD.' );
			}
		} else {
			$day = ( clone $now )->setTime( 0, 0 )->modify( '+1 day' );
		}

		$plan = array();
		foreach ( array_values( $groups ) as $i => $g ) {
			if ( ! empty( $g['date'] ) ) {

				$when = DateTime::createFromFormat( '!Y-m-d H:i', (string) $g['date'], $tz );
				if ( ! $when || $when->format( 'Y-m-d H:i' ) !== (string) $g['date'] ) {
					return new WP_Error( 'navia_sched_date', sprintf( 'Item %d: date must be "YYYY-MM-DD HH:MM".', (int) $g['main'] ) );
				}
				if ( $when <= $earliest && ! $allow_past ) {
					return new WP_Error( 'navia_sched_past', sprintf( 'Item %d: %s is in the past. Pass allow_past=true (and tick "Allow past dates" in the settings) to backdate.', (int) $g['main'], $g['date'] ) );
				}
				$day = ( clone $when )->setTime( 0, 0 );
			} else {
				if ( $i > 0 ) {
					$day->modify( '+' . wp_rand( $min, $max ) . ' days' );
				}

				for ( $guard = 0; $guard < 30; $guard++ ) {
					$candidate = ( clone $day )->setTime( 0, 0 )->modify( '+' . $w2 . ' minutes' );
					if ( in_array( (int) $day->format( 'N' ), $days, true ) && ( $allow_past || $candidate > $earliest ) ) {
						break;
					}
					$day->modify( '+1 day' );
				}
				$minute = wp_rand( $w1, $w2 );
				$when   = ( clone $day )->setTime( 0, 0 )->modify( '+' . $minute . ' minutes' );
				if ( $when <= $earliest && ! $allow_past ) {
					$when = ( clone $earliest )->modify( '+' . wp_rand( 1, 20 ) . ' minutes' );
				}
			}

			$row = array(
				'main'         => self::slot( (int) $g['main'], $when ),
				'translations' => array(),
			);
			foreach ( (array) $g['translations'] as $tid ) {
				$row['translations'][] = self::slot( (int) $tid, ( clone $when )->modify( '+' . $offset . ' minutes' ) );
			}
			$plan[] = $row;
		}
		return $plan;
	}

	private static function slot( $post_id, DateTime $when_tz ) {
		$utc = ( clone $when_tz )->setTimezone( new DateTimeZone( 'UTC' ) );
		$wp  = ( clone $when_tz )->setTimezone( wp_timezone() );
		return array(
			'id'         => $post_id,
			'title'      => get_the_title( $post_id ),
			'lang'       => Navia_MCP_Helpers::post_lang( $post_id ),
			'local'      => $when_tz->format( 'Y-m-d H:i' ),
			'timezone'   => $when_tz->getTimezone()->getName(),
			'weekday'    => $when_tz->format( 'l' ),
			'post_date'  => $wp->format( 'Y-m-d H:i:s' ),
			'post_date_gmt' => $utc->format( 'Y-m-d H:i:s' ),
			'in_past'    => $utc->getTimestamp() <= time(),
		);
	}







	public static function apply( array $plan ) {
		$out = array();
		foreach ( $plan as $row ) {
			foreach ( array_merge( array( $row['main'] ), $row['translations'] ) as $slot ) {
				$past = strtotime( $slot['post_date_gmt'] . ' UTC' ) <= time();
				if ( $past && ! Navia_MCP_Settings::get( 'sched_allow_past' ) ) {
					$slot['status'] = 'error: past dates are off in the settings';
					$out[]          = $slot;
					continue;
				}
				$res = wp_update_post(
					array(
						'ID'            => $slot['id'],
						'post_status'   => $past ? 'publish' : 'future',
						'post_date'     => $slot['post_date'],
						'post_date_gmt' => $slot['post_date_gmt'],
						'edit_date'     => true,
					),
					true
				);
				$slot['status'] = is_wp_error( $res ) ? 'error: ' . $res->get_error_message() : get_post_status( $slot['id'] );
				$out[]          = $slot;
				if ( ! is_wp_error( $res ) && $past ) {


					Navia_MCP_Cache::purge( $slot['id'] );
					Navia_MCP_Dates::flush_sitemap();
				}
				if ( ! is_wp_error( $res ) ) {
					Navia_MCP_Log::add( 'navia/schedule-posts', $slot['id'], ( $past ? 'Published with past date ' : 'Scheduled for ' ) . $slot['local'] . ' ' . $slot['timezone'], $slot );
				}
			}
		}
		return $out;
	}






	public static function fix_missed() {
		if ( ! Navia_MCP_Settings::site_enabled() ) {
			return array();
		}
		global $wpdb;
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'future' AND post_type = 'post' AND post_date_gmt < %s LIMIT 50",
				gmdate( 'Y-m-d H:i:s', time() - 300 )
			)
		);
		$done = array();
		foreach ( array_map( 'intval', $ids ) as $id ) {
			wp_publish_post( $id );
			if ( 'publish' === get_post_status( $id ) ) {
				$done[] = $id;
				Navia_MCP_Log::add( 'navia/fix-missed-schedule', $id, 'Published a post that missed its schedule.' );
			}
		}
		return $done;
	}
}
