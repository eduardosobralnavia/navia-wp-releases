<?php






defined( 'ABSPATH' ) || exit;

class Navia_MCP_Settings {

	const NETWORK_OPTION = 'navia_mcp_network';
	const SITE_OPTION    = 'navia_mcp_site';




	const MODULES = array(
		'content'  => 'Content (articles, read and write)',
		'terms'    => 'Categories and tags',
		'seo'      => 'SEO meta (Rank Math)',
		'i18n'     => 'Languages (Polylang)',
		'images'   => 'Image generation',
		'schedule' => 'Scheduling',
		'tables'   => 'Table normalisation and styles',
		'cache'    => 'Cache purge',
		'verify'   => 'Published page verification',
	);

	public static function network_defaults() {
		return array(
			'cf_account_id'      => '',
			'cf_token'           => '',
			'cf_model'           => '@cf/black-forest-labs/flux-1-schnell',
			'cf_steps'           => 4,
			'cf_daily_limit'     => 150,
			'enabled_sites'      => array(),
			'log_retention_days' => 365,
		);
	}

	public static function site_defaults() {
		return array(
			'modules'              => array_fill_keys( array_keys( self::MODULES ), true ),
			'publish_mode'         => 'schedule',
			'default_author'       => 0,
			'rate_limit'           => 40,
			'allow_trash_any'      => false,
			'sched_min_days'       => 1,
			'sched_max_days'       => 3,
			'sched_window_start'   => '08:30',
			'sched_window_end'     => '10:30',
			'sched_days'           => array( 1, 2, 3, 4, 5, 6 ),
			'sched_tr_offset'      => 120,
			'sched_timezone'       => 'Europe/Lisbon',
			'sched_allow_past'     => false,
			'img_min'              => 1,
			'img_max'              => 4,
			'img_style'            => 'Documentary photograph, natural daylight, real homes and materials of the region, realistic detail.',
			'img_palette'          => 'warm whites, terracotta, sea blue',
			'img_avoid'            => 'text, letters, words, signs, logos, brand names, watermarks',
			'img_no_people'        => true,
			'img_fallback_library' => true,
			'tbl_head_bg'          => '#C4572E',
			'tbl_head_color'       => '#FFFFFF',
			'tbl_stripe'           => '#FBF8F3',
			'tbl_border'           => '#E7E1D6',
			'tbl_radius'           => 12,
			'cache_auto_purge'     => true,
		);
	}




	public static function network() {
		$saved = is_multisite() ? get_site_option( self::NETWORK_OPTION, array() ) : get_option( self::NETWORK_OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::network_defaults() );
	}

	public static function save_network( array $values ) {
		$values = wp_parse_args( $values, self::network() );
		return is_multisite() ? update_site_option( self::NETWORK_OPTION, $values ) : update_option( self::NETWORK_OPTION, $values, false );
	}

	public static function site() {
		$saved = get_option( self::SITE_OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$out   = wp_parse_args( $saved, self::site_defaults() );
		$out['modules'] = wp_parse_args( is_array( $out['modules'] ) ? $out['modules'] : array(), array_fill_keys( array_keys( self::MODULES ), false ) );
		return $out;
	}

	public static function save_site( array $values ) {
		return update_option( self::SITE_OPTION, wp_parse_args( $values, self::site() ), false );
	}

	public static function get( $key ) {
		$site = self::site();
		return $site[ $key ] ?? null;
	}

	public static function module_on( $module ) {
		$site = self::site();
		return ! empty( $site['modules'][ $module ] );
	}




	public static function site_enabled() {
		$net = self::network();
		return NAS_Env::module_site_enabled( 'articles', (array) $net['enabled_sites'] );
	}

	public static function cf_token() {
		$net = self::network();
		return Navia_MCP_Crypto::decrypt( $net['cf_token'] );
	}




	public static function schedule_tz() {
		$name = (string) self::get( 'sched_timezone' );
		try {
			return new DateTimeZone( $name ? $name : 'Europe/Lisbon' );
		} catch ( Exception $e ) {
			return new DateTimeZone( 'Europe/Lisbon' );
		}
	}

	public static function on_activation( $network_wide = false ) {
		if ( is_multisite() && $network_wide ) {
			$net = get_site_option( self::NETWORK_OPTION, false );
			if ( false === $net ) {
				$defaults                  = self::network_defaults();
				$defaults['enabled_sites'] = array( (int) get_main_site_id() );
				update_site_option( self::NETWORK_OPTION, $defaults );
			}
		}
		Navia_MCP_Log::maybe_install();
	}
}
