<?php





defined( 'ABSPATH' ) || exit;

class Navia_MCP_Tables {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ), 20 );
	}





	public static function normalize( $html ) {
		$html = (string) $html;
		if ( false === stripos( $html, '<table' ) ) {
			return $html;
		}


		$html = preg_replace( '#<div class="navia-table-wrap">\s*(<table\b.*?</table>)\s*</div>#is', '$1', $html );

		return preg_replace_callback(
			'#<table\b.*?</table>#is',
			function ( $m ) {
				return '<div class="navia-table-wrap">' . self::normalize_one( $m[0] ) . '</div>';
			},
			$html
		);
	}

	private static function normalize_one( $table_html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return $table_html;
		}
		$doc = new DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8" ?><div id="navia-root">' . $table_html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		$table = $doc->getElementsByTagName( 'table' )->item( 0 );
		if ( ! $table ) {
			return $table_html;
		}


		$xpath = new DOMXPath( $doc );
		foreach ( $xpath->query( './/descendant-or-self::*', $table ) as $el ) {
			foreach ( array( 'style', 'width', 'height', 'border', 'cellpadding', 'cellspacing', 'bgcolor', 'align' ) as $attr ) {
				if ( $el->hasAttribute( $attr ) ) {
					$el->removeAttribute( $attr );
				}
			}
		}


		$classes = preg_split( '/\s+/', trim( $table->getAttribute( 'class' ) ) );
		$classes = array_filter( $classes );
		if ( ! in_array( 'navia-table', $classes, true ) ) {
			$classes[] = 'navia-table';
		}
		$table->setAttribute( 'class', implode( ' ', $classes ) );


		if ( 0 === $table->getElementsByTagName( 'thead' )->length ) {
			$first_row = $xpath->query( './tbody/tr[1] | ./tr[1]', $table )->item( 0 );
			if ( $first_row ) {
				$cells   = $xpath->query( './td|./th', $first_row );
				$all_th  = $cells->length > 0;
				foreach ( $cells as $c ) {
					if ( 'th' !== strtolower( $c->nodeName ) ) {
						$all_th = false;
						break;
					}
				}
				if ( $all_th ) {
					$thead = $doc->createElement( 'thead' );
					$first_row->parentNode->removeChild( $first_row );
					$thead->appendChild( $first_row );
					$table->insertBefore( $thead, $table->firstChild );
				}
			}
		}


		$loose = $xpath->query( './tr', $table );
		if ( $loose->length ) {
			$tbody = $doc->createElement( 'tbody' );
			foreach ( iterator_to_array( $loose ) as $tr ) {
				$table->removeChild( $tr );
				$tbody->appendChild( $tr );
			}
			$table->appendChild( $tbody );
		}

		foreach ( $xpath->query( './thead//th', $table ) as $th ) {
			$th->setAttribute( 'scope', 'col' );
		}
		foreach ( $xpath->query( './tbody/tr/th[1]', $table ) as $th ) {
			if ( ! $th->hasAttribute( 'scope' ) ) {
				$th->setAttribute( 'scope', 'row' );
			}
		}

		$out = $doc->saveHTML( $table );
		return $out ? $out : $table_html;
	}

	public static function enqueue() {
		if ( ! Navia_MCP_Settings::site_enabled() || ! Navia_MCP_Settings::module_on( 'tables' ) || ! is_singular() ) {
			return;
		}
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post || ( false === strpos( $post->post_content, 'navia-table' ) && false === strpos( $post->post_content, 'navia-figure' ) ) ) {
			return;
		}
		$s = Navia_MCP_Settings::site();
		$c = function ( $v, $fallback ) {
			$v = sanitize_hex_color( $v );
			return $v ? $v : $fallback;
		};
		$head  = $c( $s['tbl_head_bg'], '#C4572E' );
		$headc = $c( $s['tbl_head_color'], '#FFFFFF' );
		$strip = $c( $s['tbl_stripe'], '#FBF8F3' );
		$bord  = $c( $s['tbl_border'], '#E7E1D6' );
		$rad   = max( 0, min( 40, (int) $s['tbl_radius'] ) );

		$css = ".navia-table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;margin:0 0 1.4em;border:1px solid {$bord};border-radius:{$rad}px}"
			. '.navia-table-wrap .navia-table{width:100%;min-width:520px;border-collapse:collapse;margin:0;font-size:.95em;line-height:1.5}'
			. ".navia-table-wrap .navia-table thead th{background:{$head};color:{$headc};font-weight:600;text-align:left;padding:12px 14px;border:0;position:sticky;top:0}"
			. ".navia-table-wrap .navia-table td,.navia-table-wrap .navia-table tbody th{padding:11px 14px;border:0;border-top:1px solid {$bord};text-align:left;vertical-align:top}"
			. ".navia-table-wrap .navia-table tbody tr:nth-child(even){background:{$strip}}"
			. '.navia-table-wrap .navia-table tbody th{font-weight:600}'
			. '.navia-table-wrap .navia-table caption{caption-side:top;text-align:left;font-weight:600;padding:12px 14px 4px}'
			. '.navia-figure{margin:1.6em 0}.navia-figure img{display:block;width:100%;height:auto;border-radius:12px}';

		wp_register_style( 'navia-mcp-tables', false, array(), NAS_VERSION );
		wp_enqueue_style( 'navia-mcp-tables' );
		wp_add_inline_style( 'navia-mcp-tables', $css );
	}
}
