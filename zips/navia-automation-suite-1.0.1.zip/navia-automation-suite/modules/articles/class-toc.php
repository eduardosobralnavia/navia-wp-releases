<?php









defined( 'ABSPATH' ) || exit;

class Navia_MCP_TOC {

	const WIDGET = 'navia-toc';

	public static function init() {
		add_filter( 'elementor/frontend/widget/should_render', array( __CLASS__, 'should_render' ), 10, 2 );
	}

	public static function should_render( $should_render, $widget ) {
		if ( ! $should_render || ! is_object( $widget ) || ! method_exists( $widget, 'get_name' ) || self::WIDGET !== $widget->get_name() ) {
			return $should_render;
		}
		if ( ! is_singular() ) {
			return $should_render;
		}
		$post_id = (int) get_queried_object_id();
		if ( ! $post_id ) {
			return $should_render;
		}
		return 'no' === get_post_meta( $post_id, '_navia_toc', true ) ? false : $should_render;
	}





	public static function set( $post_id, $on ) {
		if ( null === $on ) {
			return;
		}
		update_post_meta( $post_id, '_navia_toc', $on ? 'yes' : 'no' );
	}
}
