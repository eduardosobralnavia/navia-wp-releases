<?php





defined( 'ABSPATH' ) || exit;

class Navia_MCP_Verify {




	public static function url( $url, $check_links = true ) {
		$url  = esc_url_raw( (string) $url );
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $url || wp_parse_url( $url, PHP_URL_HOST ) !== $host ) {
			return new WP_Error( 'navia_verify_host', 'Only URLs on this site can be verified (' . $host . ').' );
		}

		$fetch = add_query_arg( 'navia_nocache', time(), $url );
		$res   = wp_remote_get(
			$fetch,
			array(
				'timeout'     => 25,
				'redirection' => 0,
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
				'user-agent'  => 'Mozilla/5.0 (compatible; NaviaVerify/1.0; +' . home_url( '/' ) . ')',
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$code   = (int) wp_remote_retrieve_response_code( $res );
		$html   = (string) wp_remote_retrieve_body( $res );
		$issues = array();
		$report = array(
			'url'      => $url,
			'status'   => $code,
			'location' => (string) wp_remote_retrieve_header( $res, 'location' ),
		);
		if ( 200 !== $code ) {
			$issues[]          = 'HTTP ' . $code . ( $report['location'] ? ' to ' . $report['location'] : '' );
			$report['issues']  = $issues;
			$report['ok']      = false;
			return $report;
		}

		$doc = new DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
		libxml_clear_errors();
		$xp = new DOMXPath( $doc );

		$h1 = array();
		foreach ( $xp->query( '//h1' ) as $n ) {
			$h1[] = trim( preg_replace( '/\s+/u', ' ', $n->textContent ) );
		}
		$report['h1'] = $h1;
		if ( 1 !== count( $h1 ) ) {
			$issues[] = count( $h1 ) . ' H1 elements (expected 1).';
		}

		$title_node      = $xp->query( '//title' )->item( 0 );
		$report['title'] = $title_node ? trim( $title_node->textContent ) : '';
		$report['title_length'] = Navia_MCP_Helpers::len( $report['title'] );
		if ( '' === $report['title'] ) {
			$issues[] = 'Missing <title>.';
		}

		$desc                  = $xp->query( '//meta[@name="description"]/@content' )->item( 0 );
		$report['description'] = $desc ? trim( $desc->nodeValue ) : '';
		$report['description_length'] = Navia_MCP_Helpers::len( $report['description'] );
		if ( '' === $report['description'] ) {
			$issues[] = 'Missing meta description.';
		} elseif ( $report['description_length'] > 160 ) {
			$issues[] = 'Meta description over 160 characters.';
		}

		$robots           = $xp->query( '//meta[@name="robots"]/@content' )->item( 0 );
		$report['robots'] = $robots ? $robots->nodeValue : '';
		if ( false !== stripos( $report['robots'], 'noindex' ) ) {
			$issues[] = 'Page is noindex.';
		}

		$canon               = $xp->query( '//link[@rel="canonical"]/@href' )->item( 0 );
		$report['canonical'] = $canon ? $canon->nodeValue : '';
		if ( '' === $report['canonical'] ) {
			$issues[] = 'Missing canonical.';
		} elseif ( untrailingslashit( $report['canonical'] ) !== untrailingslashit( strtok( $url, '?' ) ) ) {
			$issues[] = 'Canonical points elsewhere: ' . $report['canonical'];
		}

		$hreflang = array();
		foreach ( $xp->query( '//link[@rel="alternate"][@hreflang]' ) as $n ) {
			$hreflang[ $n->getAttribute( 'hreflang' ) ] = $n->getAttribute( 'href' );
		}
		$report['hreflang'] = (object) $hreflang;
		if ( Navia_MCP_Helpers::pll() ) {
			if ( count( $hreflang ) < 2 ) {
				$issues[] = 'Fewer than two hreflang alternates (translation missing or not linked).';
			}
			if ( ! isset( $hreflang['x-default'] ) ) {
				$issues[] = 'No hreflang x-default.';
			}
		}

		$types = array();
		$count = 0;
		foreach ( $xp->query( '//script[@type="application/ld+json"]' ) as $n ) {
			++$count;
			$data = json_decode( $n->textContent, true );
			if ( ! is_array( $data ) ) {
				$issues[] = 'A JSON-LD block does not parse.';
				continue;
			}
			$nodes = isset( $data['@graph'] ) ? $data['@graph'] : ( isset( $data[0] ) ? $data : array( $data ) );
			foreach ( $nodes as $node ) {
				if ( isset( $node['@type'] ) ) {
					foreach ( (array) $node['@type'] as $t ) {
						$types[] = $t;
					}
				}
			}
		}
		$report['jsonld_blocks'] = $count;
		$report['jsonld_types']  = array_values( array_unique( $types ) );
		if ( ! $count ) {
			$issues[] = 'No JSON-LD.';
		}

		$no_alt = array();
		foreach ( $xp->query( '//img' ) as $img ) {
			if ( ! $img->hasAttribute( 'alt' ) || '' === trim( $img->getAttribute( 'alt' ) ) ) {
				$no_alt[] = $img->getAttribute( 'src' );
			}
		}
		$report['images_without_alt'] = array_slice( $no_alt, 0, 20 );
		if ( $no_alt ) {
			$issues[] = count( $no_alt ) . ' images without alt (may include theme images).';
		}

		$report['tables'] = $xp->query( '//table' )->length;
		$report['toc']    = $xp->query( '//*[contains(concat(" ", normalize-space(@class), " "), " navia-toc ")]' )->length > 0;
		$report['leftover_markers'] = Navia_MCP_Helpers::count_markers( $html );
		if ( $report['leftover_markers'] ) {
			$issues[] = 'Image markers left in the page.';
		}

		$broken    = array();
		$redirects = array();
		if ( $check_links ) {
			$seen = array();
			foreach ( $xp->query( '//a[@href]' ) as $a ) {
				$href = $a->getAttribute( 'href' );
				$h    = wp_parse_url( $href, PHP_URL_HOST );
				if ( ! $h || ( $h !== $host && ! preg_match( '/(^|\.)' . preg_quote( $host, '/' ) . '$/', $h ) ) ) {
					continue;
				}
				$clean = strtok( $href, '#' );
				if ( isset( $seen[ $clean ] ) || preg_match( '#/wp-(admin|login)|/feed/?$|\?#', $clean ) ) {
					continue;
				}
				$seen[ $clean ] = true;
				if ( count( $seen ) > 60 ) {
					break;
				}
				$r = wp_remote_head( $clean, array( 'timeout' => 10, 'redirection' => 0 ) );
				$c = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
				if ( 405 === $c ) {
					$r = wp_remote_get( $clean, array( 'timeout' => 10, 'redirection' => 0 ) );
					$c = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
				}
				if ( $c >= 400 || 0 === $c ) {
					$broken[] = array(
						'url'    => $clean,
						'status' => $c,
					);
				} elseif ( $c >= 300 ) {
					$redirects[] = array(
						'url'    => $clean,
						'status' => $c,
						'to'     => is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_header( $r, 'location' ),
					);
				}
			}
			$report['internal_links_checked'] = count( $seen );
		}
		$report['links_broken']    = $broken;
		$report['links_redirect']  = $redirects;
		foreach ( $broken as $b ) {
			$issues[] = 'Link ' . $b['url'] . ' returns ' . ( $b['status'] ? $b['status'] : 'no response' ) . '.';
		}

		$report['issues'] = $issues;
		$report['ok']     = ! $issues;
		return $report;
	}
}
