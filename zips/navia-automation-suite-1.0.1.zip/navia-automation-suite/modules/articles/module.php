<?php







defined( 'ABSPATH' ) || exit;

NAS_Plugin::define( 'NAVIA_MCP_FILE', NAS_FILE );
NAS_Plugin::define( 'NAVIA_MCP_DIR', __DIR__ . '/' );
NAS_Plugin::define( 'NAVIA_MCP_URL', NAS_URL . 'modules/articles/' );

require_once __DIR__ . '/class-settings.php';
require_once __DIR__ . '/class-crypto.php';
require_once __DIR__ . '/class-log.php';
require_once __DIR__ . '/class-guard.php';
require_once __DIR__ . '/class-helpers.php';
require_once __DIR__ . '/class-tables.php';
require_once __DIR__ . '/class-toc.php';
require_once __DIR__ . '/class-cache.php';
require_once __DIR__ . '/providers/class-cloudflare.php';
require_once __DIR__ . '/class-images.php';
require_once __DIR__ . '/class-scheduler.php';
require_once __DIR__ . '/class-dates.php';
require_once __DIR__ . '/class-verify.php';
require_once __DIR__ . '/abilities/class-abilities.php';
require_once __DIR__ . '/admin/class-admin.php';

add_action(
	'plugins_loaded',
	static function () {
		Navia_MCP_Log::init();
		Navia_MCP_Tables::init();
		Navia_MCP_TOC::init();
		Navia_MCP_Scheduler::init();
		Navia_MCP_Abilities::init();
		if ( is_admin() || is_network_admin() ) {
			Navia_MCP_Admin::init();
		}
	},
	20
);
