<?php





defined( 'ABSPATH' ) || exit;

class Navia_MCP_Cloudflare {

	const ID          = 'cloudflare';
	const PAUSE_KEY   = 'navia_mcp_cf_paused_until';
	const USAGE_KEY   = 'navia_mcp_image_usage';

	public static function configured() {
		$net = Navia_MCP_Settings::network();
		return '' !== trim( (string) $net['cf_account_id'] ) && '' !== Navia_MCP_Settings::cf_token();
	}

	public static function paused_until() {
		return (int) ( is_multisite() ? get_site_option( self::PAUSE_KEY, 0 ) : get_option( self::PAUSE_KEY, 0 ) );
	}

	private static function pause_until_reset() {
		$reset = strtotime( 'tomorrow 00:00 UTC' );
		is_multisite() ? update_site_option( self::PAUSE_KEY, $reset ) : update_option( self::PAUSE_KEY, $reset, false );
	}

	public static function available() {
		return self::configured() && self::paused_until() < time() && self::used_today() < (int) Navia_MCP_Settings::network()['cf_daily_limit'];
	}



	public static function usage() {
		$u = is_multisite() ? get_site_option( self::USAGE_KEY, array() ) : get_option( self::USAGE_KEY, array() );
		return is_array( $u ) ? $u : array();
	}

	public static function used_today( $provider = self::ID ) {
		$u = self::usage();
		return (int) ( $u[ gmdate( 'Y-m-d' ) ][ $provider ] ?? 0 );
	}

	public static function count_use( $provider ) {
		$u   = self::usage();
		$day = gmdate( 'Y-m-d' );
		$u[ $day ][ $provider ] = (int) ( $u[ $day ][ $provider ] ?? 0 ) + 1;

		$cut = gmdate( 'Y-m-d', time() - 40 * DAY_IN_SECONDS );
		foreach ( array_keys( $u ) as $d ) {
			if ( $d < $cut ) {
				unset( $u[ $d ] );
			}
		}
		is_multisite() ? update_site_option( self::USAGE_KEY, $u ) : update_option( self::USAGE_KEY, $u, false );
	}







	public static function generate( $prompt ) {
		if ( ! self::configured() ) {
			return new WP_Error( 'navia_cf_not_configured', 'Cloudflare Account ID or API token is missing in the network settings.' );
		}
		if ( ! self::available() ) {
			return new WP_Error( 'navia_cf_paused', 'Cloudflare is paused until the daily quota resets (00:00 UTC) or the daily limit in the settings was reached.' );
		}

		$net   = Navia_MCP_Settings::network();
		$model = trim( (string) $net['cf_model'] );
		$url   = sprintf(
			'https://api.cloudflare.com/client/v4/accounts/%s/ai/run/%s',
			rawurlencode( trim( (string) $net['cf_account_id'] ) ),
			ltrim( $model, '/' )
		);
		$body = array(
			'prompt' => function_exists( 'mb_substr' ) ? mb_substr( $prompt, 0, 2000 ) : substr( $prompt, 0, 2000 ),
			'steps'  => max( 1, min( 8, (int) $net['cf_steps'] ) ),
		);

		$errors_5xx = 0;
		for ( $attempt = 1; $attempt <= 2; $attempt++ ) {
			$res = wp_remote_post(
				$url,
				array(
					'timeout' => 30,
					'headers' => array(
						'Authorization' => 'Bearer ' . Navia_MCP_Settings::cf_token(),
						'Content-Type'  => 'application/json',
					),
					'body'    => wp_json_encode( $body ),
				)
			);

			if ( is_wp_error( $res ) ) {

				if ( 2 === $attempt ) {
					return new WP_Error( 'navia_cf_http', 'Cloudflare request failed: ' . $res->get_error_message() );
				}
				continue;
			}

			$code = (int) wp_remote_retrieve_response_code( $res );
			$raw  = wp_remote_retrieve_body( $res );
			$json = json_decode( $raw, true );

			if ( 200 === $code && ! empty( $json['result']['image'] ) ) {
				$bytes = base64_decode( (string) $json['result']['image'], true );
				if ( false === $bytes || strlen( $bytes ) < 1000 ) {
					return new WP_Error( 'navia_cf_bad_image', 'Cloudflare returned an unreadable image.' );
				}
				self::count_use( self::ID );
				return array(
					'bytes' => $bytes,
					'mime'  => 'image/jpeg',
				);
			}

			$message = '';
			if ( ! empty( $json['errors'][0]['message'] ) ) {
				$message = (string) $json['errors'][0]['message'];
			}

			if ( 429 === $code || 402 === $code || preg_match( '/quota|neurons? (allocation|limit)|daily (free )?allocation|rate limit/i', $message ) ) {
				self::pause_until_reset();
				return new WP_Error( 'navia_cf_quota', 'Cloudflare quota reached: ' . ( $message ? $message : 'HTTP ' . $code ) . '. Paused until 00:00 UTC.' );
			}
			if ( 401 === $code || 403 === $code ) {
				return new WP_Error( 'navia_cf_auth', 'Cloudflare rejected the token or Account ID (HTTP ' . $code . '). Check the token has Workers AI permission.' );
			}
			if ( $code >= 500 ) {
				++$errors_5xx;
				if ( $errors_5xx >= 2 ) {
					return new WP_Error( 'navia_cf_5xx', 'Cloudflare returned two server errors in a row (HTTP ' . $code . ').' );
				}
				continue;
			}
			return new WP_Error( 'navia_cf_error', 'Cloudflare error HTTP ' . $code . ( $message ? ': ' . $message : '' ) );
		}

		return new WP_Error( 'navia_cf_error', 'Cloudflare did not return an image.' );
	}
}
