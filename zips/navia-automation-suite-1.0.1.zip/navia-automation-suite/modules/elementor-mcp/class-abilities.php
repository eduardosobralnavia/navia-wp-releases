<?php






defined( 'ABSPATH' ) || exit;

class Navia_EL_Abilities {

	const CATEGORY = 'navia-elementor';
	const EDITABLE = array( 'page', 'chf_template' );

	public static function init(): void {
		add_action( 'wp_abilities_api_categories_init', array( __CLASS__, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( __CLASS__, 'register' ) );
	}

	public static function register_category(): void {
		if ( function_exists( 'wp_has_ability_category' ) && wp_has_ability_category( self::CATEGORY ) ) {
			return;
		}
		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => 'Navia Suite: Elementor',
				'description' => 'Design and build Elementor pages, global styles, headers, footers and menus.',
			)
		);
	}



	private static function chf_type(): string {
		return defined( 'CHF_POST_TYPE' ) ? CHF_POST_TYPE : 'chf_template';
	}

	private static function chf_active(): bool {
		return post_type_exists( self::chf_type() );
	}

	private static function can( string $cap ): callable {
		return static function () use ( $cap ) {
			if ( ! Navia_EL_Settings::site_enabled() ) {
				return new WP_Error( 'navia_el_disabled', 'The Elementor (MCP) module of Navia Automation Suite is not enabled for this site (Network Admin > Navia Suite > Elementor (MCP), or Navia Suite > Modules on a single site).' );
			}
			return current_user_can( $cap );
		};
	}

	private static function can_with( string $cap, string $setting ): callable {
		return static function () use ( $cap, $setting ) {
			if ( ! Navia_EL_Settings::site_enabled() ) {
				return new WP_Error( 'navia_el_disabled', 'The Elementor (MCP) module of Navia Automation Suite is not enabled for this site.' );
			}
			if ( ! Navia_EL_Settings::get( $setting ) ) {
				return new WP_Error( 'navia_el_setting', "This action is switched off in Navia Suite > Elementor (MCP) ($setting)." );
			}
			return current_user_can( $cap );
		};
	}

	private static function guard( string $ability ) {
		if ( ! Navia_EL_Settings::check_rate() ) {
			Navia_EL_Log::add( $ability, 0, 'Rate limit reached', 'refused' );
			return new WP_Error( 'navia_el_rate', 'Too many writes in the last minute. Wait and try again.' );
		}
		return true;
	}

	private static function decode( $value ) {
		if ( is_string( $value ) ) {
			$d = json_decode( $value, true );
			return is_array( $d ) ? $d : null;
		}
		return is_array( $value ) ? $value : null;
	}

	private static function theme_part_type( int $post_id ): string {
		return (string) get_post_meta( $post_id, '_chf_template_type', true );
	}

	private static function kind_of( WP_Post $post ): string {
		if ( self::chf_type() === $post->post_type ) {
			$t = self::theme_part_type( $post->ID );
			return $t ? $t : 'header';
		}
		return 'page';
	}

	private static function doc( int $id, bool $editable = true ) {
		$post = get_post( $id );
		if ( ! $post || 'trash' === $post->post_status ) {
			return new WP_Error( 'navia_el_not_found', "Document $id not found." );
		}
		if ( $editable && ! in_array( $post->post_type, self::EDITABLE, true ) ) {
			return new WP_Error( 'navia_el_type', "Document $id is a {$post->post_type}. These abilities edit pages and header, footer and single templates. Articles go through navia/ abilities." );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'navia_el_cap', "You cannot edit document $id." );
		}
		return $post;
	}

	private static function summary( WP_Post $post ): array {
		$row = array(
			'id'       => $post->ID,
			'title'    => $post->post_title,
			'slug'     => $post->post_name,
			'type'     => $post->post_type,
			'kind'     => self::kind_of( $post ),
			'status'   => $post->post_status,
			'modified' => $post->post_modified,
			'elementor'=> 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ),
			'url'      => 'publish' === $post->post_status ? get_permalink( $post ) : '',
			'edit_url' => admin_url( 'post.php?post=' . $post->ID . '&action=elementor' ),
		);
		if ( 'page' === $post->post_type ) {
			$row['template'] = get_post_meta( $post->ID, '_wp_page_template', true ) ?: 'default';
			$row['parent']   = $post->post_parent;
		}
		if ( self::chf_type() === $post->post_type ) {
			$row['enabled'] = 'no' !== get_post_meta( $post->ID, '_chf_enabled', true );
		}
		if ( Navia_EL_I18n::active() ) {
			$row['lang']         = Navia_EL_I18n::get_lang( $post->ID );
			$row['translations'] = Navia_EL_I18n::translations( $post->ID );
		}
		if ( get_post_meta( $post->ID, '_navia_el_created', true ) ) {
			$row['created_here'] = true;
		}
		return $row;
	}

	private static function check_status( string $status, string $post_type ) {
		if ( ! in_array( $status, array( 'draft', 'pending', 'publish', 'private' ), true ) ) {
			return new WP_Error( 'navia_el_status', "Status must be draft, pending, private or publish (got \"$status\")." );
		}
		if ( 'publish' === $status ) {
			if ( ! Navia_EL_Settings::can_publish() ) {
				return new WP_Error( 'navia_el_publish', 'Publishing is switched off on this site (Navia Suite > Elementor (MCP), publishing mode). Save as draft and ask for review.' );
			}
			$cap = 'page' === $post_type ? 'publish_pages' : 'publish_posts';
			if ( ! current_user_can( $cap ) ) {
				return new WP_Error( 'navia_el_cap', 'You cannot publish this.' );
			}
		}
		return true;
	}




	private static function prepare_elements( $raw, string $kind ) {
		$elements = self::decode( $raw );
		if ( null === $elements ) {
			return new WP_Error( 'navia_el_elements', 'elements must be an array of Elementor elements (or a JSON string of one).' );
		}
		if ( strlen( (string) wp_json_encode( $elements ) ) > 2 * MB_IN_BYTES ) {
			return new WP_Error( 'navia_el_size', 'Layout larger than 2 MB. Split the page.' );
		}
		$errors   = array();
		$warnings = array();
		$seen     = array();
		$elements = Navia_EL_Tree::normalize( $elements, $errors, $warnings, $seen );
		if ( $errors ) {
			return new WP_Error( 'navia_el_invalid', 'Invalid layout: ' . implode( ' | ', array_slice( $errors, 0, 15 ) ) );
		}
		$check = Navia_EL_Checks::tree( $elements, $kind );
		$fatal = array_filter( $check['issues'], fn( $i ) => 'error' === $i['level'] );
		if ( $fatal ) {
			return new WP_Error( 'navia_el_rules', 'Refused: ' . implode( ' | ', array_map( fn( $i ) => $i['message'], $fatal ) ) );
		}
		foreach ( $check['issues'] as $i ) {
			$warnings[] = $i['message'] . ( isset( $i['element'] ) ? ' [' . $i['element'] . ']' : '' );
		}
		return array( $elements, $warnings );
	}

	private static function merge_settings( array $current, $new ): array {
		$new = self::decode( $new ) ?? array();
		foreach ( $new as $k => $v ) {
			if ( null === $v ) {
				unset( $current[ $k ] );
			} else {
				$current[ $k ] = $v;
			}
		}
		return $current;
	}

	private static function purge( int $post_id = 0 ): void {
		if ( $post_id ) {
			clean_post_cache( $post_id );
			if ( function_exists( 'w3tc_flush_post' ) ) {
				w3tc_flush_post( $post_id );
			}
			if ( function_exists( 'rocket_clean_post' ) ) {
				rocket_clean_post( $post_id );
			}
			do_action( 'litespeed_purge_post', $post_id );
		} else {
			if ( function_exists( 'w3tc_flush_all' ) ) {
				w3tc_flush_all();
			}
			if ( function_exists( 'rocket_clean_domain' ) ) {
				rocket_clean_domain();
			}
			do_action( 'litespeed_purge_all' );
		}
	}

	private static function after_write( WP_Post $post, array $warnings, string $ability, string $summary ): array {
		$post = get_post( $post->ID );
		if ( 'publish' === $post->post_status ) {
			self::purge( self::chf_type() === $post->post_type ? 0 : $post->ID );
		}
		Navia_EL_Log::add( $ability, $post->ID, $summary );
		$out             = self::summary( $post );
		$out['warnings'] = array_values( array_unique( $warnings ) );
		return $out;
	}

	private static function apply_lang( int $post_id, $lang, $translations, $translation_of, array &$warnings ) {
		if ( ! $lang && ! $translations && ! $translation_of ) {
			return true;
		}
		if ( ! Navia_EL_I18n::active() ) {
			$warnings[] = 'Polylang is not active: language parameters ignored.';
			return true;
		}
		if ( $lang ) {
			$r = Navia_EL_I18n::set_lang( $post_id, (string) $lang );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		$map = self::decode( $translations ) ?? array();
		if ( $translation_of ) {
			$src_lang = Navia_EL_I18n::get_lang( (int) $translation_of );
			if ( ! $src_lang ) {
				return new WP_Error( 'navia_el_lang', "Post $translation_of has no language yet." );
			}
			$map[ $src_lang ] = (int) $translation_of;
		}
		if ( $map ) {
			$own = Navia_EL_I18n::get_lang( $post_id );
			if ( ! $own ) {
				return new WP_Error( 'navia_el_lang', 'Set lang before linking translations.' );
			}
			$map[ $own ] = $post_id;
			$r           = Navia_EL_I18n::link( $map );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		return true;
	}



	private static function obj( array $props = array(), array $required = array() ): array {
		$s = array(
			'type'       => 'object',
			'properties' => $props,
		);
		if ( $required ) {
			$s['required'] = $required;
		}
		return $s;
	}

	private static function elements_schema( string $desc ): array {
		return array(
			'type'        => array( 'array', 'string' ),
			'description' => $desc,
		);
	}

	private static function any_object( string $desc ): array {
		return array(
			'type'        => array( 'object', 'array' ),
			'description' => $desc,
		);
	}

	private static function lang_props(): array {
		return array(
			'lang'           => array(
				'type'        => 'string',
				'description' => 'Polylang language slug, for example pt or en.',
			),
			'translation_of' => array(
				'type'        => 'integer',
				'description' => 'ID of the same document in another language, to link them.',
			),
			'translations'   => self::any_object( 'Explicit translation map, for example {"pt": 12, "en": 34}.' ),
		);
	}



	public static function register(): void {
		if ( ! Navia_EL_Settings::site_enabled() ) {
			return;
		}

		$read    = array(
			'readonly'    => true,
			'destructive' => false,
			'idempotent'  => true,
		);
		$write   = array(
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => false,
		);
		$replace = array(
			'readonly'    => false,
			'destructive' => true,
			'idempotent'  => false,
		);

		$abilities = array(

			'get-guide'            => array(
				'label'       => 'Get the building guide',
				'description' => 'Start here before designing. Returns how to write Elementor (V3) layouts for this site: element format, containers, global colours and fonts, header and footer workflow, translations, checks, plus the design notes saved for this site.',
				'input'       => self::obj(),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'get_guide' ),
			),

			'get-context'          => array(
				'label'       => 'Get the builder context',
				'description' => 'Elementor version and layout mode (containers or sections), active kit, breakpoints, page templates, languages, header, footer and single templates per language, menus, front page, form plugins and shortcodes, what this site allows (publishing, kit, menus, site settings).',
				'input'       => self::obj(),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'get_context' ),
			),

			'list-widgets'         => array(
				'label'       => 'List widgets or read their controls',
				'description' => 'Without name: every widget registered on this site (Elementor Free and plugins such as the Navia widgets of Navia Automation Suite). With name (a widget, or container, section, column, or kit): its controls, defaults and options, to write valid settings. tabs filters content, style, advanced (default content). search filters control names.',
				'input'       => self::obj(
					array(
						'name'   => array( 'type' => 'string' ),
						'tabs'   => array(
							'type'  => 'array',
							'items' => array(
								'type' => 'string',
								'enum' => array( 'content', 'style', 'advanced', 'layout' ),
							),
						),
						'search' => array( 'type' => 'string' ),
					)
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'list_widgets' ),
			),

			'get-kit'              => array(
				'label'       => 'Get global colours and fonts',
				'description' => 'Reads the active Elementor kit: system and custom colours, system and custom typography, and other non-empty site settings (container width, buttons, body and link styles, breakpoints).',
				'input'       => self::obj(),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'get_kit' ),
			),

			'update-kit'           => array(
				'label'       => 'Update global colours, fonts and theme style',
				'description' => 'Merges settings into the active kit (Site Settings in Elementor Free). Lists such as system_colors are replaced whole: pass every item. Colours: [{_id: "primary", title, color: "#hex"}]. Typography: [{_id, title, typography_typography: "custom", typography_font_family, typography_font_weight, typography_font_size: {unit, size}}]. A null value removes a key. Clears the CSS cache. Use list-widgets with name "kit" for every key.',
				'input'       => self::obj( array( 'settings' => self::any_object( 'Kit settings to merge.' ) ), array( 'settings' ) ),
				'cap'         => self::can_with( 'edit_theme_options', 'allow_kit' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'update_kit' ),
			),

			'list-documents'       => array(
				'label'       => 'List pages and theme parts',
				'description' => 'Lists pages and header, footer and single templates with status, language, translations, template, URL and Elementor edit link.',
				'input'       => self::obj(
					array(
						'kind'   => array(
							'type' => 'string',
							'enum' => array( 'page', 'header', 'footer', 'single', 'theme_parts', 'all' ),
						),
						'status' => array( 'type' => 'string' ),
						'lang'   => array( 'type' => 'string' ),
						'search' => array( 'type' => 'string' ),
						'limit'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 200,
						),
					)
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'list_documents' ),
			),

			'get-document'         => array(
				'label'       => 'Read a page or theme part',
				'description' => 'mode outline (default): one row per element with id, type, depth and a text preview. mode full: the complete Elementor data. mode texts: every visible text and link with id and field, ready for set_text operations (translation). element_id returns only that subtree. Also returns page settings, template and Rank Math meta.',
				'input'       => self::obj(
					array(
						'id'         => array( 'type' => 'integer' ),
						'mode'       => array(
							'type' => 'string',
							'enum' => array( 'outline', 'full', 'texts' ),
						),
						'element_id' => array( 'type' => 'string' ),
					),
					array( 'id' )
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'get_document' ),
			),

			'create-page'          => array(
				'label'       => 'Create an Elementor page',
				'description' => 'Creates a page built with Elementor from a list of elements (containers and widgets, classic V3 format). Validates every widget against this site, gives missing ids, refuses more than one H1. Default status draft, template from the site settings (full width with header and footer), page title hidden (the layout carries the H1). Optional language, translation link and Rank Math meta. Status publish only if the site allows it.',
				'input'       => self::obj(
					array_merge(
						array(
							'title'         => array( 'type' => 'string' ),
							'slug'          => array( 'type' => 'string' ),
							'status'        => array( 'type' => 'string' ),
							'parent'        => array( 'type' => 'integer' ),
							'menu_order'    => array( 'type' => 'integer' ),
							'template'      => array( 'type' => 'string' ),
							'elements'      => self::elements_schema( 'Elementor elements: [{elType: "container", settings: {...}, elements: [{elType: "widget", widgetType: "heading", settings: {title: "...", header_size: "h1"}}]}].' ),
							'page_settings' => self::any_object( 'Elementor page settings, for example {"hide_title": "yes", "background_background": "classic", "background_color": "#fff"}.' ),
							'seo'           => self::any_object( 'Rank Math: {title, description, focus_keyword, robots: ["index","follow"], canonical, social_title, social_description}.' ),
						),
						self::lang_props()
					),
					array( 'title', 'elements' )
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'create_page' ),
			),

			'update-document'      => array(
				'label'       => 'Update a page or theme part',
				'description' => 'Changes a page or header, footer, single template. Either elements (replace the whole layout) or operations (patch by element id: update, replace, insert, remove, move, duplicate, set_text). Also title, slug, status, template, parent, page_settings (merged, null removes), seo, lang and translations. The previous layout is kept as a revision (list-revisions, restore-revision).',
				'input'       => self::obj(
					array_merge(
						array(
							'id'            => array( 'type' => 'integer' ),
							'title'         => array( 'type' => 'string' ),
							'slug'          => array( 'type' => 'string' ),
							'status'        => array( 'type' => 'string' ),
							'parent'        => array( 'type' => 'integer' ),
							'menu_order'    => array( 'type' => 'integer' ),
							'template'      => array( 'type' => 'string' ),
							'elements'      => self::elements_schema( 'Full replacement layout.' ),
							'operations'    => array(
								'type'        => array( 'array', 'string' ),
								'description' => 'Patch list, applied in order, all or nothing: {op:"update", id, settings} | {op:"replace", id, element} | {op:"insert", parent_id (null for top level), position, element | elements} | {op:"remove", id} | {op:"move", id, parent_id, position} | {op:"duplicate", id} | {op:"set_text", id, field, value, index?, subfield?}.',
							),
							'page_settings' => self::any_object( 'Merged into the current page settings. null removes a key.' ),
							'seo'           => self::any_object( 'Rank Math fields to change.' ),
						),
						self::lang_props()
					),
					array( 'id' )
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'update_document' ),
			),

			'save-theme-part'      => array(
				'label'       => 'Create or update a header, footer or single post template',
				'description' => 'Works with the Theme Builder module of Navia Automation Suite (Elementor Free). type header, footer or single (the layout of every blog post). Without id creates one as draft; with id updates it (elements or operations). activate true publishes it and switches off the other active template of the same type and language, so this one is shown (needs publishing mode publish). Headers and footers cannot contain an H1.',
				'input'       => self::obj(
					array_merge(
						array(
							'id'         => array( 'type' => 'integer' ),
							'type'       => array(
								'type' => 'string',
								'enum' => array( 'header', 'footer', 'single' ),
							),
							'title'      => array( 'type' => 'string' ),
							'elements'   => self::elements_schema( 'Layout of the template.' ),
							'operations' => array( 'type' => array( 'array', 'string' ) ),
							'activate'   => array( 'type' => 'boolean' ),
							'enabled'    => array( 'type' => 'boolean' ),
						),
						self::lang_props()
					)
				),
				'cap'         => self::can( 'edit_theme_options' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'save_theme_part' ),
			),

			'clone-document'       => array(
				'label'       => 'Duplicate a page or theme part',
				'description' => 'Copies a page or template (layout, page settings, template, robots) into a new draft. With lang, the copy is set to that language and linked as a translation of the original, ready for set_text operations from get-document mode texts.',
				'input'       => self::obj(
					array(
						'id'    => array( 'type' => 'integer' ),
						'title' => array( 'type' => 'string' ),
						'slug'  => array( 'type' => 'string' ),
						'lang'  => array( 'type' => 'string' ),
					),
					array( 'id' )
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'clone_document' ),
			),

			'list-revisions'       => array(
				'label'       => 'List revisions of a layout',
				'description' => 'Revisions of a page or template, newest first, marking those that hold an Elementor layout.',
				'input'       => self::obj( array( 'id' => array( 'type' => 'integer' ) ), array( 'id' ) ),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'list_revisions' ),
			),

			'restore-revision'     => array(
				'label'       => 'Restore a layout revision',
				'description' => 'Puts back the Elementor layout and page settings of a revision. The current layout is saved as a new revision first.',
				'input'       => self::obj(
					array(
						'id'          => array( 'type' => 'integer' ),
						'revision_id' => array( 'type' => 'integer' ),
					),
					array( 'id', 'revision_id' )
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'restore_revision' ),
			),

			'check-document'       => array(
				'label'       => 'Check a page before publishing',
				'description' => 'Renders the layout on the server (drafts included) and reports: PHP errors, H1 count, heading outline and jumps, images without alt, empty or http links, internal links to missing pages or to the other language, dashes, Brazilian Portuguese words on pt pages, animations or heavy widgets above the fold, DOM size and word count.',
				'input'       => self::obj( array( 'id' => array( 'type' => 'integer' ) ), array( 'id' ) ),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'check_document' ),
			),

			'get-preview-link'     => array(
				'label'       => 'Get a preview link',
				'description' => 'Signed link that opens a draft page or template without logging in, for a limited time (default from settings, maximum 168 hours), never cached, never indexed. header_id, footer_id or single_id show a draft header, footer or single template on that page.',
				'input'       => self::obj(
					array(
						'id'        => array( 'type' => 'integer' ),
						'hours'     => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 168,
						),
						'header_id' => array( 'type' => 'integer' ),
						'footer_id' => array( 'type' => 'integer' ),
						'single_id' => array( 'type' => 'integer' ),
					),
					array( 'id' )
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'get_preview_link' ),
			),

			'save-menu'            => array(
				'label'       => 'Create or replace a menu',
				'description' => 'Creates a WordPress menu (or replaces the items of an existing one, by id or name) for the Site Menu widget of the header. items: [{title, page_id | url, parent (index of an earlier item), classes, new_tab}] or {type: "language_switcher", show_names, show_flags, hide_current} for the Polylang switcher. One menu per language.',
				'input'       => self::obj(
					array(
						'id'    => array( 'type' => 'integer' ),
						'name'  => array( 'type' => 'string' ),
						'items' => array(
							'type'  => array( 'array', 'string' ),
							'items' => array( 'type' => 'object' ),
						),
					),
					array( 'items' )
				),
				'cap'         => self::can_with( 'edit_theme_options', 'allow_menus' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'save_menu' ),
			),

			'update-site-settings' => array(
				'label'       => 'Update site settings',
				'description' => 'Site title and tagline, front page and posts page (default language page, Polylang maps the rest), site icon, permalink structure, and the search engine visibility switch. Off unless the site allows it.',
				'input'       => self::obj(
					array(
						'blogname'            => array( 'type' => 'string' ),
						'blogdescription'     => array( 'type' => 'string' ),
						'front_page_id'       => array( 'type' => 'integer' ),
						'posts_page_id'       => array( 'type' => 'integer' ),
						'site_icon_id'        => array( 'type' => 'integer' ),
						'permalink_structure' => array( 'type' => 'string' ),
						'search_engines'      => array(
							'type'        => 'string',
							'enum'        => array( 'visible', 'discouraged' ),
							'description' => 'discouraged ticks "Discourage search engines from indexing this site".',
						),
					)
				),
				'cap'         => self::can_with( 'manage_options', 'allow_site' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'update_site_settings' ),
			),

			'setup-languages'      => array(
				'label'       => 'Set up the site languages',
				'description' => 'Creates the Polylang languages that are missing (by locale, for example en_GB and pt_PT; name, slug and flag come from Polylang), sets the default language, language in a directory (/pt/) with the default language without code, no browser redirect, and gives the default language to existing content. Safe to run again. Off unless site settings are allowed.',
				'input'       => self::obj(
					array(
						'languages'       => array(
							'type'  => array( 'array', 'string' ),
							'items' => array( 'type' => 'object' ),
							'description' => 'In display order: [{"locale": "en_GB"}, {"locale": "pt_PT"}]. Optional slug, name, flag.',
						),
						'default'         => array(
							'type'        => 'string',
							'description' => 'Slug or locale of the main language, for example en_GB.',
						),
						'hide_default'    => array( 'type' => 'boolean' ),
						'url_mode'        => array(
							'type' => 'string',
							'enum' => array( 'directory', 'parameter' ),
						),
						'browser'         => array( 'type' => 'boolean' ),
						'assign_existing' => array( 'type' => 'boolean' ),
					),
					array( 'languages', 'default' )
				),
				'cap'         => self::can_with( 'manage_options', 'allow_site' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'setup_languages' ),
			),

			'upload-media'         => array(
				'label'       => 'Upload an image',
				'description' => 'Adds an image to the media library from base64 data or from a URL on this network (or a host allowed in settings). PNG, JPEG, WebP or GIF, up to 8 MB, converted to WebP by default. alt is required.',
				'input'       => self::obj(
					array(
						'filename'     => array( 'type' => 'string' ),
						'data_base64'  => array( 'type' => 'string' ),
						'url'          => array( 'type' => 'string' ),
						'alt'          => array( 'type' => 'string' ),
						'title'        => array( 'type' => 'string' ),
						'convert_webp' => array( 'type' => 'boolean' ),
					),
					array( 'filename', 'alt' )
				),
				'cap'         => self::can( 'upload_files' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'upload_media' ),
			),

			'list-media'           => array(
				'label'       => 'Find images in the media library',
				'description' => 'Searches the media library by title, file name or alt. Returns id, url, alt, width and height.',
				'input'       => self::obj(
					array(
						'search' => array( 'type' => 'string' ),
						'limit'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
					)
				),
				'cap'         => self::can( 'upload_files' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'list_media' ),
			),

			'site-css'             => array(
				'label'       => 'Read or replace the site CSS block',
				'description' => 'A small CSS block printed after Elementor on every page, for what Free controls cannot do (custom CSS is a Pro feature). Without css returns the current block; with css replaces it whole. No @import. Keep it short: every byte is on every page.',
				'input'       => self::obj( array( 'css' => array( 'type' => 'string' ) ) ),
				'cap'         => self::can_with( 'edit_theme_options', 'allow_css' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'site_css' ),
			),

			'save-design-notes'    => array(
				'label'       => 'Save the design notes of this site',
				'description' => 'Stores the design decisions (palette, type scale, spacing, section recipes, tone, what to avoid) as markdown, returned by get-guide in every future session so pages stay consistent. Replaces the previous notes.',
				'input'       => self::obj( array( 'notes' => array( 'type' => 'string' ) ), array( 'notes' ) ),
				'cap'         => self::can( 'edit_theme_options' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'save_design_notes' ),
			),

			'trash-document'       => array(
				'label'       => 'Move a page or template to the trash',
				'description' => 'Moves to the trash (never deletes). Only documents created by these abilities, unless the site settings allow any. Off unless the site allows it.',
				'input'       => self::obj( array( 'id' => array( 'type' => 'integer' ) ), array( 'id' ) ),
				'cap'         => self::can_with( 'delete_pages', 'allow_trash' ),
				'ann'         => $replace,
				'run'         => array( __CLASS__, 'trash_document' ),
			),

			'check-uniqueness'     => array(
				'label'       => 'Check that the content is unique in the network',
				'description' => 'Compares the pages and posts of this site (or one document with id) with every page and post of every site in the network, in the same language, and with the other documents of this site. Returns the passages found word for word elsewhere (10 words or more by default), the other document, and the element id and field that hold each passage here, ready for set_text. Uses an index kept up to date on save; run rebuild-uniqueness-index once on a network where the index was never built.',
				'input'       => self::obj(
					array(
						'id'                => array( 'type' => 'integer' ),
						'include_same_site' => array( 'type' => 'boolean' ),
						'min_passage_words' => array(
							'type'    => 'integer',
							'minimum' => 7,
							'maximum' => 60,
						),
					)
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'check_uniqueness' ),
			),

			'rebuild-uniqueness-index' => array(
				'label'       => 'Rebuild the network uniqueness index',
				'description' => 'Reads every page and post of every site of the network into the uniqueness index, in slices of about 20 seconds. Call without cursor to start, then again with the returned cursor until done is true. Heavy: only needed once, or when get-context or check-uniqueness reports sites never indexed.',
				'input'       => self::obj( array( 'cursor' => self::any_object( 'Cursor returned by the previous call.' ) ) ),
				'cap'         => self::can( 'manage_options' ),
				'ann'         => $write,
				'run'         => array( __CLASS__, 'rebuild_uniqueness_index' ),
			),

			'validate-site'        => array(
				'label'       => 'Validate the whole site',
				'description' => 'Final validation in one call: check-document on every page and header, footer and single template (rules, links, language, writing style), the writing style of every post, missing Rank Math meta and languages, and the network uniqueness check. Returns a short report per document with what to fix.',
				'input'       => self::obj(
					array(
						'include_posts' => array( 'type' => 'boolean' ),
						'status'        => array(
							'type' => 'string',
							'enum' => array( 'any', 'publish', 'draft' ),
						),
					)
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'validate_site' ),
			),

			'get-log'              => array(
				'label'       => 'Get the log',
				'description' => 'Latest writes made through these abilities on this site, optionally for one document.',
				'input'       => self::obj(
					array(
						'limit' => array( 'type' => 'integer' ),
						'id'    => array( 'type' => 'integer' ),
					)
				),
				'cap'         => self::can( 'edit_pages' ),
				'ann'         => $read,
				'run'         => array( __CLASS__, 'get_log' ),
			),
		);

		foreach ( $abilities as $name => $a ) {
			wp_register_ability(
				NAVIA_EL_NS . '/' . $name,
				array(
					'label'               => $a['label'],
					'description'         => $a['description'],
					'category'            => self::CATEGORY,
					'input_schema'        => $a['input'],
					'execute_callback'    => $a['run'],
					'permission_callback' => $a['cap'],
					'meta'                => array(
						'annotations'  => $a['ann'],
						'public'       => true,
						'show_in_rest' => true,
						'mcp'          => array( 'public' => true ),
					),
				)
			);
		}
	}



	public static function get_guide( $input = null ) {
		$guide = (string) file_get_contents( NAVIA_EL_DIR . 'guide.md' );
		$notes = Navia_EL_Settings::notes();
		return array(
			'guide'        => $guide,
			'design_notes' => '' !== $notes ? $notes : 'No design notes saved for this site yet. After deciding palette, type and section recipes, save them with save-design-notes.',
		);
	}

	public static function get_context( $input = null ) {
		$el      = Navia_EL_Builder::elementor();
		$kit     = Navia_EL_Builder::kit();
		$parts   = array();
		$plugins = array();

		if ( self::chf_active() ) {
			$q = get_posts(
				array(
					'post_type'      => self::chf_type(),
					'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
					'posts_per_page' => 100,
					'lang'           => '',
				)
			);
			foreach ( $q as $p ) {
				$parts[] = self::summary( $p );
			}
		}
		foreach ( (array) get_option( 'active_plugins', array() ) as $file ) {
			$plugins[] = dirname( $file );
		}
		if ( is_multisite() ) {
			foreach ( array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) as $file ) {
				$plugins[] = dirname( $file ) . ' (network)';
			}
		}
		global $shortcode_tags;
		$menus = array();
		foreach ( wp_get_nav_menus() as $m ) {
			$menus[] = array(
				'id'    => $m->term_id,
				'name'  => $m->name,
				'slug'  => $m->slug,
				'items' => $m->count,
			);
		}
		$breakpoints = array();
		foreach ( $el->breakpoints->get_active_breakpoints() as $name => $bp ) {
			$breakpoints[ $name ] = $bp->get_value();
		}
		$front = (int) get_option( 'page_on_front' );

		return array(
			'site'      => array(
				'name'           => get_bloginfo( 'name' ),
				'tagline'        => get_bloginfo( 'description' ),
				'url'            => home_url( '/' ),
				'blog_id'        => get_current_blog_id(),
				'multisite'      => is_multisite(),
				'theme'          => get_stylesheet(),
				'permalinks'     => (string) get_option( 'permalink_structure' ),
				'front_page'     => 'page' === get_option( 'show_on_front' ) ? $front : 0,
				'posts_page'     => (int) get_option( 'page_for_posts' ),
				'search_engines' => get_option( 'blog_public' ) ? 'visible' : 'discouraged',
				'timezone'       => wp_timezone_string(),
			),
			'elementor' => array(
				'version'          => ELEMENTOR_VERSION,
				'pro'              => defined( 'ELEMENTOR_PRO_VERSION' ),
				'layout'           => Navia_EL_Builder::container_active() ? 'containers' : 'sections',
				'element_types'    => Navia_EL_Builder::element_types(),
				'kit_id'           => $kit ? $kit->get_id() : 0,
				'breakpoints'      => $breakpoints,
				'page_templates'   => Navia_EL_Builder::page_templates(),
				'unfiltered_html'  => current_user_can( 'unfiltered_html' ),
				'site_css_bytes'   => strlen( Navia_EL_Site_CSS::get() ),
			),
			'languages' => Navia_EL_I18n::languages(),
			'theme_parts' => array(
				'plugin_active' => self::chf_active(),
				'templates'     => $parts,
				'rule'          => 'One published and enabled template per type and language is shown; the most recent wins. A language without one falls back to the default language template.',
			),
			'menus'     => $menus,
			'plugins'   => $plugins,
			'shortcodes'=> array_values( array_diff( array_keys( (array) $shortcode_tags ), array( 'audio', 'video', 'playlist', 'caption', 'wp_caption', 'gallery', 'embed' ) ) ),
			'navia_wp_mcp' => function_exists( 'wp_has_ability' ) && wp_has_ability( 'navia/get-site-context' ),
			'settings'  => Navia_EL_Settings::site(),
			'has_design_notes' => '' !== Navia_EL_Settings::notes(),
		);
	}

	public static function list_widgets( $input = null ) {
		$input = (array) $input;
		if ( empty( $input['name'] ) ) {
			return array(
				'layout'  => Navia_EL_Builder::container_active() ? 'containers' : 'sections',
				'widgets' => Navia_EL_Builder::widget_list( (string) ( $input['search'] ?? '' ) ),
			);
		}
		$tabs = ! empty( $input['tabs'] ) ? array_map( 'strval', (array) $input['tabs'] ) : array( 'content', 'layout' );
		return Navia_EL_Builder::controls_schema( (string) $input['name'], $tabs, (string) ( $input['search'] ?? '' ) );
	}

	public static function get_kit( $input = null ) {
		return Navia_EL_Builder::kit_summary();
	}

	public static function list_documents( $input = null ) {
		$input = (array) $input;
		$kind  = $input['kind'] ?? 'all';
		$types = array();
		if ( in_array( $kind, array( 'page', 'all' ), true ) ) {
			$types[] = 'page';
		}
		if ( 'page' !== $kind && self::chf_active() ) {
			$types[] = self::chf_type();
		}
		if ( ! $types ) {
			return array( 'documents' => array() );
		}
		$args = array(
			'post_type'      => $types,
			'post_status'    => ! empty( $input['status'] ) && 'any' !== $input['status'] ? (string) $input['status'] : array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page' => (int) ( $input['limit'] ?? 100 ),
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'lang'           => (string) ( $input['lang'] ?? '' ),
		);
		if ( ! empty( $input['search'] ) ) {
			$args['s'] = (string) $input['search'];
		}
		if ( in_array( $kind, array( 'header', 'footer', 'single' ), true ) ) {
			$args['meta_query'] = array(
				array(
					'key'   => '_chf_template_type',
					'value' => $kind,
				),
			);
		}
		$docs = array_map( array( __CLASS__, 'summary' ), get_posts( $args ) );
		return array( 'documents' => $docs );
	}

	public static function get_document( $input = null ) {
		$input = (array) $input;
		$post  = self::doc( (int) $input['id'], false );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$elements = Navia_EL_Builder::get_elements( $post->ID );
		if ( ! empty( $input['element_id'] ) ) {
			$sub = Navia_EL_Tree::find( $elements, (string) $input['element_id'] );
			if ( ! $sub ) {
				return new WP_Error( 'navia_el_not_found', 'Element ' . $input['element_id'] . ' not found.' );
			}
			$elements = array( $sub );
		}
		$mode = $input['mode'] ?? 'outline';
		$out  = self::summary( $post );

		$out['page_settings'] = Navia_EL_Builder::page_settings( $post->ID );
		$out['seo']           = Navia_EL_SEO::get( $post->ID );
		$out['element_count'] = Navia_EL_Tree::count( $elements );
		if ( 'full' === $mode ) {
			$out['elements'] = $elements;
		} elseif ( 'texts' === $mode ) {
			$out['texts'] = Navia_EL_Tree::texts( $elements );
		} else {
			$out['outline'] = Navia_EL_Tree::outline( $elements );
		}
		return $out;
	}

	public static function list_revisions( $input = null ) {
		$post = self::doc( (int) ( (array) $input )['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		return array( 'revisions' => Navia_EL_Builder::revisions( $post->ID ) );
	}

	public static function check_document( $input = null ) {
		$post = self::doc( (int) ( (array) $input )['id'], false );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$result       = Navia_EL_Checks::render( $post->ID, self::kind_of( $post ) );
		$result['id'] = $post->ID;
		if ( 'page' === $post->post_type ) {
			$seo = Navia_EL_SEO::get( $post->ID );
			if ( '' === $seo['title'] || '' === $seo['description'] ) {
				$result['issues'][] = array(
					'level'   => 'warning',
					'message' => 'Rank Math title or description is empty.',
				);
			}
			if ( Navia_EL_I18n::active() && ! Navia_EL_I18n::get_lang( $post->ID ) ) {
				$result['issues'][] = array(
					'level'   => 'warning',
					'message' => 'Page has no language.',
				);
			}
		}
		return $result;
	}

	public static function get_log( $input = null ) {
		$input = (array) $input;
		return array( 'log' => Navia_EL_Log::latest( (int) ( $input['limit'] ?? 50 ), (int) ( $input['id'] ?? 0 ) ) );
	}

	public static function list_media( $input = null ) {
		$input = (array) $input;
		$args  = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => (int) ( $input['limit'] ?? 30 ),
			'orderby'        => 'date',
			'order'          => 'DESC',
		);
		if ( ! empty( $input['search'] ) ) {
			$args['s'] = (string) $input['search'];
		}
		$out = array();
		foreach ( get_posts( $args ) as $a ) {
			$meta  = wp_get_attachment_metadata( $a->ID );
			$out[] = array(
				'id'     => $a->ID,
				'url'    => wp_get_attachment_url( $a->ID ),
				'alt'    => (string) get_post_meta( $a->ID, '_wp_attachment_image_alt', true ),
				'title'  => $a->post_title,
				'width'  => (int) ( $meta['width'] ?? 0 ),
				'height' => (int) ( $meta['height'] ?? 0 ),
			);
		}
		return array( 'media' => $out );
	}



	public static function update_kit( $input = null ) {
		$g = self::guard( 'update-kit' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$settings = self::decode( ( (array) $input )['settings'] ?? null );
		if ( null === $settings ) {
			return new WP_Error( 'navia_el_kit', 'settings must be an object.' );
		}
		$r = Navia_EL_Builder::update_kit( $settings );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		self::purge();
		Navia_EL_Log::add( 'update-kit', Navia_EL_Builder::kit()->get_id(), 'Kit keys: ' . implode( ', ', array_keys( $settings ) ) );
		return Navia_EL_Builder::kit_summary();
	}

	public static function create_page( $input = null ) {
		$g = self::guard( 'create-page' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input  = (array) $input;
		$status = (string) ( $input['status'] ?? 'draft' );
		$ok     = self::check_status( $status, 'page' );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$prep = self::prepare_elements( $input['elements'] ?? null, 'page' );
		if ( is_wp_error( $prep ) ) {
			return $prep;
		}
		list( $elements, $warnings ) = $prep;

		$template = (string) ( $input['template'] ?? Navia_EL_Settings::get( 'default_template' ) );
		if ( ! array_key_exists( $template, Navia_EL_Builder::page_templates() ) ) {
			return new WP_Error( 'navia_el_template', "Unknown page template \"$template\"." );
		}

		$postarr = array(
			'post_type'    => 'page',
			'post_title'   => wp_strip_all_tags( (string) $input['title'] ),
			'post_status'  => 'draft',
			'post_content' => '',
			'post_parent'  => (int) ( $input['parent'] ?? 0 ),
			'menu_order'   => (int) ( $input['menu_order'] ?? 0 ),
		);
		if ( ! empty( $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $input['slug'] );
		}
		$id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		update_post_meta( $id, '_navia_el_created', 1 );
		update_post_meta( $id, '_wp_page_template', $template );
		update_post_meta( $id, '_elementor_template_type', 'wp-page' );

		$r = self::apply_lang( $id, $input['lang'] ?? '', $input['translations'] ?? null, $input['translation_of'] ?? 0, $warnings );
		if ( is_wp_error( $r ) ) {
			wp_delete_post( $id, true );
			return $r;
		}

		$settings = self::merge_settings( array( 'hide_title' => 'yes' ), $input['page_settings'] ?? null );
		$saved    = Navia_EL_Builder::save( $id, $elements, $settings );
		if ( is_wp_error( $saved ) ) {
			wp_delete_post( $id, true );
			return $saved;
		}
		if ( ! empty( $input['seo'] ) ) {
			$warnings = array_merge( $warnings, Navia_EL_SEO::set( $id, self::decode( $input['seo'] ) ?? array() ) );
		}
		if ( 'draft' !== $status ) {
			wp_update_post(
				array(
					'ID'          => $id,
					'post_status' => $status,
				)
			);
		}
		$post = get_post( $id );
		if ( ! empty( $postarr['post_name'] ) && $post->post_name !== $postarr['post_name'] && 'publish' === $post->post_status ) {
			$warnings[] = "Slug \"{$postarr['post_name']}\" was taken; WordPress used \"{$post->post_name}\".";
		}
		if ( ! empty( $postarr['post_name'] ) && 'publish' !== $post->post_status ) {
			update_post_meta( $id, '_navia_el_wanted_slug', $postarr['post_name'] );
		}
		return self::after_write( $post, $warnings, 'create-page', 'Created "' . $post->post_title . '" (' . Navia_EL_Tree::count( $elements ) . ' elements, ' . $status . ')' );
	}

	public static function update_document( $input = null ) {
		$g = self::guard( 'update-document' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input = (array) $input;
		$post  = self::doc( (int) $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		return self::write_document( $post, $input, 'update-document' );
	}




	private static function write_document( WP_Post $post, array $input, string $ability ) {
		$kind     = self::kind_of( $post );
		$warnings = array();
		$changes  = array();

		if ( isset( $input['elements'] ) && isset( $input['operations'] ) ) {
			return new WP_Error( 'navia_el_input', 'Pass elements or operations, not both.' );
		}

		$new_elements = null;
		if ( isset( $input['elements'] ) ) {
			$prep = self::prepare_elements( $input['elements'], $kind );
			if ( is_wp_error( $prep ) ) {
				return $prep;
			}
			list( $new_elements, $w ) = $prep;
			$warnings                 = array_merge( $warnings, $w );
			$changes[]                = 'layout replaced';
		} elseif ( isset( $input['operations'] ) ) {
			$ops = self::decode( $input['operations'] );
			if ( null === $ops ) {
				return new WP_Error( 'navia_el_input', 'operations must be an array.' );
			}
			$tree = Navia_EL_Tree::apply_operations( Navia_EL_Builder::get_elements( $post->ID ), $ops );
			if ( is_wp_error( $tree ) ) {
				return $tree;
			}
			$prep = self::prepare_elements( $tree, $kind );
			if ( is_wp_error( $prep ) ) {
				return $prep;
			}
			list( $new_elements, $w ) = $prep;
			$warnings                 = array_merge( $warnings, $w );
			$changes[]                = count( $ops ) . ' operation(s): ' . implode( ', ', array_unique( array_map( fn( $o ) => $o['op'] ?? '?', $ops ) ) );
		}

		$postarr = array( 'ID' => $post->ID );
		if ( isset( $input['title'] ) ) {
			$postarr['post_title'] = wp_strip_all_tags( (string) $input['title'] );
		}
		if ( isset( $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $input['slug'] );
		}
		if ( isset( $input['parent'] ) && 'page' === $post->post_type ) {
			$postarr['post_parent'] = (int) $input['parent'];
		}
		if ( isset( $input['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $input['menu_order'];
		}
		if ( isset( $input['status'] ) && $input['status'] !== $post->post_status ) {
			$ok = self::check_status( (string) $input['status'], $post->post_type );
			if ( is_wp_error( $ok ) ) {
				return $ok;
			}
			if ( 'publish' === $post->post_status && ! Navia_EL_Settings::can_publish() ) {
				return new WP_Error( 'navia_el_publish', 'This document is live; taking it offline needs publishing mode publish.' );
			}
			$postarr['post_status'] = (string) $input['status'];
		}
		if ( isset( $input['template'] ) && 'page' === $post->post_type ) {
			if ( ! array_key_exists( (string) $input['template'], Navia_EL_Builder::page_templates() ) ) {
				return new WP_Error( 'navia_el_template', 'Unknown page template "' . $input['template'] . '".' );
			}
		}


		$r = self::apply_lang( $post->ID, $input['lang'] ?? '', $input['translations'] ?? null, $input['translation_of'] ?? 0, $warnings );
		if ( is_wp_error( $r ) ) {
			return $r;
		}

		$settings = null;
		if ( isset( $input['page_settings'] ) ) {
			$settings  = self::merge_settings( Navia_EL_Builder::page_settings( $post->ID ), $input['page_settings'] );
			$changes[] = 'page settings';
		}

		if ( null !== $new_elements || null !== $settings ) {
			Navia_EL_Builder::backup( $post->ID );
			if ( isset( $input['template'] ) && 'page' === $post->post_type ) {
				update_post_meta( $post->ID, '_wp_page_template', (string) $input['template'] );
			}
			$saved = Navia_EL_Builder::save( $post->ID, $new_elements, $settings );
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
		} elseif ( isset( $input['template'] ) && 'page' === $post->post_type ) {
			update_post_meta( $post->ID, '_wp_page_template', (string) $input['template'] );
			$changes[] = 'template';
		}

		if ( count( $postarr ) > 1 ) {
			$r = wp_update_post( $postarr, true );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$changes[] = implode( ', ', array_keys( array_diff_key( $postarr, array( 'ID' => 1 ) ) ) );
			if ( ( $postarr['post_status'] ?? '' ) === 'publish' && ! isset( $postarr['post_name'] ) ) {
				$wanted = get_post_meta( $post->ID, '_navia_el_wanted_slug', true );
				if ( $wanted && $wanted !== get_post( $post->ID )->post_name ) {
					wp_update_post(
						array(
							'ID'        => $post->ID,
							'post_name' => $wanted,
						)
					);
				}
			}
		}
		if ( ! empty( $input['seo'] ) ) {
			$warnings  = array_merge( $warnings, Navia_EL_SEO::set( $post->ID, self::decode( $input['seo'] ) ?? array() ) );
			$changes[] = 'seo';
		}

		$after = get_post( $post->ID );
		if ( isset( $postarr['post_name'] ) && $after->post_name !== $postarr['post_name'] && 'publish' === $after->post_status ) {
			$warnings[] = "Slug \"{$postarr['post_name']}\" was taken; WordPress used \"{$after->post_name}\".";
		}
		return self::after_write( $after, $warnings, $ability, $changes ? implode( '; ', $changes ) : 'no change' );
	}

	public static function save_theme_part( $input = null ) {
		$g = self::guard( 'save-theme-part' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		if ( ! self::chf_active() ) {
			return new WP_Error( 'navia_el_chf', 'The Theme Builder module of Navia Automation Suite is off on this site (Navia Suite > Modules). With Elementor Pro, headers and footers are made in the Pro theme builder.' );
		}
		$input    = (array) $input;
		$warnings = array();
		$activate = ! empty( $input['activate'] );
		if ( $activate && ! Navia_EL_Settings::can_publish() ) {
			return new WP_Error( 'navia_el_publish', 'Activating a theme part changes every page; it needs publishing mode publish in the site settings.' );
		}

		if ( ! empty( $input['id'] ) ) {
			$post = self::doc( (int) $input['id'] );
			if ( is_wp_error( $post ) ) {
				return $post;
			}
			if ( self::chf_type() !== $post->post_type ) {
				return new WP_Error( 'navia_el_type', 'This id is not a header, footer or single template.' );
			}
			if ( ! empty( $input['type'] ) && $input['type'] !== self::theme_part_type( $post->ID ) ) {
				update_post_meta( $post->ID, '_chf_template_type', (string) $input['type'] );
			}
			if ( isset( $input['enabled'] ) ) {
				update_post_meta( $post->ID, '_chf_enabled', $input['enabled'] ? 'yes' : 'no' );
			}
			unset( $input['status'] );
			$result = self::write_document( $post, $input, 'save-theme-part' );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		} else {
			$type = (string) ( $input['type'] ?? '' );
			if ( ! in_array( $type, array( 'header', 'footer', 'single' ), true ) ) {
				return new WP_Error( 'navia_el_input', 'type must be header, footer or single.' );
			}
			if ( ! isset( $input['elements'] ) ) {
				return new WP_Error( 'navia_el_input', 'elements is required to create a template.' );
			}
			$prep = self::prepare_elements( $input['elements'], $type );
			if ( is_wp_error( $prep ) ) {
				return $prep;
			}
			list( $elements, $warnings ) = $prep;
			$lang                        = (string) ( $input['lang'] ?? '' );
			$id                          = wp_insert_post(
				array(
					'post_type'   => self::chf_type(),
					'post_title'  => wp_strip_all_tags( (string) ( $input['title'] ?? ucfirst( $type ) . ( $lang ? ' ' . strtoupper( $lang ) : '' ) ) ),
					'post_status' => 'draft',
				),
				true
			);
			if ( is_wp_error( $id ) ) {
				return $id;
			}
			update_post_meta( $id, '_navia_el_created', 1 );
			update_post_meta( $id, '_chf_template_type', $type );
			update_post_meta( $id, '_chf_enabled', ( ! isset( $input['enabled'] ) || $input['enabled'] ) ? 'yes' : 'no' );
			update_post_meta( $id, '_elementor_template_type', 'wp-post' );
			$r = self::apply_lang( $id, $lang, $input['translations'] ?? null, $input['translation_of'] ?? 0, $warnings );
			if ( is_wp_error( $r ) ) {
				wp_delete_post( $id, true );
				return $r;
			}
			$saved = Navia_EL_Builder::save( $id, $elements, array() );
			if ( is_wp_error( $saved ) ) {
				wp_delete_post( $id, true );
				return $saved;
			}
			$result = self::after_write( get_post( $id ), $warnings, 'save-theme-part', "Created $type template" );
		}

		if ( $activate ) {
			$id   = (int) $result['id'];
			$type = self::theme_part_type( $id );
			$lang = Navia_EL_I18n::get_lang( $id );
			wp_update_post(
				array(
					'ID'          => $id,
					'post_status' => 'publish',
				)
			);
			update_post_meta( $id, '_chf_enabled', 'yes' );
			$others = get_posts(
				array(
					'post_type'      => self::chf_type(),
					'post_status'    => 'publish',
					'posts_per_page' => 50,
					'post__not_in'   => array( $id ),
					'fields'         => 'ids',
					'lang'           => $lang,
					'meta_query'     => array(
						array(
							'key'   => '_chf_template_type',
							'value' => $type,
						),
					),
				)
			);
			$switched_off = array();
			foreach ( $others as $other ) {
				if ( 'no' !== get_post_meta( $other, '_chf_enabled', true ) ) {
					update_post_meta( $other, '_chf_enabled', 'no' );
					$switched_off[] = $other;
				}
			}
			self::purge();
			Navia_EL_Log::add( 'save-theme-part', $id, "Activated $type" . ( $lang ? " ($lang)" : '' ) . ( $switched_off ? '; switched off ' . implode( ', ', $switched_off ) : '' ) );
			$result                 = self::summary( get_post( $id ) ) + array( 'warnings' => $result['warnings'] ?? array() );
			$result['switched_off'] = $switched_off;
		}
		return $result;
	}

	public static function clone_document( $input = null ) {
		$g = self::guard( 'clone-document' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input = (array) $input;
		$src   = self::doc( (int) $input['id'] );
		if ( is_wp_error( $src ) ) {
			return $src;
		}
		$lang     = (string) ( $input['lang'] ?? '' );
		$warnings = array();
		$postarr  = array(
			'post_type'   => $src->post_type,
			'post_title'  => wp_strip_all_tags( (string) ( $input['title'] ?? $src->post_title . ( $lang ? ' (' . strtoupper( $lang ) . ')' : ' (copy)' ) ) ),
			'post_status' => 'draft',
			'post_parent' => $src->post_parent,
			'menu_order'  => $src->menu_order,
		);
		if ( ! empty( $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $input['slug'] );
		}
		$id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		update_post_meta( $id, '_navia_el_created', 1 );
		foreach ( array( '_wp_page_template', '_elementor_template_type', '_chf_template_type', '_chf_enabled' ) as $k ) {
			$v = get_post_meta( $src->ID, $k, true );
			if ( '' !== $v ) {
				update_post_meta( $id, $k, $v );
			}
		}
		$robots = get_post_meta( $src->ID, 'rank_math_robots', true );
		if ( $robots ) {
			update_post_meta( $id, 'rank_math_robots', $robots );
		}
		if ( ! empty( $postarr['post_name'] ) ) {
			update_post_meta( $id, '_navia_el_wanted_slug', $postarr['post_name'] );
		}
		if ( $lang ) {
			$r = self::apply_lang( $id, $lang, null, Navia_EL_I18n::get_lang( $src->ID ) ? $src->ID : 0, $warnings );
			if ( is_wp_error( $r ) ) {
				wp_delete_post( $id, true );
				return $r;
			}
		}
		$saved = Navia_EL_Builder::save( $id, Navia_EL_Builder::get_elements( $src->ID ), Navia_EL_Builder::page_settings( $src->ID ) );
		if ( is_wp_error( $saved ) ) {
			wp_delete_post( $id, true );
			return $saved;
		}
		if ( $lang ) {
			$warnings[] = 'Texts and links are still in the original language: read get-document mode texts and send set_text operations.';
		}
		return self::after_write( get_post( $id ), $warnings, 'clone-document', "Copy of {$src->ID}" . ( $lang ? " in $lang" : '' ) );
	}

	public static function restore_revision( $input = null ) {
		$g = self::guard( 'restore-revision' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input = (array) $input;
		$post  = self::doc( (int) $input['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$r = Navia_EL_Builder::restore( $post->ID, (int) $input['revision_id'] );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return self::after_write( $post, array(), 'restore-revision', 'Restored revision ' . (int) $input['revision_id'] );
	}

	public static function get_preview_link( $input = null ) {
		$input = (array) $input;
		$post  = self::doc( (int) $input['id'], false );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		foreach ( array( 'header_id', 'footer_id', 'single_id' ) as $k ) {
			if ( ! empty( $input[ $k ] ) && self::chf_type() !== get_post_type( (int) $input[ $k ] ) ) {
				return new WP_Error( 'navia_el_input', "$k is not a header, footer or single template." );
			}
		}
		$hours = (int) ( $input['hours'] ?? Navia_EL_Settings::get( 'preview_hours' ) );
		$link  = Navia_EL_Preview::create(
			$post->ID,
			max( 1, min( 168, $hours ) ),
			array(
				'header' => (int) ( $input['header_id'] ?? 0 ),
				'footer' => (int) ( $input['footer_id'] ?? 0 ),
				'single' => (int) ( $input['single_id'] ?? 0 ),
			)
		);
		Navia_EL_Log::add( 'get-preview-link', $post->ID, 'Preview link until ' . $link['expires'] );
		return $link + array( 'id' => $post->ID );
	}

	public static function save_menu( $input = null ) {
		$g = self::guard( 'save-menu' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input = (array) $input;
		$items = self::decode( $input['items'] ?? null );
		if ( null === $items ) {
			return new WP_Error( 'navia_el_input', 'items must be an array.' );
		}
		$menu_id = (int) ( $input['id'] ?? 0 );
		if ( ! $menu_id ) {
			$name = trim( (string) ( $input['name'] ?? '' ) );
			if ( '' === $name ) {
				return new WP_Error( 'navia_el_input', 'Give the menu an id or a name.' );
			}
			$existing = wp_get_nav_menu_object( $name );
			$menu_id  = $existing ? (int) $existing->term_id : wp_create_nav_menu( $name );
			if ( is_wp_error( $menu_id ) ) {
				return $menu_id;
			}
		} elseif ( ! wp_get_nav_menu_object( $menu_id ) ) {
			return new WP_Error( 'navia_el_not_found', "Menu $menu_id not found." );
		}


		foreach ( array_values( $items ) as $i => $item ) {
			if ( ! is_array( $item ) ) {
				return new WP_Error( 'navia_el_input', "Item $i is not an object." );
			}
			$type = $item['type'] ?? ( ! empty( $item['page_id'] ) ? 'page' : 'custom' );
			if ( 'page' === $type && ( empty( $item['page_id'] ) || ! get_post( (int) $item['page_id'] ) ) ) {
				return new WP_Error( 'navia_el_input', "Item $i: page " . ( $item['page_id'] ?? '?' ) . ' not found.' );
			}
			if ( 'custom' === $type && empty( $item['url'] ) ) {
				return new WP_Error( 'navia_el_input', "Item $i needs page_id or url." );
			}
			if ( isset( $item['parent'] ) && ( (int) $item['parent'] >= $i || (int) $item['parent'] < 0 ) ) {
				return new WP_Error( 'navia_el_input', "Item $i: parent must be the index of an earlier item." );
			}
		}

		foreach ( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) as $old ) {
			wp_delete_post( $old->ID, true );
		}
		$db_ids = array();
		$out    = array();
		foreach ( array_values( $items ) as $i => $item ) {
			$type = $item['type'] ?? ( ! empty( $item['page_id'] ) ? 'page' : 'custom' );
			$args = array(
				'menu-item-status'    => 'publish',
				'menu-item-position'  => $i + 1,
				'menu-item-classes'   => sanitize_text_field( (string) ( $item['classes'] ?? '' ) ),
				'menu-item-parent-id' => isset( $item['parent'] ) ? (int) $db_ids[ (int) $item['parent'] ] : 0,
			);
			if ( ! empty( $item['new_tab'] ) ) {
				$args['menu-item-target'] = '_blank';
			}
			if ( 'page' === $type ) {
				$args['menu-item-type']      = 'post_type';
				$args['menu-item-object']    = 'page';
				$args['menu-item-object-id'] = (int) $item['page_id'];
				if ( ! empty( $item['title'] ) ) {
					$args['menu-item-title'] = sanitize_text_field( (string) $item['title'] );
				}
			} elseif ( 'language_switcher' === $type ) {
				$args['menu-item-type']  = 'custom';
				$args['menu-item-url']   = '#pll_switcher';
				$args['menu-item-title'] = sanitize_text_field( (string) ( $item['title'] ?? 'Languages' ) );
			} else {
				$args['menu-item-type']  = 'custom';
				$args['menu-item-url']   = esc_url_raw( (string) $item['url'] );
				$args['menu-item-title'] = sanitize_text_field( (string) ( $item['title'] ?? $item['url'] ) );
			}
			$db_id = wp_update_nav_menu_item( $menu_id, 0, $args );
			if ( is_wp_error( $db_id ) ) {
				return $db_id;
			}
			if ( 'language_switcher' === $type ) {
				update_post_meta( $db_id, '_pll_menu_item', Navia_EL_I18n::switcher_options( $item ) );
			}
			$db_ids[ $i ] = $db_id;
			$out[]        = array(
				'index' => $i,
				'id'    => $db_id,
				'title' => get_the_title( $db_id ) ?: ( $args['menu-item-title'] ?? '' ),
			);
		}
		$menu = wp_get_nav_menu_object( $menu_id );
		self::purge();
		Navia_EL_Log::add( 'save-menu', $menu_id, 'Menu "' . $menu->name . '" with ' . count( $items ) . ' items' );
		return array(
			'menu_id' => $menu_id,
			'name'    => $menu->name,
			'slug'    => $menu->slug,
			'items'   => $out,
		);
	}

	public static function update_site_settings( $input = null ) {
		$g = self::guard( 'update-site-settings' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input   = (array) $input;
		$changed = array();
		foreach ( array( 'blogname', 'blogdescription' ) as $k ) {
			if ( isset( $input[ $k ] ) ) {
				update_option( $k, sanitize_text_field( (string) $input[ $k ] ) );
				$changed[] = $k;
			}
		}
		foreach ( array(
			'front_page_id' => 'page_on_front',
			'posts_page_id' => 'page_for_posts',
		) as $k => $opt ) {
			if ( ! isset( $input[ $k ] ) ) {
				continue;
			}
			$pid = (int) $input[ $k ];
			if ( $pid && 'page' !== get_post_type( $pid ) ) {
				return new WP_Error( 'navia_el_input', "$k must be a page." );
			}
			if ( $pid && Navia_EL_I18n::active() ) {
				$def = Navia_EL_I18n::default_lang();
				$own = Navia_EL_I18n::get_lang( $pid );
				if ( $own && $own !== $def ) {
					$tr = Navia_EL_I18n::translations( $pid );
					if ( empty( $tr[ $def ] ) ) {
						return new WP_Error( 'navia_el_lang', "Page $pid is in $own; Polylang needs the $def version as $k. Create and link it first." );
					}
					$pid = (int) $tr[ $def ];
				}
			}
			update_option( $opt, $pid );
			if ( 'page_on_front' === $opt ) {
				update_option( 'show_on_front', $pid ? 'page' : 'posts' );
			}
			$changed[] = $opt;
		}
		if ( isset( $input['site_icon_id'] ) ) {
			$icon = (int) $input['site_icon_id'];
			if ( $icon && ! wp_attachment_is_image( $icon ) ) {
				return new WP_Error( 'navia_el_input', 'site_icon_id must be an image.' );
			}
			update_option( 'site_icon', $icon );
			$changed[] = 'site_icon';
		}
		if ( isset( $input['permalink_structure'] ) ) {
			$p = trim( (string) $input['permalink_structure'] );
			if ( '' !== $p && ( ! str_starts_with( $p, '/' ) || ! str_contains( $p, '%postname%' ) ) ) {
				return new WP_Error( 'navia_el_input', 'permalink_structure must start with / and contain %postname%, for example /artigos/%postname%/.' );
			}
			global $wp_rewrite;
			$wp_rewrite->set_permalink_structure( $p );
			flush_rewrite_rules( false );
			$changed[] = 'permalink_structure';
		}
		if ( isset( $input['search_engines'] ) ) {
			update_option( 'blog_public', 'visible' === $input['search_engines'] ? '1' : '0' );
			$changed[] = 'blog_public';
		}
		self::purge();
		Navia_EL_Log::add( 'update-site-settings', 0, 'Changed: ' . implode( ', ', $changed ) );
		return array(
			'changed' => $changed,
			'site'    => self::get_context()['site'],
		);
	}

	public static function setup_languages( $input = null ) {
		$g = self::guard( 'setup-languages' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input = (array) $input;
		$langs = self::decode( $input['languages'] ?? null );
		if ( ! $langs ) {
			return new WP_Error( 'navia_el_input', 'languages must be a list such as [{"locale": "en_GB"}, {"locale": "pt_PT"}].' );
		}
		$r = Navia_EL_I18n::setup( $langs, (string) $input['default'], $input );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		self::purge();
		Navia_EL_Log::add( 'setup-languages', 0, implode( '; ', $r['report'] ) );
		return $r;
	}

	public static function check_uniqueness( $input = null ) {
		$input = (array) $input;
		$id    = ! empty( $input['id'] ) ? (int) $input['id'] : null;
		if ( $id ) {
			$post = self::doc( $id, false );
			if ( is_wp_error( $post ) ) {
				return $post;
			}
		}
		return Navia_EL_Unique::check( $id, $input );
	}

	public static function rebuild_uniqueness_index( $input = null ) {
		$input  = (array) $input;
		$cursor = self::decode( $input['cursor'] ?? null );
		$r      = Navia_EL_Unique::rebuild( $cursor ?: null );
		if ( $r['done'] ) {
			Navia_EL_Log::add( 'rebuild-uniqueness-index', 0, "Index rebuilt: {$r['docs']} documents in {$r['sites']} sites" );
		}
		return $r;
	}

	public static function validate_site( $input = null ) {
		$input    = (array) $input;
		$statuses = array(
			'any'     => array( 'publish', 'draft', 'pending', 'future' ),
			'publish' => array( 'publish' ),
			'draft'   => array( 'draft', 'pending' ),
		)[ $input['status'] ?? 'any' ] ?? array( 'publish', 'draft', 'pending', 'future' );
		$types    = array( 'page' );
		if ( self::chf_active() ) {
			$types[] = self::chf_type();
		}
		if ( ! empty( $input['include_posts'] ) || ! isset( $input['include_posts'] ) ) {
			$types[] = 'post';
		}
		$docs   = get_posts(
			array(
				'post_type'      => $types,
				'post_status'    => $statuses,
				'posts_per_page' => 300,
				'lang'           => '',
				'orderby'        => 'type title',
				'order'          => 'ASC',
			)
		);
		$report = array();
		$totals = array(
			'documents' => 0,
			'errors'    => 0,
			'warnings'  => 0,
		);
		$start  = microtime( true );
		foreach ( $docs as $post ) {
			if ( microtime( true ) - $start > 45 ) {
				$report[] = array( 'stopped' => 'Time limit reached; run check-document on the remaining documents.' );
				break;
			}
			$row = array(
				'id'     => $post->ID,
				'title'  => $post->post_title,
				'kind'   => 'post' === $post->post_type ? 'post' : self::kind_of( $post ),
				'status' => $post->post_status,
				'lang'   => Navia_EL_I18n::get_lang( $post->ID ),
			);
			if ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
				$r      = self::check_document( array( 'id' => $post->ID ) );
				$issues = is_wp_error( $r ) ? array(
					array(
						'level'   => 'error',
						'message' => $r->get_error_message(),
					),
				) : $r['issues'];
			} else {
				$text   = Navia_EL_Unique::text_of( $post );
				$heads  = array();
				if ( preg_match_all( '#<h[2-4][^>]*>(.*?)</h[2-4]>#is', (string) $post->post_content, $m ) ) {
					$heads = array_map( 'wp_strip_all_tags', $m[1] );
				}
				$issues = Navia_EL_Style::check( $text, $row['lang'], $heads );
				$seo    = Navia_EL_SEO::get( $post->ID );
				if ( '' === $seo['title'] || '' === $seo['description'] ) {
					$issues[] = array(
						'level'   => 'warning',
						'message' => 'Rank Math title or description is empty.',
					);
				}
			}
			$row['errors']   = count( array_filter( $issues, fn( $i ) => 'error' === ( $i['level'] ?? '' ) ) );
			$row['warnings'] = count( array_filter( $issues, fn( $i ) => 'warning' === ( $i['level'] ?? '' ) ) );
			if ( $issues ) {
				$row['issues'] = array_map(
					fn( $i ) => ( $i['message'] ?? '' ) . ( ! empty( $i['elements'] ) ? ' [' . implode( ', ', $i['elements'] ) . ']' : ( ! empty( $i['element'] ) ? ' [' . $i['element'] . ']' : '' ) ),
					array_slice( $issues, 0, 12 )
				);
			}
			$totals['documents']++;
			$totals['errors']   += $row['errors'];
			$totals['warnings'] += $row['warnings'];
			$report[]            = $row;
		}
		$unique = Navia_EL_Unique::check( null, array() );
		Navia_EL_Log::add( 'validate-site', 0, "{$totals['documents']} documents, {$totals['errors']} errors, {$totals['warnings']} warnings, " . count( $unique['pairs'] ) . ' uniqueness findings' );
		return array(
			'totals'     => $totals + array( 'uniqueness_findings' => count( $unique['pairs'] ) ),
			'documents'  => $report,
			'uniqueness' => $unique,
		);
	}

	private static function media_host_allowed( string $host ): bool {
		$host  = strtolower( $host );
		$hosts = array( wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( is_multisite() ) {
			$net     = wp_parse_url( network_home_url(), PHP_URL_HOST );
			$hosts[] = $net;
			if ( str_ends_with( $host, '.' . $net ) ) {
				return true;
			}
		}
		foreach ( preg_split( '/\s+/', (string) Navia_EL_Settings::get( 'media_hosts' ) ) as $h ) {
			if ( '' !== $h ) {
				$hosts[] = strtolower( $h );
			}
		}
		return in_array( $host, array_map( 'strtolower', array_filter( $hosts ) ), true );
	}

	public static function upload_media( $input = null ) {
		$g = self::guard( 'upload-media' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$input = (array) $input;
		$alt   = trim( sanitize_text_field( (string) ( $input['alt'] ?? '' ) ) );
		if ( '' === $alt ) {
			return new WP_Error( 'navia_el_input', 'alt is required.' );
		}
		if ( ! empty( $input['data_base64'] ) ) {
			$raw = preg_replace( '#^data:[^;]+;base64,#', '', (string) $input['data_base64'] );
			$bin = base64_decode( $raw, true );
			if ( false === $bin ) {
				return new WP_Error( 'navia_el_input', 'data_base64 is not valid base64.' );
			}
		} elseif ( ! empty( $input['url'] ) ) {
			$url  = esc_url_raw( (string) $input['url'] );
			$host = (string) wp_parse_url( $url, PHP_URL_HOST );
			if ( ! $host || ! self::media_host_allowed( $host ) ) {
				return new WP_Error( 'navia_el_host', "Host $host is not allowed. Add it to the media hosts in the settings." );
			}
			$resp = wp_safe_remote_get(
				$url,
				array(
					'timeout' => 20,
					'limit_response_size' => 8 * MB_IN_BYTES,
				)
			);
			if ( is_wp_error( $resp ) || 200 !== wp_remote_retrieve_response_code( $resp ) ) {
				return new WP_Error( 'navia_el_fetch', 'Could not download the image.' );
			}
			$bin = wp_remote_retrieve_body( $resp );
		} else {
			return new WP_Error( 'navia_el_input', 'Give data_base64 or url.' );
		}
		if ( strlen( $bin ) > 8 * MB_IN_BYTES ) {
			return new WP_Error( 'navia_el_size', 'Images are limited to 8 MB.' );
		}
		$info = @getimagesizefromstring( $bin );
		$ext  = array(
			'image/png'  => 'png',
			'image/jpeg' => 'jpg',
			'image/webp' => 'webp',
			'image/gif'  => 'gif',
		);
		if ( ! $info || ! isset( $ext[ $info['mime'] ] ) ) {
			return new WP_Error( 'navia_el_type', 'Only PNG, JPEG, WebP or GIF images.' );
		}
		$name = sanitize_file_name( pathinfo( (string) $input['filename'], PATHINFO_FILENAME ) );
		$name = $name ? $name : 'image';
		$up   = wp_upload_bits( $name . '.' . $ext[ $info['mime'] ], null, $bin );
		if ( ! empty( $up['error'] ) ) {
			return new WP_Error( 'navia_el_upload', $up['error'] );
		}
		$file = $up['file'];
		$mime = $info['mime'];
		if ( ( ! isset( $input['convert_webp'] ) || $input['convert_webp'] ) && in_array( $mime, array( 'image/png', 'image/jpeg' ), true ) ) {
			$editor = wp_get_image_editor( $file );
			if ( ! is_wp_error( $editor ) && $editor->supports_mime_type( 'image/webp' ) ) {
				$editor->set_quality( 82 );
				$webp = preg_replace( '/\.(png|jpe?g)$/i', '.webp', $file );
				$res  = $editor->save( $webp, 'image/webp' );
				if ( ! is_wp_error( $res ) ) {
					wp_delete_file( $file );
					$file = $res['path'];
					$mime = 'image/webp';
				}
			}
		}
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$att = wp_insert_attachment(
			array(
				'post_mime_type' => $mime,
				'post_title'     => sanitize_text_field( (string) ( $input['title'] ?? $alt ) ),
				'post_status'    => 'inherit',
			),
			$file,
			0,
			true
		);
		if ( is_wp_error( $att ) ) {
			return $att;
		}
		wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $file ) );
		update_post_meta( $att, '_wp_attachment_image_alt', $alt );
		$meta = wp_get_attachment_metadata( $att );
		Navia_EL_Log::add( 'upload-media', $att, 'Uploaded ' . basename( $file ) );
		return array(
			'id'     => $att,
			'url'    => wp_get_attachment_url( $att ),
			'alt'    => $alt,
			'width'  => (int) ( $meta['width'] ?? 0 ),
			'height' => (int) ( $meta['height'] ?? 0 ),
		);
	}

	public static function site_css( $input = null ) {
		$input = (array) $input;
		if ( ! isset( $input['css'] ) ) {
			return array( 'css' => Navia_EL_Site_CSS::get() );
		}
		$g = self::guard( 'site-css' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$css = Navia_EL_Site_CSS::set( (string) $input['css'] );
		if ( is_wp_error( $css ) ) {
			return $css;
		}
		self::purge();
		Navia_EL_Log::add( 'site-css', 0, 'Site CSS ' . strlen( $css ) . ' bytes' );
		return array(
			'css'   => $css,
			'bytes' => strlen( $css ),
		);
	}

	public static function save_design_notes( $input = null ) {
		$notes = (string) ( ( (array) $input )['notes'] ?? '' );
		if ( strlen( $notes ) > 60000 ) {
			return new WP_Error( 'navia_el_size', 'Design notes are limited to 60 KB.' );
		}
		Navia_EL_Settings::save_notes( wp_kses_post( $notes ) );
		Navia_EL_Log::add( 'save-design-notes', 0, strlen( $notes ) . ' bytes' );
		return array(
			'saved' => true,
			'bytes' => strlen( $notes ),
		);
	}

	public static function trash_document( $input = null ) {
		$g = self::guard( 'trash-document' );
		if ( is_wp_error( $g ) ) {
			return $g;
		}
		$post = self::doc( (int) ( (array) $input )['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		if ( 'any' !== Navia_EL_Settings::get( 'trash_scope' ) && ! get_post_meta( $post->ID, '_navia_el_created', true ) ) {
			return new WP_Error( 'navia_el_trash', 'Only documents created through these abilities can be trashed here.' );
		}
		if ( (int) get_option( 'page_on_front' ) === $post->ID || (int) get_option( 'page_for_posts' ) === $post->ID ) {
			return new WP_Error( 'navia_el_trash', 'This is the front page or posts page. Change that first.' );
		}
		$was_live = 'publish' === $post->post_status;
		wp_trash_post( $post->ID );
		Navia_EL_Preview::revoke( $post->ID );
		if ( $was_live ) {
			self::purge();
		}
		Navia_EL_Log::add( 'trash-document', $post->ID, 'Trashed "' . $post->post_title . '"' );
		return array(
			'id'      => $post->ID,
			'trashed' => true,
		);
	}
}
