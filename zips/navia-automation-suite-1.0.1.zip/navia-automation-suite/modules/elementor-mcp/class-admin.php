<?php




defined( 'ABSPATH' ) || exit;

class Navia_EL_Admin {

	const SLUG = 'navia-elementor-mcp';

	public static function init(): void {
		add_action( 'network_admin_menu', array( __CLASS__, 'network_menu' ) );
		add_action( 'admin_menu', array( __CLASS__, 'site_menu' ) );
		add_action( 'admin_post_navia_el_save_site', array( __CLASS__, 'save_site' ) );
		add_action( 'network_admin_edit_navia_el_save_network', array( __CLASS__, 'save_network' ) );
		add_action( 'network_admin_edit_navia_el_rebuild', array( __CLASS__, 'rebuild' ) );
		add_action( 'admin_post_navia_el_rebuild', array( __CLASS__, 'rebuild' ) );
	}

	public static function missing_elementor_notice(): void {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>Navia Elementor MCP needs Elementor (the free version is enough).</p></div>';
		}
	}

	public static function missing_abilities_notice(): void {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>Navia Elementor MCP needs WordPress 6.9 or newer (Abilities API).</p></div>';
		}
	}

	public static function site_links( $links ) {
		if ( Navia_EL_Settings::site_enabled() ) {
			array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Settings</a>' );
		}
		return $links;
	}

	public static function network_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( network_admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Settings</a>' );
		return $links;
	}

	public static function network_menu(): void {
		add_submenu_page( NAS_Admin::MENU, 'Elementor (MCP)', 'Elementor (MCP)', 'manage_network_options', self::SLUG, array( __CLASS__, 'network_page' ) );
	}

	public static function site_menu(): void {
		if ( ! Navia_EL_Settings::site_enabled() ) {
			return;
		}
		add_submenu_page( NAS_Admin::MENU, 'Elementor (MCP)', 'Elementor (MCP)', 'manage_options', self::SLUG, array( __CLASS__, 'site_page' ) );
	}

	public static function network_page(): void {
		if ( ! current_user_can( 'manage_network_options' ) ) {
			return;
		}
		$net = Navia_EL_Settings::network();
		echo '<div class="wrap"><h1>Navia Suite: Elementor (MCP)</h1>';
		if ( isset( $_GET['updated'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<p>Tick the sites where AI agents may build with Elementor. Each site then has its own page under Navia Suite > Elementor (MCP), where publishing stays off until you switch it on.</p>';
		echo '<form method="post" action="' . esc_url( network_admin_url( 'edit.php?action=navia_el_save_network' ) ) . '">';
		wp_nonce_field( 'navia_el_network' );
		echo '<table class="widefat striped" style="max-width:720px"><thead><tr><th style="width:40px"></th><th>Site</th><th>ID</th></tr></thead><tbody>';
		foreach ( get_sites( array( 'number' => 500 ) ) as $site ) {
			$checked = NAS_Settings::module_on( 'elementor_mcp', (int) $site->blog_id );
			printf(
				'<tr><td><input type="checkbox" name="enabled_sites[]" value="%1$d" %2$s></td><td>%3$s</td><td>%1$d</td></tr>',
				(int) $site->blog_id,
				checked( $checked, true, false ),
				esc_html( $site->domain . $site->path )
			);
		}
		echo '</tbody></table>';
		submit_button( 'Save' );
		echo '</form>';
		self::index_box( network_admin_url( 'edit.php?action=navia_el_rebuild' ) );
		echo '</div>';
	}




	private static function index_box( string $action ): void {
		$s = Navia_EL_Unique::status();
		echo '<h2>Uniqueness index</h2>';
		echo '<p>Every page and post of every site, reduced to fingerprints and kept up to date on save. The check (button on each site, or check-uniqueness and validate-site over MCP) compares a site with all the others. Rebuild once after installing, and whenever sites are listed below as never indexed.</p>';
		printf(
			'<p><strong>%d</strong> documents from <strong>%d</strong> of %d sites. Last full rebuild: %s.%s</p>',
			(int) $s['documents'],
			(int) $s['sites_indexed'],
			(int) $s['sites_in_network'],
			esc_html( $s['last_rebuild'] ? $s['last_rebuild'] : 'never' ),
			$s['sites_never_seen'] ? ' Never indexed: ' . esc_html( implode( ', ', $s['sites_never_seen'] ) ) . '.' : ''
		);
		echo '<p><a class="button button-secondary" href="' . esc_url( wp_nonce_url( $action, 'navia_el_rebuild' ) ) . '">Rebuild the index now</a> <span class="description">Runs in slices of about 15 seconds; keep the tab open until it says done.</span></p>';
	}

	public static function rebuild(): void {
		$cap = NAS_Env::network_mode() ? 'manage_network_options' : 'manage_options';
		if ( ! current_user_can( $cap ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'navia_el_rebuild' );
		$cursor = null;
		if ( ! empty( $_GET['cursor'] ) ) {
			$cursor = json_decode( base64_decode( sanitize_text_field( wp_unslash( $_GET['cursor'] ) ) ), true );
		}
		$r    = Navia_EL_Unique::rebuild( is_array( $cursor ) ? $cursor : null, 15 );
		$back = NAS_Env::network_mode() ? network_admin_url( 'admin.php?page=' . self::SLUG ) : admin_url( 'admin.php?page=' . self::SLUG . '&tab=unique' );
		if ( $r['done'] ) {
			Navia_EL_Log::add( 'rebuild-uniqueness-index', 0, "Index rebuilt from the admin: {$r['docs']} documents in {$r['sites']} sites" );
			wp_safe_redirect( add_query_arg( 'updated', 1, $back ) );
			exit;
		}
		$base = NAS_Env::network_mode() ? network_admin_url( 'edit.php?action=navia_el_rebuild' ) : admin_url( 'admin-post.php?action=navia_el_rebuild' );
		$next = wp_nonce_url( add_query_arg( 'cursor', rawurlencode( base64_encode( wp_json_encode( $r['cursor'] ) ) ), $base ), 'navia_el_rebuild' );
		$pct  = $r['sites'] ? round( 100 * $r['cursor']['site'] / $r['sites'] ) : 0;
		echo '<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="1;url=' . esc_url( $next ) . '"><title>Rebuilding</title>';
		echo '<p style="font:16px sans-serif;margin:40px">Rebuilding the uniqueness index: ' . (int) $r['docs'] . ' documents so far, site ' . (int) ( $r['cursor']['site'] + 1 ) . ' of ' . (int) $r['sites'] . ' (' . (int) $pct . '%). Keep this tab open.</p>';
		exit;
	}

	public static function save_network(): void {
		if ( ! current_user_can( 'manage_network_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'navia_el_network' );
		$sites = isset( $_POST['enabled_sites'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['enabled_sites'] ) ) : array();
		Navia_EL_Settings::save_network( array( 'enabled_sites' => $sites ) );
		NAS_Settings::set_module_sites( 'elementor_mcp', $sites );
		wp_safe_redirect( network_admin_url( 'admin.php?page=' . self::SLUG . '&updated=1' ) );
		exit;
	}

	private static function row( string $label, string $field, string $help = '' ): void {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . $field;
		if ( $help ) {
			echo '<p class="description">' . esc_html( $help ) . '</p>';
		}
		echo '</td></tr>';
	}

	private static function checkbox( string $name, bool $value ): string {
		return '<input type="hidden" name="' . esc_attr( $name ) . '" value="0"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . '>';
	}

	private static function select( string $name, string $value, array $options ): string {
		$html = '<select name="' . esc_attr( $name ) . '">';
		foreach ( $options as $k => $label ) {
			$html .= '<option value="' . esc_attr( $k ) . '" ' . selected( $value, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		return $html . '</select>';
	}

	public static function site_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s   = Navia_EL_Settings::site();
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'settings';
		$url = admin_url( 'admin.php?page=' . self::SLUG );

		echo '<div class="wrap"><h1>Navia Suite: Elementor (MCP)</h1>';
		echo '<nav class="nav-tab-wrapper">';
		foreach ( array(
			'settings' => 'Settings',
			'notes'    => 'Design notes',
			'unique'   => 'Uniqueness',
			'log'      => 'Log',
		) as $k => $label ) {
			printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( add_query_arg( 'tab', $k, $url ) ), $tab === $k ? 'nav-tab-active' : '', esc_html( $label ) );
		}
		echo '</nav>';
		if ( isset( $_GET['updated'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}

		if ( 'unique' === $tab ) {
			self::unique_tab( $url );
			echo '</div>';
			return;
		}

		if ( 'log' === $tab ) {
			echo '<table class="widefat striped"><thead><tr><th>Date</th><th>User</th><th>Ability</th><th>Object</th><th>Summary</th><th>Result</th></tr></thead><tbody>';
			foreach ( Navia_EL_Log::latest( 200 ) as $e ) {
				printf(
					'<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td><td>%s</td></tr>',
					esc_html( $e['time'] ),
					esc_html( $e['user'] ),
					esc_html( $e['ability'] ),
					$e['object'] ? '<a href="' . esc_url( get_edit_post_link( (int) $e['object'] ) ?: '#' ) . '">' . (int) $e['object'] . '</a>' : '',
					esc_html( $e['summary'] ),
					esc_html( $e['result'] )
				);
			}
			echo '</tbody></table></div>';
			return;
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="navia_el_save_site"><input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';
		wp_nonce_field( 'navia_el_site' );

		if ( 'notes' === $tab ) {
			echo '<p>What the agent reads at the start of every session (get-guide). The agent writes it with save-design-notes; you can correct it here.</p>';
			echo '<textarea name="notes" rows="24" class="large-text code">' . esc_textarea( Navia_EL_Settings::notes() ) . '</textarea>';
			submit_button( 'Save notes' );
			echo '</form></div>';
			return;
		}

		echo '<table class="form-table" role="presentation">';
		self::row(
			'Publishing',
			self::select(
				'publish_mode',
				$s['publish_mode'],
				array(
					'draft'   => 'Drafts only (you publish)',
					'publish' => 'Agent may publish pages and activate headers and footers',
				)
			),
			'Use "may publish" while a site is being built and not yet public, then go back to drafts only.'
		);
		self::row( 'Global styles', self::checkbox( 'allow_kit', $s['allow_kit'] ) . ' Colours, fonts and theme style of the Elementor kit' );
		self::row( 'Menus', self::checkbox( 'allow_menus', $s['allow_menus'] ) . ' Create and replace menus' );
		self::row( 'Site CSS', self::checkbox( 'allow_css', $s['allow_css'] ) . ' The small CSS block printed by this plugin' );
		self::row( 'Site settings', self::checkbox( 'allow_site', $s['allow_site'] ) . ' Front page, posts page, title, icon, permalinks, search engine visibility' );
		self::row(
			'Trash',
			self::checkbox( 'allow_trash', $s['allow_trash'] ) . ' Move to trash ' . self::select(
				'trash_scope',
				$s['trash_scope'],
				array(
					'own' => 'only what the agent created',
					'any' => 'any page or template',
				)
			)
		);
		self::row(
			'Default page template',
			self::select(
				'default_template',
				$s['default_template'],
				array(
					'elementor_header_footer' => 'Elementor Full Width (header and footer)',
					'elementor_canvas'        => 'Elementor Canvas (no header or footer)',
					'default'                 => 'Theme default',
				)
			)
		);
		self::row( 'Preview links', '<input type="number" min="1" max="168" name="preview_hours" value="' . (int) $s['preview_hours'] . '"> hours' );
		self::row( 'Write limit', '<input type="number" min="5" max="600" name="writes_per_minute" value="' . (int) $s['writes_per_minute'] . '"> writes per minute' );
		self::row( 'Media hosts', '<textarea name="media_hosts" rows="3" class="regular-text code">' . esc_textarea( $s['media_hosts'] ) . '</textarea>', 'Extra hosts upload-media may download images from, one per line. This network is always allowed.' );
		echo '</table>';
		submit_button();
		echo '</form></div>';
	}

	private static function unique_tab( string $url ): void {
		if ( ! NAS_Env::network_mode() ) {
			self::index_box( admin_url( 'admin-post.php?action=navia_el_rebuild' ) );
		} else {
			$s = Navia_EL_Unique::status();
			printf( '<p>Network index: %d documents from %d of %d sites (last full rebuild %s). Rebuilt from Network Admin > Navia Suite > Elementor (MCP).</p>', (int) $s['documents'], (int) $s['sites_indexed'], (int) $s['sites_in_network'], esc_html( $s['last_rebuild'] ? $s['last_rebuild'] : 'never' ) );
		}
		$run = add_query_arg(
			array(
				'tab' => 'unique',
				'run' => 1,
			),
			$url
		);
		echo '<p><a class="button button-primary" href="' . esc_url( wp_nonce_url( $run, 'navia_el_unique' ) ) . '">Check this site against the network</a></p>';
		if ( empty( $_GET['run'] ) || ! check_admin_referer( 'navia_el_unique' ) ) {
			return;
		}
		$r = Navia_EL_Unique::check( null, array() );
		if ( ! $r['pairs'] ) {
			echo '<div class="notice notice-success"><p>No repeated passages found.</p></div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>Here</th><th>Also in</th><th>Overlap</th><th>Repeated passages</th></tr></thead><tbody>';
		foreach ( $r['pairs'] as $p ) {
			$passages = '';
			foreach ( $p['passages'] as $x ) {
				$passages .= '<p>' . esc_html( $x['text'] ) . ' <em>(' . (int) $x['words'] . ' words' . ( ! empty( $x['element'] ) ? ', element ' . esc_html( $x['element']['id'] ) : '' ) . ')</em></p>';
			}
			printf(
				'<tr><td><a href="%s">%s</a></td><td>%s%s</td><td>%s</td><td>%s</td></tr>',
				esc_url( (string) get_edit_post_link( $p['post_id'] ) ),
				esc_html( $p['title'] ),
				$p['same_site'] ? 'this site: ' : esc_html( $p['other']['site'] ) . ': ',
				$p['other']['url'] ? '<a href="' . esc_url( $p['other']['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $p['other']['title'] ) . '</a>' : esc_html( $p['other']['title'] . ' (' . $p['other']['status'] . ')' ),
				esc_html( $p['overlap'] ),
				$passages
			);
		}
		echo '</tbody></table>';
	}

	public static function save_site(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'navia_el_site' );
		$tab = isset( $_POST['tab'] ) ? sanitize_key( $_POST['tab'] ) : 'settings';
		if ( 'notes' === $tab ) {
			Navia_EL_Settings::save_notes( wp_kses_post( wp_unslash( $_POST['notes'] ?? '' ) ) );
		} else {
			$values = array();
			foreach ( array_keys( Navia_EL_Settings::site_defaults() ) as $k ) {
				if ( isset( $_POST[ $k ] ) ) {
					$values[ $k ] = wp_unslash( $_POST[ $k ] );
				}
			}
			Navia_EL_Settings::save_site( $values );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $tab . '&updated=1' ) );
		exit;
	}
}
