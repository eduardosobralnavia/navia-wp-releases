<?php





defined( 'ABSPATH' ) || exit;

use Elementor\Plugin;

class Navia_EL_Builder {

	const BACKUP_META = array( '_elementor_data', '_elementor_page_settings', '_elementor_edit_mode', '_elementor_template_type', '_elementor_version', '_wp_page_template' );

	private static $text_cache = array();

	public static function elementor(): Plugin {
		return Plugin::$instance;
	}

	public static function element_types(): array {
		static $types = null;
		if ( null === $types ) {
			$types = array_keys( self::elementor()->elements_manager->get_element_types() );
		}
		return $types;
	}

	public static function widget_types(): array {
		static $types = null;
		if ( null === $types ) {
			$types = array_keys( self::elementor()->widgets_manager->get_widget_types() );
		}
		return $types;
	}




	public static function is_nested( string $widget_type ): bool {
		$w = self::elementor()->widgets_manager->get_widget_types( $widget_type );
		return $w && class_exists( '\Elementor\Modules\NestedElements\Base\Widget_Nested_Base' ) && $w instanceof \Elementor\Modules\NestedElements\Base\Widget_Nested_Base;
	}

	public static function container_active(): bool {
		$exp = self::elementor()->experiments;
		return $exp && $exp->is_feature_active( 'container' );
	}




	private static function source_of( $object ): string {
		try {
			$file = ( new ReflectionClass( $object ) )->getFileName();
		} catch ( ReflectionException $e ) {
			return '';
		}
		$file = wp_normalize_path( (string) $file );
		$dir  = wp_normalize_path( WP_PLUGIN_DIR ) . '/';
		if ( 0 === strpos( $file, $dir ) ) {
			return strtok( substr( $file, strlen( $dir ) ), '/' );
		}
		return 'theme';
	}




	public static function widget_list( string $search = '' ): array {
		$out = array();
		foreach ( self::elementor()->widgets_manager->get_widget_types() as $name => $widget ) {
			if ( str_starts_with( $name, 'common' ) || in_array( 'pro-elements', (array) $widget->get_categories(), true ) ) {
				continue;
			}
			$title = (string) $widget->get_title();
			if ( $search && false === stripos( $name . ' ' . $title, $search ) ) {
				continue;
			}
			if ( method_exists( $widget, 'show_in_panel' ) && ! $widget->show_in_panel() ) {
				$title .= ' (hidden in panel, legacy)';
			}
			$out[ self::source_of( $widget ) ][ $name ] = $title;
		}
		ksort( $out );
		foreach ( $out as &$group ) {
			ksort( $group );
		}
		return $out;
	}





	public static function controls_schema( string $name, array $tabs = array( 'content' ), string $search = '' ) {
		if ( 'kit' === $name ) {
			$kit = self::elementor()->kits_manager->get_active_kit();
			if ( ! $kit ) {
				return new WP_Error( 'navia_el_no_kit', 'No active Elementor kit.' );
			}
			$controls = $kit->get_controls();
			$tabs     = array();
		} elseif ( in_array( $name, self::element_types(), true ) ) {
			$controls = self::elementor()->elements_manager->get_element_types( $name )->get_controls();
		} elseif ( in_array( $name, self::widget_types(), true ) ) {
			$controls = self::elementor()->widgets_manager->get_widget_types( $name )->get_controls();
		} else {
			return new WP_Error( 'navia_el_unknown', "Unknown widget or element \"$name\"." );
		}

		$skip_types = array( 'section', 'tab', 'tabs', 'heading', 'divider', 'raw_html', 'deprecated_notice', 'alert', 'notice', 'button', 'hidden' );

		$noise = '/(^_?transform|_transform_|^_mask|motion_fx|^_offset|^_z_index|^_position$|_attributes$|_video_|video_link|_slideshow_|play_once|play_on_mobile|privacy_mode|_xpos|_ypos|_bg_width|^_element_cache|^_element_vertical_align|^_flex_(order|size)_?)/';
		$out    = array();
		$groups = array();

		foreach ( $controls as $cname => $c ) {
			$type = $c['type'] ?? '';
			if ( in_array( $type, $skip_types, true ) ) {
				continue;
			}
			if ( preg_match( '/_(widescreen|laptop|tablet_extra|tablet|mobile_extra|mobile)$/', $cname ) ) {
				continue;
			}
			$tab = $c['tab'] ?? 'content';
			if ( $tabs && ! in_array( $tab, $tabs, true ) ) {
				continue;
			}
			if ( $search ) {
				if ( false === stripos( $cname . ' ' . ( $c['label'] ?? '' ), $search ) ) {
					continue;
				}
			} elseif ( preg_match( $noise, $cname ) ) {
				continue;
			}


			if ( ! $search && preg_match( '/elementor-group-control-([a-z0-9-]+) elementor-group-control /', (string) ( $c['classes'] ?? '' ), $m ) && 'flex-container' !== $m[1] && 'flex-item' !== $m[1] ) {
				$gkey = $m[1] . '|' . ( $c['section'] ?? '' ) . '|' . ( $c['inner_tab'] ?? '' );
				if ( ! isset( $groups[ $gkey ] ) ) {
					$groups[ $gkey ] = array(
						'group'  => $m[1],
						'switch' => $cname,
						'tab'    => $tab,
						'keys'   => array(),
					);
				}
				$groups[ $gkey ]['keys'][] = $cname . ( ! empty( $c['is_responsive'] ) ? ' (responsive)' : '' );
				continue;
			}

			$row = array( 'type' => $type );
			if ( ! $tabs || count( $tabs ) > 1 ) {
				$row['tab'] = $tab;
			}
			if ( ! empty( $c['is_responsive'] ) ) {
				$row['responsive'] = true;
			}
			if ( isset( $c['default'] ) && '' !== $c['default'] && array() !== $c['default'] ) {
				$row['default'] = $c['default'];
			}
			if ( ! empty( $c['options'] ) && is_array( $c['options'] ) ) {
				$opts = array_keys( $c['options'] );
				$row['options'] = count( $opts ) > 40 ? array_slice( $opts, 0, 40 ) : $opts;
			}
			if ( ! empty( $c['condition'] ) ) {
				$row['condition'] = $c['condition'];
			}
			if ( in_array( $type, array( 'repeater', 'nested-elements-repeater' ), true ) && ! empty( $c['fields'] ) ) {
				$fields = array();
				foreach ( $c['fields'] as $fname => $f ) {
					$ftype = $f['type'] ?? '';
					$fname = is_string( $fname ) ? $fname : ( $f['name'] ?? '' );
					if ( ! $fname || in_array( $ftype, $skip_types, true ) || preg_match( '/_(tablet|mobile)$/', $fname ) ) {
						continue;
					}
					$fr = array( 'type' => $ftype );
					if ( isset( $f['default'] ) && '' !== $f['default'] && array() !== $f['default'] ) {
						$fr['default'] = $f['default'];
					}
					if ( ! empty( $f['options'] ) && is_array( $f['options'] ) && count( $f['options'] ) <= 40 ) {
						$fr['options'] = array_keys( $f['options'] );
					}
					$fields[ $fname ] = $fr;
				}
				$row['fields'] = $fields;
			}
			$out[ $cname ] = $row;
		}

		$compact = array();
		foreach ( $groups as $g ) {
			$keys = array_values( array_unique( $g['keys'] ) );
			$compact[ $g['switch'] ] = array(
				'group' => $g['group'],
				'tab'   => $g['tab'],
				'keys'  => array_slice( $keys, 0, 14 ),
			);
		}
		return array(
			'name'     => $name,
			'controls' => $out,
			'groups'   => $compact,
			'note'     => 'Responsive controls take the same value shape under name_tablet and name_mobile. A group is switched on by its first key: typography_typography = "custom", background_background = "classic", border_border = "solid", box_shadow_box_shadow_type = "yes". Sliders are {"unit":"px","size":24}; dimensions are {"unit":"px","top":"0","right":"0","bottom":"0","left":"0","isLinked":false}; gaps are {"unit":"px","column":"24","row":"24","isLinked":true}. Pass search to see any control that is hidden here, and tabs ["style"] for style controls.',
		);
	}




	public static function text_controls( string $type, bool $is_widget ): array {
		if ( isset( self::$text_cache[ $type ] ) ) {
			return self::$text_cache[ $type ];
		}
		$map = array(
			'fields'    => array(),
			'repeaters' => array(),
		);
		$obj = $is_widget
			? self::elementor()->widgets_manager->get_widget_types( $type )
			: self::elementor()->elements_manager->get_element_types( $type );
		if ( ! $obj ) {
			self::$text_cache[ $type ] = $map;
			return $map;
		}
		$kinds = array(
			'text'     => 'text',
			'textarea' => 'text',
			'wysiwyg'  => 'html',
			'url'      => 'url',
		);
		foreach ( $obj->get_controls() as $name => $c ) {
			if ( str_starts_with( $name, '_' ) || preg_match( '/(css|_id$|attributes|anchor|class)/', $name ) ) {
				continue;
			}
			if ( preg_match( '/_(tablet|mobile|widescreen|laptop)(_extra)?$/', $name ) ) {
				continue;
			}
			$t = $c['type'] ?? '';
			if ( isset( $kinds[ $t ] ) && ( $c['tab'] ?? 'content' ) === 'content' ) {
				$map['fields'][ $name ] = $kinds[ $t ];
			}
			if ( in_array( $t, array( 'repeater', 'nested-elements-repeater' ), true ) && ! empty( $c['fields'] ) ) {
				foreach ( $c['fields'] as $fname => $f ) {
					$fname = is_string( $fname ) ? $fname : ( $f['name'] ?? '' );
					$ft    = $f['type'] ?? '';
					if ( $fname && isset( $kinds[ $ft ] ) && ! preg_match( '/(css|_id$|class)/', $fname ) ) {
						$map['repeaters'][ $name ][ $fname ] = $kinds[ $ft ];
					}
				}
			}
		}
		self::$text_cache[ $type ] = $map;
		return $map;
	}

	public static function get_elements( int $post_id ): array {
		$doc = self::elementor()->documents->get( $post_id, false );
		if ( ! $doc ) {
			return array();
		}
		$data = $doc->get_elements_data();
		return is_array( $data ) ? $data : array();
	}

	public static function page_settings( int $post_id ): array {
		$s = get_post_meta( $post_id, '_elementor_page_settings', true );
		return is_array( $s ) ? $s : array();
	}






	public static function save( int $post_id, ?array $elements, ?array $settings = null ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'navia_el_not_found', "Post $post_id not found." );
		}
		update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
		if ( ! get_post_meta( $post_id, '_elementor_template_type', true ) ) {
			update_post_meta( $post_id, '_elementor_template_type', 'page' === $post->post_type ? 'wp-page' : 'wp-post' );
		}
		$doc = self::elementor()->documents->get( $post_id, false );
		if ( ! $doc ) {
			return new WP_Error( 'navia_el_document', "Elementor cannot open post $post_id as a document. Is its post type enabled for Elementor?" );
		}
		$data = array();
		if ( null !== $elements ) {
			$data['elements'] = $elements;
		}
		if ( null !== $settings ) {
			$data['settings'] = $settings;
		}
		try {
			$ok = $doc->save( $data );
		} catch ( Throwable $e ) {
			return new WP_Error( 'navia_el_save', 'Elementor refused the data: ' . $e->getMessage() );
		}
		if ( ! $ok ) {
			return new WP_Error( 'navia_el_save', 'Elementor did not save: the current user cannot edit this document with Elementor.' );
		}
		return true;
	}





	public static function backup( int $post_id ): int {
		$post = get_post( $post_id );
		if ( ! $post || ! get_post_meta( $post_id, '_elementor_data', true ) ) {
			return 0;
		}
		$rev_id = _wp_put_post_revision( $post );
		if ( ! $rev_id || is_wp_error( $rev_id ) ) {
			return 0;
		}
		foreach ( self::BACKUP_META as $key ) {
			$v = get_post_meta( $post_id, $key, true );
			if ( '' !== $v && null !== $v ) {
				update_metadata( 'post', $rev_id, $key, is_string( $v ) ? wp_slash( $v ) : $v );
			}
		}
		update_metadata( 'post', $rev_id, '_navia_el_backup', 1 );

		$keep = wp_revisions_to_keep( $post );
		$keep = $keep < 0 ? 0 : max( 5, $keep );
		if ( $keep ) {
			$revs = wp_get_post_revisions( $post_id, array( 'order' => 'DESC' ) );
			foreach ( array_slice( $revs, $keep ) as $old ) {
				wp_delete_post_revision( $old->ID );
			}
		}
		return (int) $rev_id;
	}

	public static function revisions( int $post_id ): array {
		$out = array();
		foreach ( wp_get_post_revisions( $post_id, array( 'order' => 'DESC' ) ) as $rev ) {
			$data  = get_metadata( 'post', $rev->ID, '_elementor_data', true );
			$out[] = array(
				'revision_id' => $rev->ID,
				'date'        => $rev->post_modified,
				'author'      => get_the_author_meta( 'user_login', $rev->post_author ),
				'has_layout'  => ! empty( $data ),
				'by_navia'    => (bool) get_metadata( 'post', $rev->ID, '_navia_el_backup', true ),
			);
		}
		return $out;
	}

	public static function restore( int $post_id, int $rev_id ) {
		$rev = get_post( $rev_id );
		if ( ! $rev || 'revision' !== $rev->post_type || (int) $rev->post_parent !== $post_id ) {
			return new WP_Error( 'navia_el_revision', "Revision $rev_id does not belong to $post_id." );
		}
		$json = get_metadata( 'post', $rev_id, '_elementor_data', true );
		$data = is_string( $json ) ? json_decode( $json, true ) : $json;
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'navia_el_revision', 'This revision has no Elementor layout.' );
		}
		$settings = get_metadata( 'post', $rev_id, '_elementor_page_settings', true );
		self::backup( $post_id );
		$tpl = get_metadata( 'post', $rev_id, '_wp_page_template', true );
		if ( $tpl ) {
			update_post_meta( $post_id, '_wp_page_template', $tpl );
		}
		return self::save( $post_id, $data, is_array( $settings ) ? $settings : null );
	}

	public static function kit() {
		return self::elementor()->kits_manager->get_active_kit();
	}




	public static function kit_summary(): array {
		$kit = self::kit();
		if ( ! $kit ) {
			return array();
		}
		$s   = get_post_meta( $kit->get_id(), '_elementor_page_settings', true );
		$s   = is_array( $s ) ? $s : array();
		$out = array(
			'kit_id'            => $kit->get_id(),
			'system_colors'     => $s['system_colors'] ?? array(),
			'custom_colors'     => $s['custom_colors'] ?? array(),
			'system_typography' => $s['system_typography'] ?? array(),
			'custom_typography' => $s['custom_typography'] ?? array(),
			'other'             => array(),
		);
		foreach ( $s as $k => $v ) {
			if ( in_array( $k, array( 'system_colors', 'custom_colors', 'system_typography', 'custom_typography' ), true ) ) {
				continue;
			}
			if ( '' === $v || array() === $v || null === $v ) {
				continue;
			}
			$out['other'][ $k ] = $v;
		}
		return $out;
	}

	public static function update_kit( array $settings ) {
		$kit = self::kit();
		if ( ! $kit ) {
			return new WP_Error( 'navia_el_no_kit', 'No active Elementor kit.' );
		}
		$current = get_post_meta( $kit->get_id(), '_elementor_page_settings', true );
		$current = is_array( $current ) ? $current : array();
		foreach ( $settings as $k => $v ) {
			if ( null === $v ) {
				unset( $current[ $k ] );
			} else {
				$current[ $k ] = $v;
			}
		}
		foreach ( array( 'system_colors', 'custom_colors', 'system_typography', 'custom_typography' ) as $list ) {
			if ( ! empty( $current[ $list ] ) && is_array( $current[ $list ] ) ) {
				$current[ $list ] = array_values(
					array_filter(
						$current[ $list ],
						fn( $item ) => is_array( $item ) && ! empty( $item['_id'] )
					)
				);
			}
		}
		try {
			$ok = $kit->save( array( 'settings' => $current ) );
		} catch ( Throwable $e ) {
			return new WP_Error( 'navia_el_kit', 'Elementor refused the kit settings: ' . $e->getMessage() );
		}
		if ( ! $ok ) {
			return new WP_Error( 'navia_el_kit', 'The kit was not saved (permissions).' );
		}
		self::clear_css();
		return true;
	}

	public static function clear_css(): void {
		self::elementor()->files_manager->clear_cache();
	}




	public static function render( int $post_id ): array {
		$errors = array();
		set_error_handler(
			function ( $no, $str, $file, $line ) use ( &$errors ) {
				if ( in_array( $no, array( E_DEPRECATED, E_USER_DEPRECATED ), true ) ) {
					return true;
				}
				$errors[] = $str . ' (' . basename( (string) $file ) . ':' . $line . ')';
				return true;
			}
		);
		$html = '';



		ob_start();
		try {
			$GLOBALS['post'] = get_post( $post_id );
			setup_postdata( $GLOBALS['post'] );
			$html = (string) self::elementor()->frontend->get_builder_content( $post_id, false );
		} catch ( Throwable $e ) {
			$errors[] = 'Render failed: ' . $e->getMessage();
		}
		$printed = (string) ob_get_clean();
		$html    = $printed . $html;
		restore_error_handler();
		wp_reset_postdata();
		return array(
			'html'   => $html,
			'errors' => array_slice( array_unique( $errors ), 0, 20 ),
		);
	}

	public static function page_templates(): array {
		$tpl = array( 'default' => 'Theme default' );
		foreach ( wp_get_theme()->get_page_templates( null, 'page' ) as $file => $name ) {
			$tpl[ $file ] = $name;
		}
		$tpl['elementor_header_footer'] = 'Elementor Full Width (header and footer)';
		$tpl['elementor_canvas']        = 'Elementor Canvas (no header or footer)';
		return $tpl;
	}
}
