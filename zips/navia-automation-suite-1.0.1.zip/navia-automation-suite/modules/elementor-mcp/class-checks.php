<?php






defined( 'ABSPATH' ) || exit;

class Navia_EL_Checks {


	const PT_BR = array( 'você', 'vocês', 'celular', 'tela', 'arquivo', 'aba', 'hospedagem', 'registro', 'mecanismo de busca', 'cadastro', 'usuário', 'equipe', 'ônibus', 'contato' );




	public static function tree( array $elements, string $kind = 'page' ): array {
		$issues = array();
		$h1     = 0;
		$first  = $elements[0]['id'] ?? '';

		Navia_EL_Tree::walk(
			$elements,
			function ( $el, $depth ) use ( &$issues, &$h1, $first, $elements ) {
				$s  = is_array( $el['settings'] ?? null ) ? $el['settings'] : array();
				$wt = $el['widgetType'] ?? '';
				if ( 'heading' === $wt && 'h1' === ( $s['header_size'] ?? 'h2' ) ) {
					$h1++;
				}
				foreach ( array( 'editor', 'html' ) as $k ) {
					if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
						$h1 += preg_match_all( '/<h1[\s>]/i', $s[ $k ] );
					}
				}
				if ( 'html' === $wt && ! current_user_can( 'unfiltered_html' ) && preg_match( '/<(script|style|form|iframe|svg|input)\b/i', (string) ( $s['html'] ?? '' ) ) ) {
					$issues[] = array(
						'level'   => 'error',
						'element' => $el['id'],
						'message' => 'HTML widget uses script, style, form, iframe, svg or input, which WordPress strips for users without unfiltered_html (normal on a network subsite). Use native widgets or a shortcode.',
					);
				}
				$anim = $s['_animation'] ?? ( $s['animation'] ?? '' );
				if ( $anim && 'none' !== $anim && $first && ( $el['id'] === $first || Navia_EL_Tree::find_path( array( $elements[0] ), $el['id'] ) ) ) {
					$issues[] = array(
						'level'   => 'warning',
						'element' => $el['id'],
						'message' => 'Entrance animation in the first section: it delays the largest paint on mobile.',
					);
				}
				if ( in_array( $wt, array( 'image-carousel', 'video', 'google_maps' ), true ) && $first && Navia_EL_Tree::find_path( array( $elements[0] ), $el['id'] ) ) {
					$issues[] = array(
						'level'   => 'warning',
						'element' => $el['id'],
						'message' => "Heavy widget ($wt) above the fold: keep the first section to text, a button and at most one image.",
					);
				}
				if ( 'button' === $wt && empty( $s['link']['url'] ) ) {
					$issues[] = array(
						'level'   => 'warning',
						'element' => $el['id'],
						'message' => 'Button without a link.',
					);
				}
				if ( 'image' === $wt && empty( $s['image']['id'] ) && empty( $s['image']['url'] ) ) {
					$issues[] = array(
						'level'   => 'warning',
						'element' => $el['id'],
						'message' => 'Image widget without an image.',
					);
				}
			}
		);

		if ( 'page' === $kind && 0 === $h1 ) {
			$issues[] = array(
				'level'   => 'warning',
				'message' => 'No H1 in the layout. Pages use hide_title, so the layout must carry exactly one H1.',
			);
		}
		if ( 'page' === $kind && $h1 > 1 ) {
			$issues[] = array(
				'level'   => 'error',
				'message' => "$h1 H1 headings: a page must have exactly one.",
			);
		}
		if ( in_array( $kind, array( 'header', 'footer' ), true ) && $h1 > 0 ) {
			$issues[] = array(
				'level'   => 'error',
				'message' => 'Headers and footers must not contain an H1 (it would repeat on every page).',
			);
		}
		$depth = Navia_EL_Tree::max_depth( $elements );
		if ( $depth > 6 ) {
			$issues[] = array(
				'level'   => 'warning',
				'message' => "Layout is $depth levels deep. Keep containers at 4 levels or fewer for a small DOM.",
			);
		}
		$count = Navia_EL_Tree::count( $elements );
		if ( $count > 250 ) {
			$issues[] = array(
				'level'   => 'warning',
				'message' => "$count elements on one page: consider splitting or simplifying.",
			);
		}
		return array(
			'h1'       => $h1,
			'elements' => $count,
			'depth'    => $depth,
			'issues'   => $issues,
		);
	}




	public static function render( int $post_id, string $kind = 'page' ): array {
		$rendered = Navia_EL_Builder::render( $post_id );
		$html     = $rendered['html'];
		$lang     = Navia_EL_I18n::get_lang( $post_id );
		$static   = self::tree( Navia_EL_Builder::get_elements( $post_id ), $kind );
		$issues   = $static['issues'];

		foreach ( $rendered['errors'] as $e ) {
			$issues[] = array(
				'level'   => 'error',
				'message' => 'PHP while rendering: ' . $e,
			);
		}
		if ( '' === trim( $html ) ) {
			$issues[] = array(
				'level'   => 'error',
				'message' => 'The layout renders empty.',
			);
			return array(
				'ok'     => false,
				'issues' => $issues,
			);
		}

		$dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8"?><div id="navia-root">' . $html . '</div>', LIBXML_NOERROR | LIBXML_NOWARNING );
		libxml_clear_errors();
		$xp = new DOMXPath( $dom );

		$headings = array();
		foreach ( $xp->query( '//h1|//h2|//h3|//h4' ) as $h ) {
			$headings[] = $h->nodeName . ': ' . mb_substr( trim( preg_replace( '/\s+/', ' ', $h->textContent ) ), 0, 90 );
		}
		$prev = 0;
		foreach ( $headings as $h ) {
			$lvl = (int) substr( $h, 1, 1 );
			if ( $prev && $lvl > $prev + 1 ) {
				$issues[] = array(
					'level'   => 'warning',
					'message' => "Heading level jumps from h$prev to h$lvl at \"" . substr( $h, 4, 50 ) . '".',
				);
			}
			$prev = $lvl;
		}

		$images      = $xp->query( '//img' );
		$missing_alt = array();
		foreach ( $images as $img ) {
			if ( '' === trim( (string) $img->getAttribute( 'alt' ) ) && 'presentation' !== $img->getAttribute( 'role' ) ) {
				$missing_alt[] = basename( (string) wp_parse_url( $img->getAttribute( 'src' ), PHP_URL_PATH ) );
			}
		}
		if ( $missing_alt ) {
			$issues[] = array(
				'level'   => 'warning',
				'message' => count( $missing_alt ) . ' image(s) without alt text: ' . implode( ', ', array_slice( $missing_alt, 0, 8 ) ) . '. Set the alt in the media library or in the widget.',
			);
		}

		$home     = wp_parse_url( home_url(), PHP_URL_HOST );
		$internal = array();
		$external = array();
		foreach ( $xp->query( '//a[@href]' ) as $a ) {
			$href = trim( (string) $a->getAttribute( 'href' ) );
			$text = trim( preg_replace( '/\s+/', ' ', $a->textContent ) );
			if ( '' === $href || '#' === $href ) {
				$issues[] = array(
					'level'   => 'warning',
					'message' => 'Empty link' . ( $text ? " on \"$text\"" : '' ) . '.',
				);
				continue;
			}
			if ( preg_match( '/^(mailto|tel|sms):/i', $href ) || str_starts_with( $href, '#' ) ) {
				continue;
			}
			$host = wp_parse_url( $href, PHP_URL_HOST );
			if ( ! $host || $host === $home ) {
				$internal[ $href ] = $text;
			} else {
				$external[ $href ] = $text;
				if ( str_starts_with( strtolower( $href ), 'http://' ) ) {
					$issues[] = array(
						'level'   => 'warning',
						'message' => "Link without https: $href",
					);
				}
			}
		}
		foreach ( $internal as $href => $text ) {
			$abs    = str_starts_with( $href, '/' ) ? home_url( $href ) : $href;
			$path   = (string) wp_parse_url( $abs, PHP_URL_PATH );
			$homes  = array( untrailingslashit( home_url( '/' ) ) );
			foreach ( Navia_EL_I18n::languages() as $l ) {
				$homes[] = untrailingslashit( $l['home_url'] );
			}
			if ( in_array( untrailingslashit( strtok( $abs, '?#' ) ), $homes, true ) ) {
				continue;
			}
			$target = url_to_postid( $abs );
			if ( ! $target && ! in_array( rtrim( $path, '/' ), array( '', '/en', '/pt' ), true ) ) {
				$issues[] = array(
					'level'   => 'warning',
					'message' => "Internal link to a page that does not exist (yet): $href",
				);
				continue;
			}
			if ( $target && $lang ) {
				$tlang = Navia_EL_I18n::get_lang( $target );
				if ( $tlang && $tlang !== $lang ) {
					$issues[] = array(
						'level'   => 'warning',
						'message' => "Link in the wrong language ($lang page links to a $tlang page): $href",
					);
				}
			}
		}

		$plain = preg_replace( '#<(script|style)\b.*?</\1>#is', ' ', $html );
		$plain = preg_replace( '#</(p|div|li|h[1-6]|td|th|tr|summary|button)>#i', "$0\n", $plain );
		$text  = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $plain ), ENT_QUOTES, 'UTF-8' ) ) );
		$words = count( preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) );


		$style_texts = Navia_EL_Tree::texts( Navia_EL_Builder::get_elements( $post_id ) );
		$heading_txt = array_map( fn( $h ) => substr( $h, 4 ), $headings );
		foreach ( Navia_EL_Style::check( $text, $lang, $heading_txt, $style_texts ) as $s ) {
			$issues[] = $s;
		}
		if ( 'pt' === $lang ) {
			$found = array();
			foreach ( self::PT_BR as $w ) {
				if ( preg_match( '/(?<![\p{L}])' . preg_quote( $w, '/' ) . '(?![\p{L}])/iu', $text ) ) {
					$found[] = $w;
				}
			}
			if ( $found ) {
				$issues[] = array(
					'level'   => 'warning',
					'message' => 'Words that read as Brazilian Portuguese: ' . implode( ', ', $found ) . '.',
				);
			}
		}


		$markers = array(
			'pt' => '/[ãõçáéíóúâêôà]|\b(que|do|da|dos|das|em|um|uma|para|com|não|mais|seu|sua|quanto|quem|fica|sempre|inclui|perguntas)\b/iu',
			'en' => '/\b(the|and|with|your|from|which|price|website|who|what|how|get|our|you|is|are)\b/i',
		);
		if ( $lang && in_array( $lang, array( 'pt', 'en' ), true ) ) {
			$other  = 'pt' === $lang ? 'en' : 'pt';
			$suspic = array();
			foreach ( Navia_EL_Tree::texts( Navia_EL_Builder::get_elements( $post_id ) ) as $t ) {
				if ( 'url' === $t['kind'] ) {
					continue;
				}
				$plain = wp_strip_all_tags( $t['value'] );
				if ( preg_match_all( $markers[ $other ], $plain ) > preg_match_all( $markers[ $lang ], $plain ) ) {
					$suspic[] = $t['id'] . ( isset( $t['index'] ) ? '[' . $t['index'] . ']' : '' ) . ' "' . mb_substr( $plain, 0, 40 ) . '"';
				}
			}
			if ( $suspic ) {
				$issues[] = array(
					'level'   => 'warning',
					'message' => 'Text that still looks ' . strtoupper( $other ) . ' on a ' . strtoupper( $lang ) . ' page: ' . implode( '; ', array_slice( $suspic, 0, 12 ) ),
				);
			}
		}

		$nodes = $xp->query( '//*' )->length;
		if ( $nodes > 1200 ) {
			$issues[] = array(
				'level'   => 'warning',
				'message' => "$nodes DOM nodes in the layout alone. PageSpeed starts to complain above about 1,400 for the whole page.",
			);
		}

		$errors = array_filter( $issues, fn( $i ) => 'error' === $i['level'] );
		return array(
			'ok'         => ! $errors,
			'h1'         => $static['h1'],
			'headings'   => array_slice( $headings, 0, 60 ),
			'words'      => $words,
			'images'     => $images->length,
			'links'      => array(
				'internal' => array_slice( array_keys( $internal ), 0, 60 ),
				'external' => array_slice( array_keys( $external ), 0, 30 ),
			),
			'dom_nodes'  => $nodes,
			'html_bytes' => strlen( $html ),
			'issues'     => array_values( $issues ),
		);
	}
}
