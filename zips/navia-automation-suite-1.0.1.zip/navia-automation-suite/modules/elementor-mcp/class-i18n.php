<?php




defined( 'ABSPATH' ) || exit;

class Navia_EL_I18n {

	public static function active(): bool {
		return function_exists( 'pll_languages_list' ) && function_exists( 'pll_set_post_language' );
	}

	public static function languages(): array {
		if ( ! self::active() ) {
			return array();
		}
		$out     = array();
		$default = pll_default_language();
		foreach ( pll_languages_list( array( 'fields' => '' ) ) as $l ) {
			$out[] = array(
				'slug'       => $l->slug,
				'name'       => $l->name,
				'locale'     => $l->locale,
				'is_default' => $l->slug === $default,
				'home_url'   => pll_home_url( $l->slug ),
			);
		}
		return $out;
	}

	public static function slugs(): array {
		return self::active() ? pll_languages_list( array( 'fields' => 'slug' ) ) : array();
	}

	public static function default_lang(): string {
		return self::active() ? (string) pll_default_language() : '';
	}

	public static function translatable( string $post_type ): bool {
		return self::active() && function_exists( 'pll_is_translated_post_type' ) && pll_is_translated_post_type( $post_type );
	}

	public static function get_lang( int $post_id ): string {
		return self::active() ? (string) pll_get_post_language( $post_id ) : '';
	}

	public static function translations( int $post_id ): array {
		return self::active() ? pll_get_post_translations( $post_id ) : array();
	}

	public static function set_lang( int $post_id, string $lang ) {
		if ( ! self::active() ) {
			return new WP_Error( 'navia_el_no_polylang', 'Polylang is not active on this site.' );
		}
		if ( ! in_array( $lang, self::slugs(), true ) ) {
			return new WP_Error( 'navia_el_lang', "Unknown language \"$lang\". Languages: " . implode( ', ', self::slugs() ) . '.' );
		}
		if ( ! self::translatable( get_post_type( $post_id ) ) ) {
			return new WP_Error( 'navia_el_lang', 'This post type is not translated by Polylang.' );
		}
		pll_set_post_language( $post_id, $lang );
		return true;
	}




	public static function link( array $map ) {
		if ( ! self::active() ) {
			return new WP_Error( 'navia_el_no_polylang', 'Polylang is not active on this site.' );
		}
		$merged = array();
		foreach ( $map as $lang => $id ) {
			$id = (int) $id;
			if ( ! $id || ! get_post( $id ) ) {
				return new WP_Error( 'navia_el_lang', "Post $id for \"$lang\" not found." );
			}
			$actual = self::get_lang( $id );
			if ( $actual && $actual !== $lang ) {
				return new WP_Error( 'navia_el_lang', "Post $id is in \"$actual\", not \"$lang\"." );
			}
			if ( ! $actual ) {
				$r = self::set_lang( $id, $lang );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
			}
			$merged = array_merge( self::translations( $id ), $merged );
		}
		foreach ( $map as $lang => $id ) {
			$merged[ $lang ] = (int) $id;
		}
		pll_save_post_translations( $merged );
		return $merged;
	}









	public static function setup( array $langs, string $default, array $opts ) {
		if ( ! function_exists( 'PLL' ) || ! isset( PLL()->model->languages ) || ! method_exists( PLL()->model->languages, 'add' ) ) {
			return new WP_Error( 'navia_el_no_polylang', 'Polylang 3.7 or newer must be active on this site.' );
		}
		$model   = PLL()->model;
		$report  = array();
		$by_loc  = array();
		$by_slug = array();
		foreach ( $model->languages->get_list() as $l ) {
			$by_loc[ $l->locale ] = $l->slug;
			$by_slug[ $l->slug ]  = $l->locale;
		}

		foreach ( array_values( $langs ) as $order => $l ) {
			if ( ! is_array( $l ) || empty( $l['locale'] ) || ! preg_match( '/^[a-z]{2,3}(_[A-Z]{2})?(_[a-z0-9]+)?$/', (string) $l['locale'] ) ) {
				return new WP_Error( 'navia_el_lang', "Language $order needs a locale such as en_GB or pt_PT." );
			}
			$locale = (string) $l['locale'];
			if ( isset( $by_loc[ $locale ] ) ) {
				$report[] = "$locale already exists ({$by_loc[ $locale ]})";
				continue;
			}
			$args = array(
				'locale'     => $locale,
				'term_group' => $order,
			);
			foreach ( array( 'slug', 'name', 'flag' ) as $k ) {
				if ( ! empty( $l[ $k ] ) ) {
					$args[ $k ] = sanitize_text_field( (string) $l[ $k ] );
				}
			}
			$r = $model->languages->add( $args );
			if ( is_wp_error( $r ) && in_array( 'pll_invalid_flag', $r->get_error_codes(), true ) ) {
				$args['flag'] = '';
				$r            = $model->languages->add( $args );
				$report[]     = "$locale: flag could not be checked, added without flag";
			}
			if ( is_wp_error( $r ) ) {
				return new WP_Error( 'navia_el_lang', "$locale: " . implode( ' ', $r->get_error_messages() ) );
			}
			$by_loc[ $locale ]    = $r->slug;
			$by_slug[ $r->slug ] = $locale;
			$report[]             = "$locale added as {$r->slug}";
		}

		$default_slug = $by_loc[ $default ] ?? ( isset( $by_slug[ $default ] ) ? $default : '' );
		if ( ! $default_slug ) {
			return new WP_Error( 'navia_el_lang', "Default language \"$default\" is not among the site languages." );
		}
		if ( pll_default_language() !== $default_slug ) {
			$r = $model->languages->update_default( $default_slug );
			if ( is_wp_error( $r ) && $r->has_errors() ) {
				return new WP_Error( 'navia_el_lang', implode( ' ', $r->get_error_messages() ) );
			}
			$report[] = "default language set to $default_slug";
		}

		$options = PLL()->options;
		$wanted  = array(
			'hide_default' => isset( $opts['hide_default'] ) ? (bool) $opts['hide_default'] : true,
			'force_lang'   => 'parameter' === ( $opts['url_mode'] ?? 'directory' ) ? 0 : 1,
			'rewrite'      => true,
			'browser'      => ! empty( $opts['browser'] ),
		);
		foreach ( $wanted as $key => $value ) {
			if ( $options->get( $key ) !== $value ) {
				$e = $options->set( $key, $value );
				if ( $e->has_errors() ) {
					return new WP_Error( 'navia_el_lang', "$key: " . implode( ' ', $e->get_error_messages() ) );
				}
			}
		}
		$options->save();

		if ( ! isset( $opts['assign_existing'] ) || $opts['assign_existing'] ) {
			$model->set_language_in_mass();
			$report[] = 'content without a language set to the default language';
		}
		$model->clean_languages_cache();
		flush_rewrite_rules( false );

		return array(
			'report'    => $report,
			'languages' => self::languages(),
			'options'   => $wanted,
		);
	}




	public static function switcher_options( array $o ): array {
		return array(
			'hide_if_no_translation' => empty( $o['hide_if_no_translation'] ) ? 0 : 1,
			'hide_current'           => isset( $o['hide_current'] ) ? (int) (bool) $o['hide_current'] : 1,
			'force_home'             => empty( $o['force_home'] ) ? 0 : 1,
			'show_flags'             => empty( $o['show_flags'] ) ? 0 : 1,
			'show_names'             => isset( $o['show_names'] ) ? (int) (bool) $o['show_names'] : 1,
			'dropdown'               => empty( $o['dropdown'] ) ? 0 : 1,
		);
	}
}
