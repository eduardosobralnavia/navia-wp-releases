<?php




defined( 'ABSPATH' ) || exit;

class Navia_EL_Log {

	const OPTION = 'navia_el_log';
	const MAX    = 500;

	public static function add( string $ability, int $object_id, string $summary, string $result = 'ok' ): void {
		$log   = self::all();
		$user  = wp_get_current_user();
		$log[] = array(
			'time'    => current_time( 'mysql' ),
			'user'    => $user && $user->exists() ? $user->user_login : '',
			'ability' => $ability,
			'object'  => $object_id,
			'summary' => mb_substr( $summary, 0, 500 ),
			'result'  => $result,
		);
		if ( count( $log ) > self::MAX ) {
			$log = array_slice( $log, -self::MAX );
		}
		update_option( self::OPTION, $log, false );
	}

	public static function all(): array {
		$log = get_option( self::OPTION, array() );
		return is_array( $log ) ? $log : array();
	}

	public static function latest( int $limit = 50, int $object_id = 0 ): array {
		$log = array_reverse( self::all() );
		if ( $object_id ) {
			$log = array_values( array_filter( $log, fn( $e ) => (int) $e['object'] === $object_id ) );
		}
		return array_slice( $log, 0, max( 1, min( 500, $limit ) ) );
	}
}
