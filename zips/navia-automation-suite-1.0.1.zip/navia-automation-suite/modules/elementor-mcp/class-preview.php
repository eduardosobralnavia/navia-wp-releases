<?php






defined( 'ABSPATH' ) || exit;

class Navia_EL_Preview {

	const META = '_navia_el_preview';
	const ARG  = 'navia_preview';

	private static $active = null;

	public static function init(): void {
		add_filter( 'posts_results', array( __CLASS__, 'posts_results' ), 10, 2 );
		add_filter( 'chf_template_id', array( __CLASS__, 'override_template' ), 99, 2 );
		add_action( 'template_redirect', array( __CLASS__, 'headers' ), 0 );
	}

	public static function create( int $post_id, int $hours, array $overrides = array() ): array {
		$token  = wp_generate_password( 32, false, false );
		$store  = self::store( $post_id );
		$expiry = time() + $hours * HOUR_IN_SECONDS;

		$store[ hash( 'sha256', $token ) ] = array(
			'exp'    => $expiry,
			'header' => (int) ( $overrides['header'] ?? 0 ),
			'footer' => (int) ( $overrides['footer'] ?? 0 ),
			'single' => (int) ( $overrides['single'] ?? 0 ),
		);
		update_post_meta( $post_id, self::META, $store );

		$type = get_post_type( $post_id );
		$args = 'page' === $type ? array( 'page_id' => $post_id ) : array(
			'p'         => $post_id,
			'post_type' => $type,
		);
		$args[ self::ARG ] = $post_id . '.' . $token;

		$lang = Navia_EL_I18n::get_lang( $post_id );
		$base = $lang && function_exists( 'pll_home_url' ) ? pll_home_url( $lang ) : home_url( '/' );

		return array(
			'url'     => add_query_arg( $args, $base ),
			'expires' => wp_date( 'Y-m-d H:i', $expiry ),
		);
	}

	public static function revoke( int $post_id ): void {
		delete_post_meta( $post_id, self::META );
	}

	private static function store( int $post_id ): array {
		$store = get_post_meta( $post_id, self::META, true );
		$store = is_array( $store ) ? $store : array();
		$now   = time();
		return array_filter( $store, fn( $t ) => is_array( $t ) && ( $t['exp'] ?? 0 ) > $now );
	}




	private static function current( int $post_id ): ?array {
		if ( empty( $_GET[ self::ARG ] ) ) {
			return null;
		}
		$raw = sanitize_text_field( wp_unslash( $_GET[ self::ARG ] ) );
		if ( ! preg_match( '/^(\d+)\.([A-Za-z0-9]{32})$/', $raw, $m ) || (int) $m[1] !== $post_id ) {
			return null;
		}
		$hash = hash( 'sha256', $m[2] );
		foreach ( self::store( $post_id ) as $stored => $data ) {
			if ( hash_equals( $stored, $hash ) ) {
				return $data;
			}
		}
		return null;
	}

	public static function posts_results( $posts, $query ) {
		if ( is_admin() || ! $query->is_main_query() || empty( $_GET[ self::ARG ] ) || 1 !== count( (array) $posts ) ) {
			return $posts;
		}
		$post = $posts[0];
		$data = self::current( (int) $post->ID );
		if ( ! $data ) {
			return $posts;
		}
		self::$active = $data;
		if ( 'publish' !== $post->post_status ) {
			$post->post_status = 'publish';
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		add_filter( 'redirect_canonical', '__return_false' );
		add_filter( 'pll_check_canonical_url', '__return_false' );
		add_filter( 'wp_robots', 'wp_robots_no_robots' );
		return $posts;
	}

	public static function headers(): void {
		if ( null === self::$active ) {
			return;
		}
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow', true );
	}

	public static function override_template( $id, $type ) {
		if ( null === self::$active || empty( self::$active[ $type ] ) ) {
			return $id;
		}
		return (int) self::$active[ $type ];
	}
}
