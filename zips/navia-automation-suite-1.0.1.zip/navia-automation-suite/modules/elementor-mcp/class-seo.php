<?php




defined( 'ABSPATH' ) || exit;

class Navia_EL_SEO {

	public static function active(): bool {
		return class_exists( 'RankMath' ) || defined( 'RANK_MATH_VERSION' );
	}

	public static function get( int $post_id ): array {
		$robots = get_post_meta( $post_id, 'rank_math_robots', true );
		return array(
			'title'              => (string) get_post_meta( $post_id, 'rank_math_title', true ),
			'description'        => (string) get_post_meta( $post_id, 'rank_math_description', true ),
			'focus_keyword'      => (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true ),
			'robots'             => is_array( $robots ) ? $robots : array(),
			'canonical'          => (string) get_post_meta( $post_id, 'rank_math_canonical_url', true ),
			'social_title'       => (string) get_post_meta( $post_id, 'rank_math_facebook_title', true ),
			'social_description' => (string) get_post_meta( $post_id, 'rank_math_facebook_description', true ),
		);
	}




	public static function set( int $post_id, array $seo ): array {
		$warnings = array();
		$lang     = Navia_EL_I18n::get_lang( $post_id );

		if ( isset( $seo['title'] ) ) {
			$t = trim( wp_strip_all_tags( (string) $seo['title'] ) );
			update_post_meta( $post_id, 'rank_math_title', $t );
			if ( mb_strlen( $t ) > 60 ) {
				$warnings[] = 'SEO title has ' . mb_strlen( $t ) . ' characters (over 60).';
			}
			if ( preg_match( '/[\x{2013}\x{2014}]/u', $t ) ) {
				$warnings[] = 'SEO title contains a dash (en or em).';
			}
		}
		if ( isset( $seo['description'] ) ) {
			$d = trim( wp_strip_all_tags( (string) $seo['description'] ) );
			update_post_meta( $post_id, 'rank_math_description', $d );
			if ( mb_strlen( $d ) > 158 ) {
				$warnings[] = 'Meta description has ' . mb_strlen( $d ) . ' characters (over 158).';
			}
			if ( preg_match( '/[\x{2013}\x{2014}]/u', $d ) ) {
				$warnings[] = 'Meta description contains a dash (en or em).';
			}
		}
		if ( isset( $seo['focus_keyword'] ) ) {
			$fk = trim( sanitize_text_field( (string) $seo['focus_keyword'] ) );
			update_post_meta( $post_id, 'rank_math_focus_keyword', $fk );
			$primary = trim( explode( ',', $fk )[0] );
			if ( '' !== $primary ) {
				$dupes = get_posts(
					array(
						'post_type'      => 'any',
						'post_status'    => array( 'publish', 'future', 'draft', 'pending' ),
						'posts_per_page' => 5,
						'post__not_in'   => array( $post_id ),
						'fields'         => 'ids',
						'lang'           => $lang ? $lang : '',
						'meta_query'     => array(
							array(
								'key'     => 'rank_math_focus_keyword',
								'value'   => $primary,
								'compare' => 'LIKE',
							),
						),
					)
				);
				$dupes = array_values(
					array_filter(
						$dupes,
						fn( $id ) => 0 === strcasecmp( trim( explode( ',', (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) )[0] ), $primary )
					)
				);
				if ( $dupes ) {
					$warnings[] = "Focus keyword \"$primary\" is already the primary keyword of: " . implode( ', ', $dupes ) . '.';
				}
			}
		}
		if ( isset( $seo['robots'] ) && is_array( $seo['robots'] ) ) {
			$allowed = array( 'index', 'noindex', 'follow', 'nofollow', 'noarchive', 'noimageindex', 'nosnippet' );
			$robots  = array_values( array_intersect( array_map( 'strval', $seo['robots'] ), $allowed ) );
			update_post_meta( $post_id, 'rank_math_robots', $robots );
		}
		if ( isset( $seo['canonical'] ) ) {
			update_post_meta( $post_id, 'rank_math_canonical_url', esc_url_raw( (string) $seo['canonical'] ) );
		}
		if ( isset( $seo['social_title'] ) ) {
			update_post_meta( $post_id, 'rank_math_facebook_title', sanitize_text_field( (string) $seo['social_title'] ) );
		}
		if ( isset( $seo['social_description'] ) ) {
			update_post_meta( $post_id, 'rank_math_facebook_description', sanitize_text_field( (string) $seo['social_description'] ) );
		}
		if ( ! self::active() ) {
			$warnings[] = 'Rank Math is not active here: the meta was stored but nothing reads it yet.';
		}
		return $warnings;
	}
}
