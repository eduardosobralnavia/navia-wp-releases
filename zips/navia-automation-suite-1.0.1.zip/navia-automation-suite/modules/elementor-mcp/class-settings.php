<?php




defined( 'ABSPATH' ) || exit;

class Navia_EL_Settings {

	const NETWORK_OPTION = 'navia_el_network';
	const SITE_OPTION    = 'navia_el_site';
	const NOTES_OPTION   = 'navia_el_design_notes';




	public static function site_defaults(): array {
		return array(


			'publish_mode'       => 'draft',
			'allow_kit'          => true,
			'allow_site'         => false,
			'allow_menus'        => true,
			'allow_css'          => true,
			'allow_trash'        => false,
			'trash_scope'        => 'own',
			'default_template'   => 'elementor_header_footer',
			'preview_hours'      => 48,
			'writes_per_minute'  => 60,
			'media_hosts'        => '',
		);
	}

	public static function network_defaults(): array {
		return array(
			'enabled_sites' => array(),
		);
	}

	public static function site(): array {
		$saved = get_option( self::SITE_OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::site_defaults() );
	}

	public static function get( string $key ) {
		$s = self::site();
		return $s[ $key ] ?? null;
	}

	public static function save_site( array $values ): void {
		$clean    = array();
		$defaults = self::site_defaults();
		foreach ( $defaults as $key => $default ) {
			if ( ! array_key_exists( $key, $values ) ) {
				$clean[ $key ] = $default;
				continue;
			}
			$v = $values[ $key ];
			if ( is_bool( $default ) ) {
				$clean[ $key ] = (bool) $v;
			} elseif ( is_int( $default ) ) {
				$clean[ $key ] = max( 1, (int) $v );
			} else {
				$clean[ $key ] = sanitize_textarea_field( (string) $v );
			}
		}
		if ( ! in_array( $clean['publish_mode'], array( 'draft', 'publish' ), true ) ) {
			$clean['publish_mode'] = 'draft';
		}
		if ( ! in_array( $clean['trash_scope'], array( 'own', 'any' ), true ) ) {
			$clean['trash_scope'] = 'own';
		}
		if ( ! in_array( $clean['default_template'], array( 'default', 'elementor_header_footer', 'elementor_canvas' ), true ) ) {
			$clean['default_template'] = 'elementor_header_footer';
		}
		$clean['preview_hours'] = min( 168, $clean['preview_hours'] );
		update_option( self::SITE_OPTION, $clean, false );
	}

	public static function network(): array {
		if ( ! is_multisite() ) {
			return self::network_defaults();
		}
		$saved = get_site_option( self::NETWORK_OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::network_defaults() );
	}

	public static function save_network( array $values ): void {
		$sites = array_values( array_unique( array_map( 'intval', (array) ( $values['enabled_sites'] ?? array() ) ) ) );
		update_site_option( self::NETWORK_OPTION, array( 'enabled_sites' => $sites ) );
	}




	public static function site_enabled( ?int $blog_id = null ): bool {
		return NAS_Env::module_site_enabled( 'elementor_mcp', self::network()['enabled_sites'], $blog_id );
	}

	public static function can_publish(): bool {
		return 'publish' === self::get( 'publish_mode' );
	}

	public static function notes(): string {
		return (string) get_option( self::NOTES_OPTION, '' );
	}

	public static function save_notes( string $notes ): void {
		update_option( self::NOTES_OPTION, $notes, false );
	}




	public static function check_rate(): bool {
		$limit = (int) self::get( 'writes_per_minute' );
		$key   = 'navia_el_rate_' . get_current_user_id();
		$count = (int) get_transient( $key );
		if ( $count >= $limit ) {
			return false;
		}
		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		return true;
	}
}
