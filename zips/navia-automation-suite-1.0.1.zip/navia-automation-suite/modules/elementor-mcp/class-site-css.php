<?php





defined( 'ABSPATH' ) || exit;

class Navia_EL_Site_CSS {

	const OPTION = 'navia_el_site_css';
	const MAX    = 30000;

	public static function init(): void {
		add_action( 'wp_head', array( __CLASS__, 'print' ), 120 );
	}

	public static function get(): string {
		return (string) get_option( self::OPTION, '' );
	}




	public static function set( string $css ) {
		$css = str_replace( array( "\r\n", "\r" ), "\n", $css );
		$css = wp_strip_all_tags( $css );
		if ( strlen( $css ) > self::MAX ) {
			return new WP_Error( 'navia_el_css', 'Site CSS is limited to ' . self::MAX . ' bytes.' );
		}
		if ( preg_match( '/@import|expression\s*\(|javascript:|behavior\s*:|<\s*\/?\s*style/i', $css ) ) {
			return new WP_Error( 'navia_el_css', 'Site CSS cannot contain @import, expression(), javascript: or style tags.' );
		}
		if ( substr_count( $css, '{' ) !== substr_count( $css, '}' ) ) {
			return new WP_Error( 'navia_el_css', 'Unbalanced braces in the CSS.' );
		}
		update_option( self::OPTION, $css, true );
		return $css;
	}

	public static function print(): void {
		$css = self::get();
		if ( '' === trim( $css ) ) {
			return;
		}
		echo "<style id=\"navia-el-site-css\">\n" . $css . "\n</style>\n";
	}
}
