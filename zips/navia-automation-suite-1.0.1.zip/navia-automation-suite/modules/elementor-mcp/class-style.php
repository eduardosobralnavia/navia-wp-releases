<?php





defined( 'ABSPATH' ) || exit;

class Navia_EL_Style {

	private static $rules = null;

	public static function rules(): array {
		if ( null === self::$rules ) {
			self::$rules = (array) apply_filters( 'navia_el_style_rules', include NAVIA_EL_DIR . 'style-rules.php' );
		}
		return self::$rules;
	}







	public static function check( string $text, string $lang, array $headings = array(), array $texts = array() ): array {
		$rules  = self::rules();
		$issues = array();
		$text   = trim( preg_replace( '/\s+/u', ' ', $text ) );
		$words  = max( 1, count( preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) ) );
		$per_k  = 1000 / $words;


		$dashes = preg_match_all( '/[\x{2013}\x{2014}]|\s-\s/u', $text );
		if ( $dashes ) {
			$issues[] = self::issue( 'warning', "$dashes dash(es) used as punctuation (em, en or spaced hyphen). Rewrite with a full stop, a comma or a colon.", self::where( '/[\x{2013}\x{2014}]|\s-\s/u', $texts ) );
		}


		$phrases = $rules[ $lang ]['phrases'] ?? array();
		$found   = array();
		foreach ( $phrases as $p ) {
			$re = '/(?<![\p{L}])' . preg_quote( $p, '/' ) . '(?![\p{L}])/iu';
			$n  = preg_match_all( $re, $text );
			if ( $n ) {
				$found[ $p ] = $n;
			}
		}
		if ( $found ) {
			arsort( $found );
			$list     = implode( ', ', array_map( fn( $p, $n ) => $n > 1 ? "$p ($n)" : $p, array_keys( $found ), $found ) );
			$re       = '/(?<![\p{L}])(' . implode( '|', array_map( fn( $p ) => preg_quote( $p, '/' ), array_keys( $found ) ) ) . ')(?![\p{L}])/iu';
			$issues[] = self::issue( 'warning', "Stock or filler phrases: $list. Rewrite with something concrete, unless it is the literal meaning.", self::where( $re, $texts ) );
		}


		$and    = 'pt' === $lang ? 'e' : 'and';
		$triads = preg_match_all( '/\b[\p{L}-]+, [\p{L}-]+,? ' . $and . ' [\p{L}-]+\b/u', $text );
		if ( $triads * $per_k > (float) $rules['triads_per_1000_words'] && $triads >= 3 ) {
			$issues[] = self::issue( 'warning', "$triads lists of three in a row (\"x, y $and z\"). Keep one or two; vary the rhythm." );
		}


		if ( count( $headings ) >= 4 ) {
			$colon = count( array_filter( $headings, fn( $h ) => preg_match( '/^[^:]{2,60}:\s/u', $h ) ) );
			if ( $colon / count( $headings ) > (float) $rules['colon_headings_share'] ) {
				$issues[] = self::issue( 'warning', "$colon of " . count( $headings ) . ' headings use the "Topic: subtitle" pattern. Write plain headings.' );
			}
			$questions = count( array_filter( $headings, fn( $h ) => str_ends_with( trim( $h ), '?' ) ) );
			if ( $questions / count( $headings ) > 0.6 && count( $headings ) >= 6 ) {
				$issues[] = self::issue( 'info', "$questions of " . count( $headings ) . ' headings are questions. Fine for FAQ, monotonous elsewhere.' );
			}
		}


		$sentences = array_values( array_filter( array_map( 'trim', preg_split( '/(?<=[.!?])\s+(?=\p{Lu})/u', $text ) ), fn( $s ) => mb_strlen( $s ) > 20 ) );
		if ( count( $sentences ) >= 15 ) {
			$lens = array_map( fn( $s ) => count( preg_split( '/\s+/u', $s ) ), $sentences );
			$mean = array_sum( $lens ) / count( $lens );
			$var  = array_sum( array_map( fn( $l ) => ( $l - $mean ) ** 2, $lens ) ) / count( $lens );
			$cv   = $mean > 0 ? sqrt( $var ) / $mean : 1;
			if ( $cv < (float) $rules['sentence_cv_min'] ) {
				$issues[] = self::issue( 'warning', sprintf( 'Sentences are very even in length (average %.0f words, little variation). Mix short and long sentences.', $mean ) );
			}
			$openings = array_count_values( array_map( fn( $s ) => mb_strtolower( preg_split( '/[\s,]+/u', $s )[0] ), $sentences ) );
			arsort( $openings );
			$top = array_key_first( $openings );
			if ( $openings[ $top ] / count( $sentences ) > (float) $rules['same_opening_share'] && $openings[ $top ] >= 4 ) {
				$issues[] = self::issue( 'warning', $openings[ $top ] . " sentences start with \"$top\"." );
			}
		}

		$ex = substr_count( $text, '!' );
		if ( $ex * $per_k > (float) $rules['exclamations_per_1000'] && $ex >= 3 ) {
			$issues[] = self::issue( 'warning', "$ex exclamation marks. Keep the tone calm and factual." );
		}
		if ( preg_match( '/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', $text ) ) {
			$issues[] = self::issue( 'warning', 'Emoji in the text.', self::where( '/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', $texts ) );
		}
		return $issues;
	}

	private static function issue( string $level, string $message, array $elements = array() ): array {
		$i = array(
			'level'   => $level,
			'type'    => 'style',
			'message' => $message,
		);
		if ( $elements ) {
			$i['elements'] = array_slice( $elements, 0, 15 );
		}
		return $i;
	}




	private static function where( string $re, array $texts ): array {
		$out = array();
		foreach ( $texts as $t ) {
			if ( 'url' === ( $t['kind'] ?? '' ) ) {
				continue;
			}
			if ( preg_match( $re, wp_strip_all_tags( (string) $t['value'] ) ) ) {
				$out[] = $t['id'] . ( isset( $t['index'] ) ? '[' . $t['field'] . ':' . $t['index'] . ']' : '' );
			}
		}
		return array_values( array_unique( $out ) );
	}
}
