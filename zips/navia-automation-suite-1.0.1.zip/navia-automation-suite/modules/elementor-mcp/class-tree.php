<?php





defined( 'ABSPATH' ) || exit;

class Navia_EL_Tree {

	const MAX_DEPTH = 12;

	public static function new_id(): string {
		return substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
	}





	public static function normalize( $elements, array &$errors, array &$warnings, array &$seen = array(), int $depth = 0, string $path = 'root', string $parent_type = '' ): array {
		if ( ! is_array( $elements ) ) {
			$errors[] = "$path: elements must be an array.";
			return array();
		}
		if ( $depth > self::MAX_DEPTH ) {
			$errors[] = "$path: nesting deeper than " . self::MAX_DEPTH . ' levels.';
			return array();
		}
		$el_types     = Navia_EL_Builder::element_types();
		$widget_types = Navia_EL_Builder::widget_types();
		$out          = array();

		foreach ( array_values( $elements ) as $i => $el ) {
			$here = "$path/$i";
			if ( ! is_array( $el ) || empty( $el['elType'] ) || ! is_string( $el['elType'] ) ) {
				$errors[] = "$here: every element needs an elType.";
				continue;
			}
			$type = $el['elType'];
			if ( str_starts_with( $type, 'e-' ) || ( 'widget' === $type && is_string( $el['widgetType'] ?? null ) && str_starts_with( $el['widgetType'], 'e-' ) ) ) {
				$errors[] = "$here: atomic (V4) elements are not used on this site. Use container and the classic widgets (heading, text-editor, button, image, icon-list...).";
				continue;
			}
			if ( 'widget' !== $type && ! in_array( $type, $el_types, true ) ) {
				$errors[] = "$here: unknown elType \"$type\". Known: widget, " . implode( ', ', $el_types ) . '.';
				continue;
			}
			if ( 'widget' === $type ) {
				$wt = $el['widgetType'] ?? '';
				if ( ! is_string( $wt ) || ! in_array( $wt, $widget_types, true ) ) {
					$errors[] = "$here: unknown widgetType \"" . ( is_string( $wt ) ? $wt : '' ) . '". Use list-widgets to see what this site has.';
					continue;
				}
				$nested = Navia_EL_Builder::is_nested( $wt );
				if ( ! empty( $el['elements'] ) && ! $nested ) {
					$errors[] = "$here ($wt): widgets cannot contain elements.";
					continue;
				}
			}
			if ( 'column' === $type && 'section' !== $parent_type ) {
				$warnings[] = "$here: a column should sit inside a section.";
			}
			if ( 'section' === $parent_type && 'column' !== $type ) {
				$warnings[] = "$here: a section should only contain columns.";
			}

			$id = isset( $el['id'] ) && is_string( $el['id'] ) ? $el['id'] : '';
			if ( '' === $id || ! preg_match( '/^[a-z0-9]{2,20}$/i', $id ) || isset( $seen[ $id ] ) ) {
				if ( '' !== $id ) {
					$warnings[] = "$here: id \"$id\" was invalid or duplicated and was replaced.";
				}
				do {
					$id = self::new_id();
				} while ( isset( $seen[ $id ] ) );
			}
			$seen[ $id ] = true;

			$settings = $el['settings'] ?? array();
			if ( ! is_array( $settings ) ) {
				$errors[] = "$here: settings must be an object.";
				continue;
			}

			$norm = array(
				'id'       => $id,
				'elType'   => $type,
				'settings' => $settings,
				'elements' => array(),
			);
			if ( 'widget' === $type ) {
				$norm['widgetType'] = $el['widgetType'];
				if ( $nested ) {
					$norm['elements'] = self::normalize( $el['elements'] ?? array(), $errors, $warnings, $seen, $depth + 1, $here, 'nested' );
				}
			} else {
				$norm['elements'] = self::normalize( $el['elements'] ?? array(), $errors, $warnings, $seen, $depth + 1, $here, $type );
			}
			if ( ! empty( $el['isInner'] ) ) {
				$norm['isInner'] = true;
			}
			$out[] = $norm;
		}
		return $out;
	}

	public static function walk( array $elements, callable $fn, int $depth = 0, string $parent = '' ): void {
		foreach ( $elements as $el ) {
			$fn( $el, $depth, $parent );
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				self::walk( $el['elements'], $fn, $depth + 1, $el['id'] ?? '' );
			}
		}
	}

	public static function count( array $elements ): int {
		$n = 0;
		self::walk(
			$elements,
			function () use ( &$n ) {
				$n++;
			}
		);
		return $n;
	}

	public static function max_depth( array $elements ): int {
		$max = 0;
		self::walk(
			$elements,
			function ( $el, $depth ) use ( &$max ) {
				$max = max( $max, $depth + 1 );
			}
		);
		return $max;
	}




	public static function find_path( array $elements, string $id, array $prefix = array() ): ?array {
		foreach ( $elements as $i => $el ) {
			$p = array_merge( $prefix, array( $i ) );
			if ( ( $el['id'] ?? '' ) === $id ) {
				return $p;
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$r = self::find_path( $el['elements'], $id, $p );
				if ( $r ) {
					return $r;
				}
			}
		}
		return null;
	}

	public static function &node( array &$tree, array $path ) {
		$ref = &$tree[ $path[0] ];
		$n   = count( $path );
		for ( $i = 1; $i < $n; $i++ ) {
			$ref = &$ref['elements'][ $path[ $i ] ];
		}
		return $ref;
	}

	public static function &children( array &$tree, ?array $parent_path ) {
		if ( ! $parent_path ) {
			return $tree;
		}
		$node = &self::node( $tree, $parent_path );
		if ( ! isset( $node['elements'] ) || ! is_array( $node['elements'] ) ) {
			$node['elements'] = array();
		}
		return $node['elements'];
	}

	public static function find( array $elements, string $id ): ?array {
		$p = self::find_path( $elements, $id );
		if ( ! $p ) {
			return null;
		}
		return self::node( $elements, $p );
	}




	public static function reid( array $el ): array {
		$el['id'] = self::new_id();
		if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
			$el['elements'] = array_map( array( __CLASS__, 'reid' ), $el['elements'] );
		}
		return $el;
	}













	public static function apply_operations( array $tree, array $ops ) {
		foreach ( array_values( $ops ) as $n => $op ) {
			$label = 'operation ' . $n;
			if ( ! is_array( $op ) || empty( $op['op'] ) ) {
				return new WP_Error( 'navia_el_bad_op', "$label: missing op." );
			}
			$kind = $op['op'];
			$id   = isset( $op['id'] ) ? (string) $op['id'] : '';

			if ( in_array( $kind, array( 'update', 'replace', 'remove', 'move', 'duplicate', 'set_text' ), true ) ) {
				$path = self::find_path( $tree, $id );
				if ( ! $path ) {
					return new WP_Error( 'navia_el_not_found', "$label ($kind): element \"$id\" not found." );
				}
			}

			switch ( $kind ) {
				case 'update':
					if ( ! isset( $op['settings'] ) || ! is_array( $op['settings'] ) ) {
						return new WP_Error( 'navia_el_bad_op', "$label: update needs settings." );
					}
					$node = &self::node( $tree, $path );
					$cur  = is_array( $node['settings'] ?? null ) ? $node['settings'] : array();
					foreach ( $op['settings'] as $k => $v ) {
						if ( '__globals__' === $k && is_array( $v ) ) {
							$g = is_array( $cur['__globals__'] ?? null ) ? $cur['__globals__'] : array();
							foreach ( $v as $gk => $gv ) {
								if ( null === $gv ) {
									unset( $g[ $gk ] );
								} else {
									$g[ $gk ] = $gv;
								}
							}
							$cur['__globals__'] = $g;
						} elseif ( null === $v ) {
							unset( $cur[ $k ] );
						} else {
							$cur[ $k ] = $v;
						}
					}
					$node['settings'] = $cur;
					unset( $node );
					break;

				case 'replace':
					if ( empty( $op['element'] ) || ! is_array( $op['element'] ) ) {
						return new WP_Error( 'navia_el_bad_op', "$label: replace needs element." );
					}
					$el = $op['element'];
					if ( empty( $el['id'] ) ) {
						$el['id'] = $id;
					}
					$node = &self::node( $tree, $path );
					$node = $el;
					unset( $node );
					break;

				case 'remove':
					$idx    = array_pop( $path );
					$parent = &self::children( $tree, $path ?: null );
					array_splice( $parent, $idx, 1 );
					unset( $parent );
					break;

				case 'duplicate':
					$copy   = self::reid( self::node( $tree, $path ) );
					$idx    = array_pop( $path );
					$parent = &self::children( $tree, $path ?: null );
					array_splice( $parent, $idx + 1, 0, array( $copy ) );
					unset( $parent );
					break;

				case 'insert':
				case 'move':
					$parent_id = isset( $op['parent_id'] ) && '' !== $op['parent_id'] ? (string) $op['parent_id'] : null;
					if ( 'move' === $kind ) {
						$moving = self::node( $tree, $path );
						if ( $parent_id && ( $parent_id === $id || self::find_path( array( $moving ), $parent_id ) ) ) {
							return new WP_Error( 'navia_el_bad_op', "$label: cannot move an element inside itself." );
						}
						$idx    = array_pop( $path );
						$parent = &self::children( $tree, $path ?: null );
						array_splice( $parent, $idx, 1 );
						unset( $parent );
						$items = array( $moving );
					} elseif ( ! empty( $op['elements'] ) && is_array( $op['elements'] ) ) {
						$items = array_values( $op['elements'] );
					} elseif ( ! empty( $op['element'] ) && is_array( $op['element'] ) ) {
						$items = array( $op['element'] );
					} else {
						return new WP_Error( 'navia_el_bad_op', "$label: insert needs element or elements." );
					}
					$ppath = null;
					if ( $parent_id ) {
						$ppath = self::find_path( $tree, $parent_id );
						if ( ! $ppath ) {
							return new WP_Error( 'navia_el_not_found', "$label ($kind): parent \"$parent_id\" not found." );
						}
						if ( 'widget' === ( self::node( $tree, $ppath )['elType'] ?? '' ) ) {
							return new WP_Error( 'navia_el_bad_op', "$label: a widget cannot be a parent." );
						}
					}
					$list = &self::children( $tree, $ppath );
					$pos  = isset( $op['position'] ) ? (int) $op['position'] : -1;
					if ( $pos < 0 || $pos > count( $list ) ) {
						$pos = count( $list );
					}
					array_splice( $list, $pos, 0, $items );
					unset( $list );
					break;

				case 'set_text':
					$field = isset( $op['field'] ) ? (string) $op['field'] : '';
					if ( '' === $field || ! array_key_exists( 'value', $op ) ) {
						return new WP_Error( 'navia_el_bad_op', "$label: set_text needs field and value." );
					}
					$node = &self::node( $tree, $path );
					if ( ! isset( $node['settings'] ) || ! is_array( $node['settings'] ) ) {
						$node['settings'] = array();
					}
					if ( isset( $op['index'] ) ) {
						$sub = isset( $op['subfield'] ) ? (string) $op['subfield'] : '';
						$i   = (int) $op['index'];
						if ( '' === $sub || ! isset( $node['settings'][ $field ][ $i ] ) || ! is_array( $node['settings'][ $field ][ $i ] ) ) {
							return new WP_Error( 'navia_el_bad_op', "$label: repeater item $field[$i] not found (subfield required)." );
						}
						$target = &$node['settings'][ $field ][ $i ][ $sub ];
					} else {
						$target = &$node['settings'][ $field ];
					}
					if ( is_array( $target ) && array_key_exists( 'url', $target ) && ! is_array( $op['value'] ) ) {
						$target['url'] = (string) $op['value'];
					} else {
						$target = $op['value'];
					}
					unset( $target, $node );
					break;

				default:
					return new WP_Error( 'navia_el_bad_op', "$label: unknown op \"$kind\"." );
			}
		}
		return $tree;
	}




	public static function outline( array $elements ): array {
		$rows = array();
		self::walk(
			$elements,
			function ( $el, $depth, $parent ) use ( &$rows ) {
				$s   = is_array( $el['settings'] ?? null ) ? $el['settings'] : array();
				$row = array(
					'id'     => $el['id'] ?? '',
					'depth'  => $depth,
					'parent' => $parent,
					'type'   => 'widget' === ( $el['elType'] ?? '' ) ? ( $el['widgetType'] ?? 'widget' ) : ( $el['elType'] ?? '' ),
				);
				$text = self::first_text( $s );
				if ( '' !== $text ) {
					$row['text'] = $text;
				}
				if ( 'widget' !== ( $el['elType'] ?? '' ) ) {
					$layout = array();
					foreach ( array( 'content_width', 'flex_direction', 'html_tag', 'background_background', '_element_id', 'css_classes' ) as $k ) {
						if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
							$layout[ $k ] = $s[ $k ];
						}
					}
					if ( $layout ) {
						$row['layout'] = $layout;
					}
					$row['children'] = count( $el['elements'] ?? array() );
				} elseif ( 'heading' === ( $el['widgetType'] ?? '' ) ) {
					$row['tag'] = $s['header_size'] ?? 'h2';
				}
				$rows[] = $row;
			}
		);
		return $rows;
	}

	private static function first_text( array $s ): string {
		foreach ( array( 'title', 'editor', 'text', 'title_text', 'description_text', 'html', 'testimonial_content', 'alert_title', 'anchor' ) as $k ) {
			if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
				$t = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $s[ $k ] ) ) );
				if ( '' !== $t ) {
					return mb_substr( $t, 0, 80 );
				}
			}
		}
		return '';
	}




	public static function texts( array $elements ): array {
		$out = array();
		self::walk(
			$elements,
			function ( $el ) use ( &$out ) {
				$type = 'widget' === ( $el['elType'] ?? '' ) ? ( $el['widgetType'] ?? '' ) : ( $el['elType'] ?? '' );
				$map  = Navia_EL_Builder::text_controls( $type, 'widget' === ( $el['elType'] ?? '' ) );
				$s    = is_array( $el['settings'] ?? null ) ? $el['settings'] : array();
				foreach ( $map['fields'] as $field => $kind ) {
					if ( ! isset( $s[ $field ] ) ) {
						continue;
					}
					$v = 'url' === $kind ? ( $s[ $field ]['url'] ?? '' ) : $s[ $field ];
					if ( is_string( $v ) && '' !== trim( $v ) ) {
						$out[] = array(
							'id'     => $el['id'],
							'widget' => $type,
							'field'  => $field,
							'kind'   => $kind,
							'value'  => $v,
						);
					}
				}
				foreach ( $map['repeaters'] as $field => $subs ) {
					if ( empty( $s[ $field ] ) || ! is_array( $s[ $field ] ) ) {
						continue;
					}
					foreach ( array_values( $s[ $field ] ) as $i => $item ) {
						if ( ! is_array( $item ) ) {
							continue;
						}
						foreach ( $subs as $sub => $kind ) {
							if ( ! isset( $item[ $sub ] ) ) {
								continue;
							}
							$v = 'url' === $kind ? ( $item[ $sub ]['url'] ?? '' ) : $item[ $sub ];
							if ( is_string( $v ) && '' !== trim( $v ) ) {
								$out[] = array(
									'id'       => $el['id'],
									'widget'   => $type,
									'field'    => $field,
									'index'    => $i,
									'subfield' => $sub,
									'kind'     => $kind,
									'value'    => $v,
								);
							}
						}
					}
				}
			}
		);
		return $out;
	}
}
