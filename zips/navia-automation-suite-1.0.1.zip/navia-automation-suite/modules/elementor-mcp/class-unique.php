<?php







defined( 'ABSPATH' ) || exit;

class Navia_EL_Unique {

	const K        = 7;
	const MOD      = 2;
	const DB_VER   = '1';
	const STATUSES = array( 'publish', 'future', 'draft', 'pending' );
	const TYPES    = array( 'page', 'post' );

	public static function init(): void {
		add_action( 'save_post', array( __CLASS__, 'on_save' ), 100, 2 );
		add_action( 'trashed_post', array( __CLASS__, 'on_remove' ) );
		add_action( 'deleted_post', array( __CLASS__, 'on_remove' ) );
	}

	public static function tables(): array {
		global $wpdb;
		return array( $wpdb->base_prefix . 'navia_el_fp', $wpdb->base_prefix . 'navia_el_fp_docs' );
	}

	public static function install(): void {
		if ( self::DB_VER === get_site_option( 'navia_el_fp_db' ) ) {
			return;
		}
		global $wpdb;
		list( $fp, $docs ) = self::tables();
		$c                 = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta(
			"CREATE TABLE $fp (
  blog_id bigint(20) unsigned NOT NULL,
  post_id bigint(20) unsigned NOT NULL,
  hash int(10) unsigned NOT NULL,
  lang varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY  (blog_id,post_id,hash),
  KEY hash_lang (hash,lang)
) $c;"
		);
		dbDelta(
			"CREATE TABLE $docs (
  blog_id bigint(20) unsigned NOT NULL,
  post_id bigint(20) unsigned NOT NULL,
  lang varchar(10) NOT NULL DEFAULT '',
  post_type varchar(20) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT '',
  title text NOT NULL,
  url text NOT NULL,
  words int(10) unsigned NOT NULL DEFAULT 0,
  samples int(10) unsigned NOT NULL DEFAULT 0,
  indexed datetime NOT NULL,
  PRIMARY KEY  (blog_id,post_id)
) $c;"
		);
		update_site_option( 'navia_el_fp_db', self::DB_VER );
	}



	public static function text_of( WP_Post $post ): string {
		$html = strip_shortcodes( (string) $post->post_content );
		$html = preg_replace( '/<!--.*?-->/s', ' ', $html );
		$html = preg_replace( '#<(script|style)\b.*?</\1>#is', ' ', $html );
		$html = preg_replace( '#</(p|div|li|h[1-6]|td|th|tr|br)>#i', "$0\n", $html );
		return trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ) );
	}




	public static function tokens( string $text ): array {
		$raw  = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		$orig = array();
		$norm = array();
		foreach ( $raw as $t ) {
			$n = trim( preg_replace( '/[^\p{L}\p{N}]+/u', '', mb_strtolower( $t ) ) );
			if ( '' === $n ) {
				continue;
			}
			$orig[] = $t;
			$norm[] = $n;
		}
		return array( $orig, $norm );
	}

	public static function shingle( array $norm, int $i ): int {
		return (int) sprintf( '%u', crc32( implode( ' ', array_slice( $norm, $i, self::K ) ) ) );
	}

	public static function samples( array $norm ): array {
		$out = array();
		$n   = count( $norm ) - self::K + 1;
		for ( $i = 0; $i < $n; $i++ ) {
			$h = self::shingle( $norm, $i );
			if ( 0 === $h % self::MOD ) {
				$out[ $h ] = true;
			}
		}
		return array_keys( $out );
	}

	private static function lang_of( int $post_id ): string {
		if ( ! taxonomy_exists( 'language' ) ) {
			return '';
		}
		$t = wp_get_object_terms( $post_id, 'language', array( 'fields' => 'slugs' ) );
		return is_array( $t ) && $t ? (string) $t[0] : '';
	}



	public static function eligible( WP_Post $post ): bool {
		return in_array( $post->post_type, self::TYPES, true ) && in_array( $post->post_status, self::STATUSES, true ) && '' === $post->post_password;
	}

	public static function index_post( WP_Post $post ): int {
		global $wpdb;
		self::install();
		list( $fp, $docs ) = self::tables();
		$blog              = get_current_blog_id();
		$wpdb->delete( $fp, array( 'blog_id' => $blog, 'post_id' => $post->ID ) );
		$wpdb->delete( $docs, array( 'blog_id' => $blog, 'post_id' => $post->ID ) );
		if ( ! self::eligible( $post ) ) {
			return 0;
		}
		list( , $norm ) = self::tokens( self::text_of( $post ) );
		$samples        = self::samples( $norm );
		$lang           = self::lang_of( $post->ID );
		foreach ( array_chunk( $samples, 400 ) as $chunk ) {
			$values = array();
			foreach ( $chunk as $h ) {
				$values[] = $wpdb->prepare( '(%d,%d,%d,%s)', $blog, $post->ID, $h, $lang );
			}
			$wpdb->query( "INSERT IGNORE INTO $fp (blog_id,post_id,hash,lang) VALUES " . implode( ',', $values ) );
		}
		$wpdb->insert(
			$docs,
			array(
				'blog_id'   => $blog,
				'post_id'   => $post->ID,
				'lang'      => $lang,
				'post_type' => $post->post_type,
				'status'    => $post->post_status,
				'title'     => mb_substr( $post->post_title, 0, 200 ),
				'url'       => 'publish' === $post->post_status ? (string) get_permalink( $post ) : '',
				'words'     => count( $norm ),
				'samples'   => count( $samples ),
				'indexed'   => current_time( 'mysql' ),
			)
		);
		return count( $samples );
	}

	public static function on_save( $post_id, $post ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! $post instanceof WP_Post ) {
			return;
		}
		if ( ! in_array( $post->post_type, self::TYPES, true ) ) {
			return;
		}
		self::index_post( $post );
	}

	public static function on_remove( $post_id ): void {
		if ( get_site_option( 'navia_el_fp_db' ) !== self::DB_VER ) {
			return;
		}
		global $wpdb;
		list( $fp, $docs ) = self::tables();
		$wpdb->delete( $fp, array( 'blog_id' => get_current_blog_id(), 'post_id' => (int) $post_id ) );
		$wpdb->delete( $docs, array( 'blog_id' => get_current_blog_id(), 'post_id' => (int) $post_id ) );
	}

	public static function index_site( int $after = 0, int $limit = 0 ): array {
		global $wpdb;
		$types    = "'" . implode( "','", self::TYPES ) . "'";
		$statuses = "'" . implode( "','", self::STATUSES ) . "'";
		$sql      = $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE ID > %d AND post_type IN ($types) AND post_status IN ($statuses) ORDER BY ID ASC", $after );
		if ( $limit ) {
			$sql .= ' LIMIT ' . (int) $limit;
		}
		$ids  = array_map( 'intval', $wpdb->get_col( $sql ) );
		$last = $after;
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( $post ) {
				self::index_post( $post );
			}
			$last = $id;
		}
		return array(
			'indexed' => count( $ids ),
			'last'    => $last,
		);
	}





	public static function rebuild( ?array $cursor, int $budget_seconds = 20 ): array {
		global $wpdb;
		self::install();
		list( $fp, $docs ) = self::tables();
		$start             = microtime( true );
		if ( ! $cursor ) {
			$wpdb->query( "DELETE FROM $fp" );
			$wpdb->query( "DELETE FROM $docs" );
			$cursor = array(
				'site'  => 0,
				'after' => 0,
				'docs'  => 0,
			);
		}
		$sites = self::sites();
		while ( $cursor['site'] < count( $sites ) ) {
			$blog = $sites[ $cursor['site'] ];
			if ( is_multisite() ) {
				switch_to_blog( $blog );
			}
			$r = self::index_site( (int) $cursor['after'], 50 );
			if ( is_multisite() ) {
				restore_current_blog();
			}
			$cursor['docs'] += $r['indexed'];
			if ( $r['indexed'] < 50 ) {
				++$cursor['site'];
				$cursor['after'] = 0;
			} else {
				$cursor['after'] = $r['last'];
			}
			if ( microtime( true ) - $start > $budget_seconds ) {
				break;
			}
		}
		$done = $cursor['site'] >= count( $sites );
		if ( $done ) {
			update_site_option( 'navia_el_fp_rebuilt', current_time( 'mysql' ) );
		}
		return array(
			'done'   => $done,
			'cursor' => $done ? null : $cursor,
			'docs'   => $cursor['docs'],
			'sites'  => count( $sites ),
		);
	}

	public static function sites(): array {
		if ( ! is_multisite() ) {
			return array( get_current_blog_id() );
		}
		return array_map(
			'intval',
			get_sites(
				array(
					'fields'   => 'ids',
					'number'   => 2000,
					'archived' => 0,
					'deleted'  => 0,
					'spam'     => 0,
				)
			)
		);
	}

	public static function status(): array {
		global $wpdb;
		self::install();
		list( , $docs ) = self::tables();
		$per_site       = $wpdb->get_results( "SELECT blog_id, COUNT(*) AS docs, MAX(indexed) AS last FROM $docs GROUP BY blog_id", ARRAY_A );
		$indexed        = array_map( 'intval', wp_list_pluck( $per_site, 'blog_id' ) );
		$missing        = array_values( array_diff( self::sites(), $indexed ) );
		return array(
			'documents'        => (int) array_sum( wp_list_pluck( $per_site, 'docs' ) ),
			'sites_indexed'    => count( $per_site ),
			'sites_in_network' => count( self::sites() ),
			'sites_never_seen' => $missing,
			'last_rebuild'     => (string) get_site_option( 'navia_el_fp_rebuilt', '' ),
		);
	}






	public static function check( ?int $post_id = null, array $o = array() ): array {
		global $wpdb;
		self::install();
		list( $fp, $docs ) = self::tables();
		$blog              = get_current_blog_id();
		$min_cross         = (int) ( $o['min_shared_cross'] ?? 2 );
		$min_same          = (int) ( $o['min_shared_same'] ?? 5 );
		$min_words         = (int) ( $o['min_passage_words'] ?? 10 );
		$same_site         = ! isset( $o['include_same_site'] ) || $o['include_same_site'];


		if ( $post_id ) {
			$p = get_post( $post_id );
			if ( $p ) {
				self::index_post( $p );
			}
		} else {
			self::index_site();
		}

		$where = $wpdb->prepare( 'a.blog_id = %d', $blog ) . ( $post_id ? $wpdb->prepare( ' AND a.post_id = %d', $post_id ) : '' );
		$rows  = $wpdb->get_results(
			"SELECT a.post_id AS mine, b.blog_id AS oblog, b.post_id AS other, COUNT(*) AS shared
			 FROM $fp a JOIN $fp b ON b.hash = a.hash AND NOT ( b.blog_id = a.blog_id AND b.post_id = a.post_id )
			 WHERE $where
			 GROUP BY a.post_id, b.blog_id, b.post_id
			 HAVING COUNT(*) >= " . min( $min_cross, $min_same ) . '
			 ORDER BY shared DESC LIMIT 300',
			ARRAY_A
		);

		$pairs = array();
		$seen  = array();
		foreach ( $rows as $r ) {
			$is_same = (int) $r['oblog'] === $blog;
			if ( $is_same && ! $same_site ) {
				continue;
			}
			if ( (int) $r['shared'] < ( $is_same ? $min_same : $min_cross ) ) {
				continue;
			}

			if ( $is_same && in_array( (int) $r['other'], array_map( 'intval', Navia_EL_I18n::translations( (int) $r['mine'] ) ), true ) ) {
				continue;
			}
			$key = $is_same ? min( $r['mine'], $r['other'] ) . '-' . max( $r['mine'], $r['other'] ) : $r['mine'] . '-' . $r['oblog'] . '-' . $r['other'];
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$pairs[]      = $r;
		}

		$out = array();
		foreach ( array_slice( $pairs, 0, 25 ) as $r ) {
			$mine  = get_post( (int) $r['mine'] );
			$odoc  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $docs WHERE blog_id = %d AND post_id = %d", $r['oblog'], $r['other'] ), ARRAY_A );
			$mdoc  = $wpdb->get_row( $wpdb->prepare( "SELECT samples FROM $docs WHERE blog_id = %d AND post_id = %d", $blog, $r['mine'] ), ARRAY_A );
			$other = self::other_text( (int) $r['oblog'], (int) $r['other'] );
			if ( ! $mine || null === $other ) {
				continue;
			}
			$passages = self::passages( self::text_of( $mine ), $other, $min_words );
			if ( ! $passages ) {
				continue;
			}
			$base = max( 1, min( (int) ( $mdoc['samples'] ?? 1 ), (int) ( $odoc['samples'] ?? 1 ) ) );
			$texts = 'builder' === get_post_meta( $mine->ID, '_elementor_edit_mode', true ) ? Navia_EL_Tree::texts( Navia_EL_Builder::get_elements( $mine->ID ) ) : array();
			foreach ( $passages as &$p ) {
				$el = self::locate( $p['norm_head'], $texts );
				if ( $el ) {
					$p['element'] = $el;
				}
				unset( $p['norm_head'] );
			}
			unset( $p );
			$out[] = array(
				'post_id'     => $mine->ID,
				'title'       => $mine->post_title,
				'type'        => $mine->post_type,
				'same_site'   => (int) $r['oblog'] === $blog,
				'other'       => array(
					'blog_id' => (int) $r['oblog'],
					'site'    => is_multisite() ? untrailingslashit( get_blog_details( (int) $r['oblog'] )->domain . get_blog_details( (int) $r['oblog'] )->path ) : '',
					'post_id' => (int) $r['other'],
					'title'   => (string) ( $odoc['title'] ?? '' ),
					'url'     => (string) ( $odoc['url'] ?? '' ),
					'status'  => (string) ( $odoc['status'] ?? '' ),
				),
				'overlap'     => round( min( 1, (int) $r['shared'] / $base ) * 100 ) . '%',
				'repeated_words' => array_sum( wp_list_pluck( $passages, 'words' ) ),
				'passages'    => array_slice( $passages, 0, 8 ),
			);
		}
		return array(
			'index'  => self::status(),
			'scope'  => $post_id ? "post $post_id" : 'site ' . $blog,
			'pairs'  => $out,
			'clean'  => ! $out,
			'note'   => 'Compared with every language (translations of the same page on this site are skipped). Each passage was found word for word (case and punctuation ignored) in the other document. Rewrite it in this document; never in a document of another site without being asked.',
		);
	}

	private static function other_text( int $blog_id, int $post_id ): ?string {
		$switched = false;
		if ( is_multisite() && get_current_blog_id() !== $blog_id ) {
			switch_to_blog( $blog_id );
			$switched = true;
		}
		$p    = get_post( $post_id );
		$text = $p ? self::text_of( $p ) : null;
		if ( $switched ) {
			restore_current_blog();
		}
		return $text;
	}




	public static function passages( string $a, string $b, int $min_words ): array {
		list( $ao, $an ) = self::tokens( $a );
		list( , $bn )    = self::tokens( $b );
		$k               = self::K;
		if ( count( $an ) < $k || count( $bn ) < $k ) {
			return array();
		}
		$set = array();
		$nb  = count( $bn ) - $k + 1;
		for ( $j = 0; $j < $nb; $j++ ) {
			$set[ implode( ' ', array_slice( $bn, $j, $k ) ) ] = true;
		}
		$na   = count( $an ) - $k + 1;
		$hit  = array_fill( 0, count( $an ), false );
		for ( $i = 0; $i < $na; $i++ ) {
			if ( isset( $set[ implode( ' ', array_slice( $an, $i, $k ) ) ] ) ) {
				for ( $x = $i; $x < $i + $k; $x++ ) {
					$hit[ $x ] = true;
				}
			}
		}
		$out = array();
		$n   = count( $an );
		for ( $i = 0; $i < $n; ) {
			if ( ! $hit[ $i ] ) {
				$i++;
				continue;
			}
			$s = $i;
			while ( $i < $n && $hit[ $i ] ) {
				$i++;
			}
			$len = $i - $s;
			if ( $len >= $min_words ) {
				$text  = implode( ' ', array_slice( $ao, $s, $len ) );
				$out[] = array(
					'words'     => $len,
					'text'      => mb_strlen( $text ) > 400 ? mb_substr( $text, 0, 400 ) . '…' : $text,
					'norm_head' => implode( ' ', array_slice( $an, $s, $k ) ),
				);
			}
		}
		usort( $out, fn( $x, $y ) => $y['words'] <=> $x['words'] );
		return $out;
	}

	private static function locate( string $norm_head, array $texts ): ?array {
		foreach ( $texts as $t ) {
			if ( 'url' === ( $t['kind'] ?? '' ) ) {
				continue;
			}
			list( , $n ) = self::tokens( html_entity_decode( wp_strip_all_tags( (string) $t['value'] ), ENT_QUOTES, 'UTF-8' ) );
			if ( false !== strpos( ' ' . implode( ' ', $n ) . ' ', ' ' . $norm_head . ' ' ) ) {
				$loc = array(
					'id'    => $t['id'],
					'field' => $t['field'],
				);
				if ( isset( $t['index'] ) ) {
					$loc['index']    = $t['index'];
					$loc['subfield'] = $t['subfield'];
				}
				return $loc;
			}
		}
		return null;
	}
}
