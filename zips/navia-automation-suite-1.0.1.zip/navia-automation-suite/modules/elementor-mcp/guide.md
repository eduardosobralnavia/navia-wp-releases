# Navia Automation Suite, Elementor module: building guide

Read this before designing. It describes how to write layouts that Elementor (Free, classic V3 format) accepts and that keep this network fast, consistent and good for SEO and GEO.

## 1. Order of work

0. New site: `setup-languages` (on this network the main language is usually en_GB without code in the URL, and pt_PT under /pt/; follow the site's strategy document when it says otherwise).
1. `get-context`: layout mode (containers), languages, theme parts, menus, form shortcodes, what the site allows.
2. `get-kit`: the global colours and fonts. On a new site, set them first with `update-kit`, then save the decisions with `save-design-notes`.
3. Header and footer per language with `save-theme-part`, menus with `save-menu`.
4. Pages in the default language with `create-page`, one at a time, each followed by `check-document`.
5. Other languages: `clone-document` with `lang`, then `get-document` mode `texts`, then `update-document` with `set_text` operations, then SEO meta, then `check-document`.
6. `get-preview-link` to look at drafts in a browser (header_id and footer_id show draft theme parts on the page).
7. Publish (`update-document` status publish) only when the site allows it and the owner asked for it.

Never rebuild a whole page to change a few things: use operations by element id (`get-document` outline gives the ids).

## 2. Element format

A layout is a list of elements. Containers hold containers or widgets. Widgets never hold children, except nested widgets (nested-accordion, nested-tabs), which hold one container per item.

```json
[
  {
    "elType": "container",
    "settings": {
      "content_width": "boxed",
      "flex_direction": "column",
      "flex_gap": {"unit": "px", "column": "24", "row": "24", "isLinked": true},
      "padding": {"unit": "px", "top": "96", "right": "24", "bottom": "96", "left": "24", "isLinked": false},
      "padding_mobile": {"unit": "px", "top": "56", "right": "16", "bottom": "56", "left": "16", "isLinked": false},
      "html_tag": "section",
      "background_background": "classic",
      "__globals__": {"background_color": "globals/colors?id=secondary"}
    },
    "elements": [
      {"elType": "widget", "widgetType": "heading",
       "settings": {"title": "Sites para pequenos negócios", "header_size": "h1",
                    "__globals__": {"title_color": "globals/colors?id=primary", "typography_typography": "globals/typography?id=primary"}}},
      {"elType": "widget", "widgetType": "text-editor",
       "settings": {"editor": "<p>Preço fechado, pronto em cinco dias úteis.</p>",
                    "__globals__": {"typography_typography": "globals/typography?id=text"}}},
      {"elType": "widget", "widgetType": "button",
       "settings": {"text": "Pedir preço", "link": {"url": "/contacto/", "is_external": "", "nofollow": ""}, "size": "md",
                    "background_background": "classic",
                    "__globals__": {"background_color": "globals/colors?id=accent"}}}
    ]
  }
]
```

- `id` is optional on create (7 hex characters are generated). Keep ids when editing.
- Row of columns: a parent container with `flex_direction: "row"` (and `flex_direction_mobile: "column"`), children containers with `content_width: "full"` and `width: {"unit": "%", "size": 50}` (`width_mobile` 100).
- Value shapes: slider `{"unit": "px", "size": 24}`; dimensions `{"unit": "px", "top": "0", "right": "0", "bottom": "0", "left": "0", "isLinked": false}`; gaps `{"unit": "px", "column": "24", "row": "24", "isLinked": true}`; link `{"url": "...", "is_external": "", "nofollow": ""}`; image `{"id": 123, "url": "https://..."}`; icon `{"value": "fas fa-check", "library": "fa-solid"}`.
- Responsive: the same key with `_tablet` or `_mobile` (breakpoints in `get-context`).
- Group controls are switched on by their first key: `typography_typography: "custom"` then `typography_font_size`, `typography_font_weight`...; `background_background: "classic"` then `background_color`; `border_border: "solid"` then `border_width`, `border_color`.
- When unsure of a key, call `list-widgets` with the widget name (tabs `["content"]`, `["style"]` or `["layout","advanced"]`, or `search`).
- Atomic V4 elements (anything starting with `e-`) are refused: the network's performance setup is built for the classic format.

## 3. Global styles

Pages must use the kit, never hard coded hex values, so the brand can change in one place.

- Colours: `"__globals__": {"<color key>": "globals/colors?id=<_id>"}`. System ids: `primary`, `secondary`, `text`, `accent`. Custom colours have their own `_id`.
- Typography: `"__globals__": {"typography_typography": "globals/typography?id=<_id>"}` (also `title_typography_typography`, `description_typography_typography` on boxes).
- `update-kit` example:

```json
{"settings": {
  "system_colors": [
    {"_id": "primary", "title": "Primary", "color": "#0E2A47"},
    {"_id": "secondary", "title": "Secondary", "color": "#F4F1EA"},
    {"_id": "text", "title": "Text", "color": "#1F2933"},
    {"_id": "accent", "title": "Accent", "color": "#E4572E"}
  ],
  "system_typography": [
    {"_id": "primary", "title": "Headings", "typography_typography": "custom", "typography_font_family": "Fraunces", "typography_font_weight": "600"},
    {"_id": "text", "title": "Body", "typography_typography": "custom", "typography_font_family": "Inter", "typography_font_weight": "400", "typography_font_size": {"unit": "px", "size": 17}, "typography_line_height": {"unit": "em", "size": 1.6}}
  ],
  "container_width": {"unit": "px", "size": 1200}
}}
```

Lists are replaced whole: always send every item of the list you change. Use at most two font families and three weights in total.

## 4. Speed rules (PageSpeed 96 to 100 on mobile is the standard here)

- First section: heading, short text, one or two buttons, at most one image. No entrance animations, carousels, videos, maps or background images above the fold.
- Containers no deeper than four levels. Fewer, larger sections beat many small ones.
- Images: WebP from the media library (`navia/generate-image`, `upload-media`), `image_size` "large" or "medium_large" for content, never "full" for photos. Set the alt in the library.
- Icons: Font Awesome solid or brands through the icon controls. No SVG in HTML widgets.
- Nested accordion (`nested-accordion`) instead of the legacy accordion: it uses native details and summary.
- The HTML widget cannot hold script, style, form, iframe or svg on a network subsite (WordPress strips them). Forms come from a shortcode listed in `get-context` (Shortcode widget). When there is no form yet, `navia-suite/setup-contact-form` creates the Contact Form 7 lead form of each language with the right mail settings and returns the shortcode; it takes the kit colours and fonts by itself, so do not restyle it with custom CSS. WhatsApp, phone and email are plain links on buttons.

## 5. SEO and GEO rules

- Exactly one H1 per page, in the layout (pages use `hide_title`). Then H2 per section, H3 inside. No level jumps. Headers and footers have no H1.
- Under each question heading, a direct answer of two or three sentences that makes sense on its own.
- Concrete, dated numbers ("390 euros mais IVA, outubro de 2026"), tables for prices and comparisons (a `table` in a text-editor, with `thead` and `th scope="col"`), and what is not done.
- FAQ: `nested-accordion` with `title_tag` "h3" and `faq_schema` "yes", one FAQ block per page, and never together with a Rank Math FAQ block.
- Internal links in the language of the page: the default language has no code in the URL, the other language has its directory (`/pt/` or `/en/`). `check-document` flags mixed links.
- Rank Math meta through `seo` on create or update: title up to 60 characters, description up to 158, no dashes, focus keyword not repeated in the same language.
- European Portuguese on pt pages (contacto, telemóvel, ecrã, ficheiro, alojamento, registo, equipa). `check-document` lists Brazilian forms it finds.
- No dashes (en or em) anywhere in the text.
- Never invent testimonials, reviews, ratings or clients.

## 6. Writing that reads like a person, and is unique

Clients notice text that sounds generated, and the network depends on every site saying something of its own. `check-document` flags the usual tells; fix every one before calling a page done.

- No dashes as punctuation (em, en or a spaced hyphen). Use a full stop, a comma or a colon.
- No stock phrases: "no mundo atual", "não é apenas... é", "desbloqueie", "eleve o seu negócio", "experiência única", "solução completa", "in today's", "delve", "seamless", "whether you're", "look no further", and the rest of style-rules.php. Say the concrete thing instead.
- Not every list in threes. Not every heading "Topic: subtitle". No emoji, almost no exclamation marks.
- Vary sentence length: a short sentence after a long one. Do not open sentences with the same word again and again.
- Write from the facts of this business: its towns, prices, hours, what it does not do, a real case. Generic sentences are the ones that repeat across sites.
- Never reuse a paragraph, FAQ answer or "how it works" block from another mini-site, not even rewritten lightly. `check-uniqueness` compares this site with every page and post of the network (any language; linked translations on the same site are skipped) and returns each repeated passage with the element id and field to rewrite with `set_text`.
- New sites come with WordPress sample content ("Sample Page", "Hello world!"); trash it, or it shows up as duplicated.

## 7. Headers, footers and single post templates

Templates of the Theme Builder module of Navia Automation Suite (`chf_template`; same post type as the old Custom Header & Footer plugin). With Elementor Pro the module is usually off: then headers and footers are made in the Pro theme builder by the person, and `save-theme-part` answers that the module is off. One per type and language is shown; `save-theme-part` with `activate: true` publishes it and switches off the previous one of that type and language.

- Header: logo or site name (heading with `header_size` "div" or "p", never h1), the Site Menu widget of the Navia widgets module (find it with `list-widgets` search "menu" and read its controls to see how it takes the menu made with `save-menu`), a call to action button, the Polylang switcher as a menu item.
- One menu per language: "Principal PT", "Principal EN".
- Footer: identity, contacts, legal pages, network credit. Before giving containers `html_tag` "header" or "footer", look at the rendered page: if the plugin already wraps the template in that tag, use "div" to avoid a double landmark.
- Single (blog post) template: built with the Navia post widgets (post title as the H1, featured image, post content, table of contents).
- Work on drafts and look at them with `get-preview-link` (`header_id`, `footer_id`, `single_id`) before activating.

## 8. Editing with operations

```json
{"id": 42, "operations": [
  {"op": "update", "id": "a1b2c3d", "settings": {"title": "Novo título"}},
  {"op": "insert", "parent_id": "f00ba12", "position": 1, "element": {"elType": "widget", "widgetType": "text-editor", "settings": {"editor": "<p>...</p>"}}},
  {"op": "move", "id": "9e8d7c6", "parent_id": null, "position": 0},
  {"op": "remove", "id": "1234abc"},
  {"op": "set_text", "id": "77aa88b", "field": "icon_list", "index": 2, "subfield": "text", "value": "Alojamento incluído"}
]}
```

`update` merges settings (null removes a key, `__globals__` merges key by key). All operations apply or none do. Every write keeps the previous layout as a revision (`list-revisions`, `restore-revision`).

## 9. Translating a page

1. `clone-document` `{id, lang: "en", title, slug}`: draft copy linked to the original.
2. `get-document` `{id: new, mode: "texts"}`: every text and link with id, field, index and subfield.
3. `update-document` with one `set_text` operation per string; links (kind url) go to the `/en/` equivalents.
4. `seo` with the English meta, then `check-document`.

## 10. Before saying a page or a site is done

For a page: `check-document` with no errors, warnings read and either fixed or explained, Rank Math meta set, language set and linked, preview looked at on mobile width.

For a whole site (the validation phase): `validate-site`, then fix everything it lists, including every passage in its uniqueness section, and run it again until it comes back clean. If check-uniqueness reports sites never indexed, run `rebuild-uniqueness-index` (repeat with the cursor until done) first.

## 10. Around the build (navia-suite/ abilities)

- Start a session with `navia-suite/get-environment`: modules running, stack status and open checks.
- After the kit and the pages exist: `navia-suite/get-font-plan`, then `navia-suite/apply-font-plan` (OMGF keeps only the fonts in use).
- Cookie bar: `navia-suite/setup-cookie-notice` with the texts per language.
- After changes that touch every page (kit, header, footer): `navia-suite/purge-caches`.
- The SMTP password and the reCAPTCHA secret are typed by the person in Navia Suite > Stack; never ask for them in the chat.
