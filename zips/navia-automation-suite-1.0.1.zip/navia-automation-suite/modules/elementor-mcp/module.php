<?php








defined( 'ABSPATH' ) || exit;

NAS_Plugin::define( 'NAVIA_EL_FILE', NAS_FILE );
NAS_Plugin::define( 'NAVIA_EL_DIR', __DIR__ . '/' );
NAS_Plugin::define( 'NAVIA_EL_NS', 'navia-el' );

require_once __DIR__ . '/class-settings.php';
require_once __DIR__ . '/class-log.php';
require_once __DIR__ . '/class-tree.php';
require_once __DIR__ . '/class-builder.php';
require_once __DIR__ . '/class-i18n.php';
require_once __DIR__ . '/class-seo.php';
require_once __DIR__ . '/class-preview.php';
require_once __DIR__ . '/class-site-css.php';
require_once __DIR__ . '/class-style.php';
require_once __DIR__ . '/class-checks.php';
require_once __DIR__ . '/class-unique.php';
require_once __DIR__ . '/class-abilities.php';
require_once __DIR__ . '/class-admin.php';

add_action(
	'plugins_loaded',
	static function () {
		Navia_EL_Admin::init();
		Navia_EL_Preview::init();
		Navia_EL_Site_CSS::init();
		Navia_EL_Unique::init();
		if ( did_action( 'elementor/loaded' ) && function_exists( 'wp_register_ability' ) ) {
			Navia_EL_Abilities::init();
		}
	},
	20
);
