<?php





defined( 'ABSPATH' ) || exit;

return array(
	'pt' => array(
		'phrases' => array(
			'no mundo atual', 'nos dias de hoje', 'nos dias que correm', 'num mundo cada vez mais', 'em suma', 'em resumo', 'em conclusão',
			'concluindo', 'vale a pena referir', 'é importante notar', 'é importante salientar', 'é importante referir', 'é fundamental',
			'não é apenas', 'não se trata apenas', 'mais do que um simples', 'mais do que uma simples', 'desbloquear', 'desbloqueie',
			'mergulhar', 'mergulhe', 'jornada', 'eleve o seu', 'eleve a sua', 'elevar o seu', 'elevar a sua', 'potenciar', 'potencie',
			'sem complicações', 'experiência única', 'solução completa', 'à medida das suas necessidades', 'no coração de', 'descubra como',
			'seja qual for', 'transformar a sua presença', 'revolucionar', 'revolucione', 'ecossistema', 'robusto', 'robusta', 'sinergia',
			'inovador', 'inovadora', 'de ponta', 'de excelência', 'líder de mercado', 'o próximo nível', 'leve o seu negócio',
			'num piscar de olhos', 'a chave para', 'o segredo para', 'tudo o que precisa de saber', 'guia definitivo', 'guia completo',
			'sem dúvida', 'aliado perfeito', 'parceiro de confiança', 'tranquilidade', 'paz de espírito', 'fazer a diferença',
		),
	),
	'en' => array(
		'phrases' => array(
			"in today's", 'in today’s', 'fast-paced', 'ever-evolving', 'ever-changing', 'delve', 'delves', 'delving', 'unlock', 'unlocks',
			'elevate', 'seamless', 'seamlessly', "whether you're", 'whether you’re', 'look no further', 'game-changer', 'game changer',
			'navigate the', 'tailored to your needs', 'in conclusion', "it's important to note", 'it’s important to note', 'it is important to note',
			'not just', 'more than just', 'embark', 'journey', 'landscape', 'robust', 'cutting-edge', 'in the heart of', 'testament',
			'leverage', 'harness', 'empower', 'realm', 'tapestry', 'bustling', 'vibrant', 'hidden gem', 'nestled', 'peace of mind',
			'take your business to the next level', 'the next level', 'ultimate guide', 'everything you need to know', 'without a doubt',
			'trusted partner', 'one-stop', 'world-class', 'state-of-the-art', 'unparalleled', 'second to none', 'rest assured',
		),
	),

	'triads_per_1000_words' => 4,

	'colon_headings_share'  => 0.3,

	'sentence_cv_min'       => 0.38,

	'same_opening_share'    => 0.2,

	'exclamations_per_1000' => 3,
);
