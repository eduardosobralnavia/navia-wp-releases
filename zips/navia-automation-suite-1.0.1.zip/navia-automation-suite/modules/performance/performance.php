<?php














if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TS_PERF_VERSION', NAS_VERSION );
define( 'TS_PERF_OPTION', 'ts_perf_settings' );
define( 'TS_PERF_LEGACY_OPTION', 'ts_perf_priority_ids' );





function ts_perf_defaults() {
	return array(

		'ids'               => '',
		'hero_url'          => '',
		'hero_srcset'       => '',
		'hero_sizes'        => '',


		'image_sizes'       => '',


		'font_preload'      => '',
		'preconnect'        => '',


		'critical_css'      => '',
		'minify_critical'   => 1,
		'strip_fontface'    => 1,
		'defer_css'         => 0,
		'defer_css_exclude' => "elementor-frontend",


		'delay_js'          => 0,
		'delay_js_patterns' => "googletagmanager\ngoogle-analytics\ngtag(\ncontact-form-7\nwpcf7\nswv\nrecaptcha",
		'delay_js_timeout'  => 5000,
		'remove_jq_migrate' => 0,
		'defer_jquery'      => 0,
		'delay_containers'  => '',


		'defer_scripts'         => 0,
		'defer_scripts_handles' => "jquery-core\nelementor-webpack-runtime\nelementor-frontend-modules\nelementor-frontend\njquery-ui-core\nnav-menu",


		'cf7_conditional'   => 0,
		'cf7_always'        => '',


		'clean_wp'          => 0,
		'clean_block_css'   => 0,
	);
}







function ts_perf_get_map() {
	$map = is_multisite()
		? get_site_option( TS_PERF_OPTION, null )
		: get_option( TS_PERF_OPTION, null );

	if ( ! is_array( $map ) ) {
		$map = ts_perf_migrate_legacy();
	}

	return $map;
}

function ts_perf_migrate_legacy() {
	$legacy = is_multisite()
		? get_site_option( TS_PERF_LEGACY_OPTION, array() )
		: get_option( TS_PERF_LEGACY_OPTION, array() );

	$map = array();

	if ( is_array( $legacy ) ) {
		foreach ( $legacy as $blog_id => $ids ) {
			$row                       = ts_perf_defaults();
			$row['ids']                = is_string( $ids ) ? $ids : '';
			$map[ absint( $blog_id ) ] = $row;
		}
	}

	if ( ! empty( $map ) ) {
		ts_perf_save_map( $map );
	}

	return $map;
}

function ts_perf_save_map( $map ) {
	if ( is_multisite() ) {
		update_site_option( TS_PERF_OPTION, $map );
	} else {
		update_option( TS_PERF_OPTION, $map );
	}
}




function ts_perf_get( $key = null ) {


	static $cache = array();

	$blog_id = get_current_blog_id();

	if ( ! isset( $cache[ $blog_id ] ) ) {
		$map               = ts_perf_get_map();
		$row               = isset( $map[ $blog_id ] ) && is_array( $map[ $blog_id ] ) ? $map[ $blog_id ] : array();
		$cache[ $blog_id ] = array_merge( ts_perf_defaults(), $row );
	}

	if ( null === $key ) {
		return $cache[ $blog_id ];
	}

	return isset( $cache[ $blog_id ][ $key ] ) ? $cache[ $blog_id ][ $key ] : null;
}




function ts_perf_lines( $key ) {
	$raw = (string) ts_perf_get( $key );

	if ( '' === trim( $raw ) ) {
		return array();
	}

	return array_values( array_filter( array_map( 'trim', preg_split( '#\R#', $raw ) ) ) );
}




function ts_perf_is_frontend() {
	if ( is_admin() || wp_doing_ajax() || is_feed() || is_embed() ) {
		return false;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return false;
	}
	if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
		return false;
	}
	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		return false;
	}

	if ( isset( $_GET['elementor-preview'] ) ) {
		return false;
	}
	if ( isset( $_GET['action'] ) && 'elementor' === $_GET['action'] ) {
		return false;
	}
	if ( isset( $_GET['ts_perf_off'] ) ) {

		return false;
	}
	return true;
}















function ts_perf_can_optimize_assets() {
	if ( ! ts_perf_is_frontend() ) {
		return false;
	}

	if ( function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) {
		return false;
	}

	return true;
}











add_filter( 'wp_omit_loading_attr_threshold', function () {
	return 2;
} );





function ts_perf_get_ids_for_current_site() {
	static $cache = array();

	$blog_id = get_current_blog_id();

	if ( isset( $cache[ $blog_id ] ) ) {
		return $cache[ $blog_id ];
	}

	$ids = array_filter( array_map( 'absint', explode( ',', (string) ts_perf_get( 'ids' ) ) ) );

	if ( empty( $ids ) ) {
		$fallback = get_theme_mod( 'custom_logo' );
		if ( ! $fallback ) {
			$fallback = get_option( 'site_logo' );
		}
		if ( $fallback ) {
			$ids = array( absint( $fallback ) );
		}
	}

	$cache[ $blog_id ] = $ids;

	return $ids;
}






function ts_perf_attachment_slug( $id ) {
	$file = get_attached_file( $id );

	if ( ! $file ) {
		return '';
	}

	return preg_quote( pathinfo( $file, PATHINFO_FILENAME ), '#' );
}





function ts_perf_rewrite_images( $html ) {
	$ids = ts_perf_get_ids_for_current_site();

	if ( empty( $ids ) || false === stripos( $html, '<img' ) ) {
		return $html;
	}

	$slugs = array_filter( array_map( 'ts_perf_attachment_slug', $ids ) );

	if ( empty( $slugs ) ) {
		return $html;
	}

	return preg_replace_callback( '#<img\b[^>]*>#i', function ( $m ) use ( $slugs ) {
		$tag = $m[0];

		$hit = false;
		foreach ( $slugs as $slug ) {
			if ( preg_match( '#src="[^"]*' . $slug . '[^"]*"#i', $tag ) ) {
				$hit = true;
				break;
			}
		}

		if ( ! $hit ) {
			return $tag;
		}

		$tag = preg_replace( '#\s+loading="[^"]*"#i', '', $tag );
		$tag = preg_replace( '#\s+fetchpriority="[^"]*"#i', '', $tag );
		$tag = preg_replace( '#\s+decoding="[^"]*"#i', '', $tag );

		return preg_replace(
			'#^<img\b#i',
			'<img loading="eager" fetchpriority="high" decoding="sync"',
			$tag
		);
	}, $html );
}









function ts_perf_sizes_map() {
	static $map = null;

	if ( null !== $map ) {
		return $map;
	}

	$map = array();

	foreach ( ts_perf_lines( 'image_sizes' ) as $line ) {
		$parts = explode( '|', $line, 2 );

		if ( count( $parts ) !== 2 ) {
			continue;
		}

		$id    = absint( trim( $parts[0] ) );
		$sizes = trim( $parts[1] );

		if ( $id && '' !== $sizes ) {
			$map[ $id ] = $sizes;
		}
	}

	return $map;
}












add_filter( 'wp_calculate_image_sizes', function ( $sizes, $size, $image_src, $image_meta, $attachment_id ) {
	if ( is_admin() ) {
		return $sizes;
	}

	$map = ts_perf_sizes_map();

	if ( isset( $map[ (int) $attachment_id ] ) ) {
		return $map[ (int) $attachment_id ];
	}

	return $sizes;
}, 10, 5 );


















function ts_perf_rewrite_scripts( $html ) {
	$patterns = ts_perf_lines( 'delay_js_patterns' );

	if ( empty( $patterns ) || false === stripos( $html, '<script' ) ) {
		return $html;
	}









	$js_types = array( '', 'text/javascript', 'application/javascript' );

	return preg_replace_callback(
		'#<script\b([^>]*)>(.*?)</script>#is',
		function ( $m ) use ( $patterns, $js_types ) {
			$full  = $m[0];
			$attrs = $m[1];


			if ( false !== stripos( $attrs, 'data-ts-perf-loader' ) ) {
				return $full;
			}


			if ( false !== stripos( $attrs, 'ts-perf/delayed' ) ) {
				return $full;
			}


			$type = '';
			if ( preg_match( '#\btype\s*=\s*["\']([^"\']*)["\']#i', $attrs, $t ) ) {
				$type = strtolower( trim( $t[1] ) );
			}
			if ( ! in_array( $type, $js_types, true ) ) {
				return $full;
			}



			$hit = false;
			foreach ( $patterns as $needle ) {
				if ( '' !== $needle && false !== stripos( $full, $needle ) ) {
					$hit = true;
					break;
				}
			}

			if ( ! $hit ) {
				return $full;
			}


			$new_attrs = preg_replace( '#\s*\btype\s*=\s*["\'][^"\']*["\']#i', '', $attrs );
			$new_attrs = rtrim( $new_attrs );

			$keep_type = ( '' !== $type )
				? ' data-ts-type="' . esc_attr( $type ) . '"'
				: '';

			return '<script' . $new_attrs . ' type="ts-perf/delayed"' . $keep_type . '>' . $m[2] . '</script>';
		},
		$html
	);
}





add_action( 'wp_footer', function () {
	if ( ! ts_perf_can_optimize_assets() || ! ts_perf_get( 'delay_js' ) ) {
		return;
	}

	if ( empty( ts_perf_lines( 'delay_js_patterns' ) ) ) {
		return;
	}

	$timeout = absint( ts_perf_get( 'delay_js_timeout' ) );



	$js = <<<'JS'
(function(){
"use strict";
var EV=["keydown","mousedown","mousemove","wheel","touchstart","touchmove","touchend","scroll"],
    done=false,T=__TS_TIMEOUT__;
function off(){for(var i=0;i<EV.length;i++){window.removeEventListener(EV[i],boot,{passive:true});}}
function fin(){
  try{document.dispatchEvent(new Event("DOMContentLoaded",{bubbles:true}));}catch(e){}
  try{window.dispatchEvent(new Event("load",{bubbles:true}));}catch(e){}
}
function boot(){
  if(done){return;}
  done=true;off();
  var list=[].slice.call(document.querySelectorAll('script[type="ts-perf/delayed"]')),i=0;
  (function nxt(){
    if(i>=list.length){fin();return;}
    var o=list[i++],s=document.createElement("script"),hasSrc=!!o.src;
    for(var k=0;k<o.attributes.length;k++){
      var a=o.attributes[k];
      if(a.name==="type"||a.name==="data-ts-type"){continue;}
      s.setAttribute(a.name,a.value);
    }
    var t=o.getAttribute("data-ts-type");
    if(t){s.type=t;}
    s.async=false;
    if(hasSrc){s.addEventListener("load",nxt);s.addEventListener("error",nxt);}
    else{s.text=o.text;}
    o.parentNode.replaceChild(s,o);
    if(!hasSrc){nxt();}
  })();
}
for(var i=0;i<EV.length;i++){window.addEventListener(EV[i],boot,{passive:true});}
if(T>0){setTimeout(boot,T);}
})();
JS;

	$js = str_replace( '__TS_TIMEOUT__', (string) $timeout, $js );

	echo "\n<script data-ts-perf-loader=\"1\">" . $js . "</script>\n";
}, 999 );

























function ts_perf_rewrite_delay_containers( $html ) {
	$ids = ts_perf_lines( 'delay_containers' );

	if ( empty( $ids ) || false === stripos( $html, 'data-id=' ) ) {
		return $html;
	}

	foreach ( $ids as $id ) {
		$id = preg_quote( $id, '#' );

		if ( '' === $id ) {
			continue;
		}




		$html = preg_replace_callback(
			'#<div\b([^>]*\bdata-id="' . $id . '"[^>]*)>#i',
			function ( $m ) {
				if ( false !== stripos( $m[1], 'data-delay-child-handlers' ) ) {
					return $m[0];
				}
				return '<div' . $m[1] . ' data-delay-child-handlers="true">';
			},
			$html
		);
	}

	return $html;
}



function ts_perf_buffer( $html ) {
	if ( ! is_string( $html ) || '' === $html ) {
		return $html;
	}


	if ( false === stripos( $html, '</html>' ) && false === stripos( $html, '<body' ) ) {
		return $html;
	}

	$html = ts_perf_rewrite_images( $html );

	if ( ! empty( ts_perf_lines( 'delay_containers' ) ) ) {
		$html = ts_perf_rewrite_delay_containers( $html );
	}





	if ( ts_perf_can_optimize_assets() && ts_perf_get( 'delay_js' ) ) {
		$html = ts_perf_rewrite_scripts( $html );
	}

	return $html;
}

add_action( 'template_redirect', function () {
	if ( ! ts_perf_is_frontend() ) {
		return;
	}

	$needs_images  = ! empty( ts_perf_get_ids_for_current_site() );
	$needs_scripts = (bool) ts_perf_get( 'delay_js' );
	$needs_delay   = ! empty( ts_perf_lines( 'delay_containers' ) );

	if ( ! $needs_images && ! $needs_scripts && ! $needs_delay ) {
		return;
	}

	ob_start( 'ts_perf_buffer' );
}, 0 );





add_action( 'wp_head', function () {
	if ( ! ts_perf_is_frontend() ) {
		return;
	}

	$out = '';




	$origins = array_slice( ts_perf_lines( 'preconnect' ), 0, 4 );
	foreach ( $origins as $origin ) {
		$out .= '<link rel="preconnect" href="' . esc_url( $origin ) . '" crossorigin>' . "\n";
	}





	foreach ( ts_perf_lines( 'font_preload' ) as $font ) {
		$out .= '<link rel="preload" as="font" type="font/woff2" crossorigin href="' . esc_url( $font ) . '">' . "\n";
	}


	if ( is_front_page() ) {
		$url = trim( (string) ts_perf_get( 'hero_url' ) );

		if ( $url ) {
			$srcset = trim( (string) ts_perf_get( 'hero_srcset' ) );
			$sizes  = trim( (string) ts_perf_get( 'hero_sizes' ) );

			$tag = '<link rel="preload" as="image" fetchpriority="high" href="' . esc_url( $url ) . '"';
			if ( $srcset ) {
				$tag .= ' imagesrcset="' . esc_attr( $srcset ) . '"';
			}
			if ( $sizes ) {
				$tag .= ' imagesizes="' . esc_attr( $sizes ) . '"';
			}
			$out .= $tag . ">\n";
		}
	}

	echo $out;
}, 1 );
















function ts_perf_minify_css( $css ) {
	$css = preg_replace( '#/\*(?!!)[\s\S]*?\*/#', '', $css );
	$css = preg_replace( '#\s+#', ' ', $css );
	$css = preg_replace( '#\s*([{};,])\s*#', '$1', $css );
	$css = str_replace( ';}', '}', $css );

	return trim( (string) $css );
}

add_action( 'wp_head', function () {
	if ( ! ts_perf_can_optimize_assets() ) {
		return;
	}

	$css = trim( (string) ts_perf_get( 'critical_css' ) );

	if ( ! $css ) {
		return;
	}

	echo '<style id="ts-perf-critical">' . wp_strip_all_tags( $css ) . "</style>\n";
}, 2 );









add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	if ( ! ts_perf_can_optimize_assets() || ! ts_perf_get( 'defer_css' ) ) {
		return $tag;
	}

	if ( ! trim( (string) ts_perf_get( 'critical_css' ) ) ) {
		return $tag;
	}

	foreach ( ts_perf_lines( 'defer_css_exclude' ) as $ex ) {
		if ( false !== stripos( $handle, $ex ) || false !== stripos( $tag, $ex ) ) {
			return $tag;
		}
	}


	if ( preg_match( '#media=[\'"](?!all|screen)#i', $tag ) ) {
		return $tag;
	}

	$deferred = preg_replace(
		'#media=[\'"][^\'"]*[\'"]#i',
		'media="print" onload="this.media=\'all\';this.onload=null;"',
		$tag
	);


	if ( $deferred === $tag ) {
		$deferred = preg_replace(
			'#(\s*/?>)$#',
			' media="print" onload="this.media=\'all\';this.onload=null;"$1',
			trim( $tag )
		);
	}

	return $deferred . '<noscript>' . $tag . '</noscript>';
}, 10, 2 );





add_action( 'wp_default_scripts', function ( $scripts ) {
	if ( is_admin() || ! ts_perf_get( 'remove_jq_migrate' ) ) {
		return;
	}

	if ( ! empty( $scripts->registered['jquery'] ) ) {
		$scripts->registered['jquery']->deps = array_diff(
			$scripts->registered['jquery']->deps,
			array( 'jquery-migrate' )
		);
	}
} );













function ts_perf_defer_handles() {
	static $set = null;

	if ( null !== $set ) {
		return $set;
	}

	$set = array();

	if ( ! ts_perf_get( 'defer_scripts' ) ) {
		return $set;
	}

	$seed = ts_perf_lines( 'defer_scripts_handles' );

	if ( empty( $seed ) ) {
		return $set;
	}

	$set = array_flip( $seed );

	global $wp_scripts;

	if ( ! ( $wp_scripts instanceof WP_Scripts ) ) {
		return $set;
	}



	$changed = true;
	$guard   = 0;

	while ( $changed && $guard++ < 20 ) {
		$changed = false;

		foreach ( $wp_scripts->registered as $handle => $obj ) {
			if ( isset( $set[ $handle ] ) ) {
				continue;
			}

			foreach ( (array) $obj->deps as $dep ) {
				if ( isset( $set[ $dep ] ) ) {
					$set[ $handle ] = true;
					$changed        = true;
					break;
				}
			}
		}
	}

	return $set;
}

add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( ! ts_perf_can_optimize_assets() ) {
		return $tag;
	}

	$set = ts_perf_defer_handles();

	if ( empty( $set ) || ! isset( $set[ $handle ] ) ) {
		return $tag;
	}


	if ( false === stripos( $tag, ' src=' ) ) {
		return $tag;
	}

	if ( false !== stripos( $tag, ' defer' ) || false !== stripos( $tag, ' async' ) ) {
		return $tag;
	}

	return str_replace( ' src=', ' defer src=', $tag );
}, 10, 2 );






add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( ! ts_perf_can_optimize_assets() || ! ts_perf_get( 'defer_jquery' ) ) {
		return $tag;
	}

	if ( ! in_array( $handle, array( 'jquery', 'jquery-core', 'jquery-migrate' ), true ) ) {
		return $tag;
	}

	if ( false !== stripos( $tag, ' defer' ) || false !== stripos( $tag, ' async' ) ) {
		return $tag;
	}

	return str_replace( ' src=', ' defer src=', $tag );
}, 10, 2 );













function ts_perf_page_needs_cf7() {



	$needles = array( 'contact-form-7', 'wpcf7' );


	foreach ( ts_perf_lines( 'cf7_always' ) as $path ) {
		$path = trim( $path, '/' );
		if ( '' === $path ) {
			continue;
		}
		$request = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( false !== stripos( $request, $path ) ) {
			return true;
		}
	}

	if ( ! is_singular() && ! is_front_page() ) {
		return true;
	}

	$post = get_post();

	if ( ! $post ) {
		return true;
	}

	if ( has_shortcode( (string) $post->post_content, 'contact-form-7' ) ) {
		return true;
	}

	$elementor = get_post_meta( $post->ID, '_elementor_data', true );

	if ( is_string( $elementor ) && '' !== $elementor ) {
		foreach ( $needles as $needle ) {
			if ( false !== stripos( $elementor, $needle ) ) {
				return true;
			}
		}
	}

	return false;
}





add_action( 'wp_enqueue_scripts', function () {
	if ( ! ts_perf_is_frontend() || ! ts_perf_get( 'cf7_conditional' ) ) {
		return;
	}

	if ( ts_perf_page_needs_cf7() ) {
		return;
	}

	add_filter( 'wpcf7_load_js', '__return_false' );
	add_filter( 'wpcf7_load_css', '__return_false' );
}, 5 );





add_action( 'init', function () {
	if ( ! ts_perf_get( 'clean_wp' ) ) {
		return;
	}

	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'wp_oembed_add_host_js' );

	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
} );

add_action( 'wp_enqueue_scripts', function () {
	if ( ! ts_perf_get( 'clean_block_css' ) ) {
		return;
	}

	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );
}, 100 );





add_action( 'network_admin_menu', function () {
	add_submenu_page(
		NAS_Admin::MENU,
		'Performance',
		'Performance',
		'manage_network_options',
		'ts-performance',
		'ts_perf_render_network_page'
	);
} );

add_action( 'admin_menu', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	add_submenu_page(
		NAS_Admin::MENU,
		'Performance',
		'Performance',
		'manage_options',
		'ts-performance-site',
		'ts_perf_render_site_page'
	);
} );

function ts_perf_sanitize_row( $raw ) {
	$out = ts_perf_defaults();

	$ids        = isset( $raw['ids'] ) ? sanitize_text_field( $raw['ids'] ) : '';
	$clean_ids  = array_filter( array_map( 'absint', explode( ',', $ids ) ) );
	$out['ids'] = implode( ',', $clean_ids );

	$out['hero_url']    = isset( $raw['hero_url'] ) ? esc_url_raw( $raw['hero_url'] ) : '';
	$out['hero_srcset'] = isset( $raw['hero_srcset'] ) ? sanitize_text_field( $raw['hero_srcset'] ) : '';
	$out['hero_sizes']  = isset( $raw['hero_sizes'] ) ? sanitize_text_field( $raw['hero_sizes'] ) : '';

	$out['image_sizes'] = isset( $raw['image_sizes'] )
		? sanitize_textarea_field( $raw['image_sizes'] )
		: '';


	foreach ( array( 'font_preload', 'preconnect' ) as $field ) {
		$lines = isset( $raw[ $field ] ) ? preg_split( '#\R#', (string) $raw[ $field ] ) : array();
		$clean = array();
		foreach ( (array) $lines as $line ) {
			$line = esc_url_raw( trim( $line ) );
			if ( '' !== $line ) {
				$clean[] = $line;
			}
		}
		$out[ $field ] = implode( "\n", $clean );
	}

	$out['minify_critical'] = ! empty( $raw['minify_critical'] ) ? 1 : 0;



	$critical = isset( $raw['critical_css'] ) ? trim( wp_strip_all_tags( $raw['critical_css'] ) ) : '';

	$out['strip_fontface'] = ! empty( $raw['strip_fontface'] ) ? 1 : 0;






	if ( $critical && $out['strip_fontface'] ) {
		$critical = preg_replace( '#@font-face\s*\{[^{}]*\}#i', '', $critical );
		$critical = trim( (string) $critical );
	}

	if ( $critical && $out['minify_critical'] ) {
		$before   = strlen( $critical );
		$critical = ts_perf_minify_css( $critical );
		set_transient(
			'ts_perf_minify_report_' . get_current_blog_id(),
			array( $before, strlen( $critical ) ),
			300
		);
	}

	$out['critical_css'] = $critical;

	$out['defer_css']         = ! empty( $raw['defer_css'] ) ? 1 : 0;
	$out['defer_css_exclude'] = isset( $raw['defer_css_exclude'] )
		? sanitize_textarea_field( $raw['defer_css_exclude'] )
		: '';

	$out['delay_js']          = ! empty( $raw['delay_js'] ) ? 1 : 0;
	$out['delay_js_patterns'] = isset( $raw['delay_js_patterns'] )
		? sanitize_textarea_field( $raw['delay_js_patterns'] )
		: '';
	$out['delay_js_timeout']  = isset( $raw['delay_js_timeout'] ) ? absint( $raw['delay_js_timeout'] ) : 0;

	$out['remove_jq_migrate'] = ! empty( $raw['remove_jq_migrate'] ) ? 1 : 0;
	$out['defer_jquery']      = ! empty( $raw['defer_jquery'] ) ? 1 : 0;

	$out['delay_containers'] = isset( $raw['delay_containers'] )
		? sanitize_textarea_field( $raw['delay_containers'] )
		: '';

	$out['defer_scripts']         = ! empty( $raw['defer_scripts'] ) ? 1 : 0;
	$out['defer_scripts_handles'] = isset( $raw['defer_scripts_handles'] )
		? sanitize_textarea_field( $raw['defer_scripts_handles'] )
		: '';

	$out['cf7_conditional'] = ! empty( $raw['cf7_conditional'] ) ? 1 : 0;
	$out['cf7_always']      = isset( $raw['cf7_always'] )
		? sanitize_textarea_field( $raw['cf7_always'] )
		: '';

	$out['clean_wp']        = ! empty( $raw['clean_wp'] ) ? 1 : 0;
	$out['clean_block_css'] = ! empty( $raw['clean_block_css'] ) ? 1 : 0;

	return $out;
}




function ts_perf_critical_help() {
	?>
	<div style="background:#fff;border:1px solid #c3c4c7;border-left:4px solid #2271b1;padding:12px 16px;margin:16px 0;max-width:62em">
		<h3 style="margin-top:0">Como gerar o CSS critico</h3>
		<p>
			Este plugin <strong>inlina</strong> o CSS critico e <strong>adia</strong> o resto. O que nao consegue fazer e <strong>gerar</strong> esse CSS: descobrir o que esta acima da dobra exige renderizar a pagina num browser real e medir o viewport, e isso nenhum plugin PHP faz. Os plugins pagos que o oferecem estao a chamar um servico externo por tras.
		</p>
		<p><strong>Geradores gratuitos</strong> (testados em 07/2026: os dois primeiros funcionaram, os tres seguintes deram erro ou timeout, provavelmente porque o site demorava demasiado a responder):</p>
		<ol style="margin-left:1.4em">
			<li><a href="https://w3speedup.com/tools/critical-css-generator/" target="_blank" rel="noopener">w3speedup.com/tools/critical-css-generator</a> &ndash; <strong>funcionou.</strong> Poe as regras <code>@font-face</code> no inicio do output, o que ajuda o LCP</li>
			<li><a href="https://berqwp.com/free-critical-css-generator-online/" target="_blank" rel="noopener">berqwp.com/free-critical-css-generator-online</a> &ndash; <strong>funcionou.</strong> So pede o URL, sem opcoes</li>
			<li><a href="https://seojuice.com/tools/critical-css-generator/" target="_blank" rel="noopener">seojuice.com/tools/critical-css-generator</a> &ndash; permite viewport e wait time, e ate 5 URLs combinados</li>
			<li><a href="https://testingbot.com/free-online-tools/critical-css-generator" target="_blank" rel="noopener">testingbot.com/free-online-tools/critical-css-generator</a> &ndash; viewport minimo de 800x600, nao tem mobile</li>
			<li><a href="https://www.corewebvitals.io/tools/critical-css-generator" target="_blank" rel="noopener">corewebvitals.io/tools/critical-css-generator</a></li>
		</ol>
		<p><strong>Definicoes a usar:</strong> viewport <code>360 x 640</code> (e o que o Lighthouse usa em mobile), wait time <code>5000 ms</code>, e <strong>nao</strong> bloquear pedidos de JavaScript &ndash; com o lazy load de backgrounds do Elementor ativo, o fundo do hero e aplicado por JS e sem ele o gerador nao o ve.</p>
		<p style="margin-bottom:0">
			<strong>Importante:</strong> o CSS critico e especifico de cada pagina e do desenho atual. Se mudares o hero, o header ou o menu, gera-o outra vez. Enquanto o campo estiver vazio, o adiamento das folhas de estilo fica automaticamente inativo, para nao veres a pagina sem estilos.
		</p>
	</div>
	<?php
}




function ts_perf_render_fields( $blog_id, $row ) {
	$name = function ( $field ) use ( $blog_id ) {
		return 'ts_perf[' . $blog_id . '][' . $field . ']';
	};
	?>

	<h3 style="margin-bottom:0">Imagens e LCP</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">IDs de imagens prioritarias</th>
			<td>
				<input type="text" name="<?php echo esc_attr( $name( 'ids' ) ); ?>" value="<?php echo esc_attr( $row['ids'] ); ?>" class="regular-text" placeholder="ex. 257">
				<p class="description">ID do anexo do logo do header; varios separados por virgulas. Encontras o numero em Media &rarr; Biblioteca, no fim do URL. Estas imagens perdem o <code>loading="lazy"</code> e ganham <code>fetchpriority="high"</code>, o que elimina o CLS do header. <strong>Sem risco.</strong></p>
			</td>
		</tr>

		<tr>
			<th scope="row">Imagem LCP da homepage</th>
			<td>
				<input type="url" name="<?php echo esc_attr( $name( 'hero_url' ) ); ?>" value="<?php echo esc_attr( $row['hero_url'] ); ?>" class="large-text" placeholder="https://.../hero.jpg">
				<p class="description">URL exato da imagem de fundo do hero, para preload. Confirma no DevTools &rarr; Network &rarr; Img qual e o ficheiro que carrega a 360px.</p>

				<p style="margin-top:10px">
					<label>imagesrcset (opcional)<br>
					<input type="text" name="<?php echo esc_attr( $name( 'hero_srcset' ) ); ?>" value="<?php echo esc_attr( $row['hero_srcset'] ); ?>" class="large-text" placeholder="hero-768.jpg 768w, hero-1600.jpg 1600w"></label>
				</p>
				<p>
					<label>imagesizes (opcional)<br>
					<input type="text" name="<?php echo esc_attr( $name( 'hero_sizes' ) ); ?>" value="<?php echo esc_attr( $row['hero_sizes'] ); ?>" class="large-text" placeholder="100vw"></label><br>
					<span class="description">Se o hero tiver versoes por breakpoint, preenche estes dois. Sem eles, mobile descarrega a versao desktop e o preload sai caro.</span>
				</p>
				<p class="description" style="margin-top:10px">
					<strong>Nota:</strong> se o elemento LCP da pagina for <em>texto</em> e nao uma imagem, este preload nao muda o LCP. Confirma na secção <em>Analise detalhada de LCP</em> do PageSpeed qual e o elemento.
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Corrigir <code>sizes</code> de imagens</th>
			<td>
				<textarea name="<?php echo esc_attr( $name( 'image_sizes' ) ); ?>" rows="4" class="large-text code" placeholder="60|(max-width:767px) 90vw, 567px"><?php echo esc_textarea( $row['image_sizes'] ); ?></textarea>
				<p class="description">
					Uma por linha, no formato <code>ID_do_anexo|valor_de_sizes</code>.
				</p>
				<p class="description" style="margin-top:8px">
					<strong>Para que serve:</strong> o WordPress gera por defeito <code>sizes="(max-width: 1152px) 100vw, 1152px"</code>, ou seja, diz ao browser que a imagem ocupa a largura toda do ecra. Se ela for na verdade apresentada numa coluna estreita, o browser escolhe do <code>srcset</code> um ficheiro muito maior do que precisa. E a causa do aviso <em>"Este ficheiro de imagem e maior do que precisa de ser"</em> no PageSpeed.
				</p>
				<p class="description" style="margin-top:8px">
					<strong>Como descobrir o ID:</strong> no relatorio do PageSpeed, a classe da imagem tem o numero &mdash; <code>class="attachment-full size-full wp-image-<strong>60</strong>"</code>. Ou em Media &rarr; Biblioteca, no fim do URL.
					<br><strong>Como descobrir a largura real:</strong> no DevTools, passa o rato sobre a imagem no separador Elements e le o <em>Rendered size</em>. Usa esse valor em pixels.
				</p>
			</td>
		</tr>
	</table>

	<h3 style="margin-bottom:0">Fontes e ligacoes</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">Preload de fontes</th>
			<td>
				<textarea name="<?php echo esc_attr( $name( 'font_preload' ) ); ?>" rows="3" class="large-text code" placeholder="https://site.pt/wp-content/uploads/omgf/.../inter-normal-latin.woff2"><?php echo esc_textarea( $row['font_preload'] ); ?></textarea>
				<p class="description">Um URL <code>.woff2</code> por linha. Um ficheiro de fonte referido dentro de um CSS externo so e descoberto depois desse CSS chegar e ser processado &mdash; o preload tira-o dessa cadeia. Poe aqui apenas as fontes usadas acima da dobra (tipicamente o peso normal dos titulos e do corpo). <strong>Sem risco.</strong></p>
			</td>
		</tr>
		<tr>
			<th scope="row">Preconnect</th>
			<td>
				<textarea name="<?php echo esc_attr( $name( 'preconnect' ) ); ?>" rows="3" class="large-text code" placeholder="https://www.googletagmanager.com"><?php echo esc_textarea( $row['preconnect'] ); ?></textarea>
				<p class="description">Uma origem por linha, maximo 4 (as restantes sao ignoradas). Estabelece a ligacao TCP/TLS mais cedo. <strong>Sem risco.</strong></p>
			</td>
		</tr>
	</table>

	<h3 style="margin-bottom:0">CSS</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">CSS critico</th>
			<td>
				<textarea name="<?php echo esc_attr( $name( 'critical_css' ) ); ?>" rows="8" class="large-text code" placeholder="Cola aqui o CSS gerado (ver instrucoes acima)"><?php echo esc_textarea( $row['critical_css'] ); ?></textarea>
				<p class="description">
					<?php if ( trim( $row['critical_css'] ) ) : ?>
						<span style="color:#00701a">Definido (<?php echo esc_html( number_format_i18n( strlen( $row['critical_css'] ) ) ); ?> caracteres).</span>
						<?php
						$report = get_transient( 'ts_perf_minify_report_' . $blog_id );
						if ( is_array( $report ) && ! empty( $report[0] ) && $report[1] < $report[0] ) :
							$pct = round( ( 1 - $report[1] / $report[0] ) * 100 );
							?>
							<span style="color:#646970">Comprimido de <?php echo esc_html( number_format_i18n( $report[0] ) ); ?> para <?php echo esc_html( number_format_i18n( $report[1] ) ); ?> (&minus;<?php echo esc_html( $pct ); ?>%).</span>
						<?php endif; ?>
					<?php else : ?>
						<span style="color:#996800">Vazio. Enquanto estiver assim, o adiamento das folhas de estilo fica inativo.</span>
					<?php endif; ?>
				</p>

				<p style="margin-top:10px">
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'strip_fontface' ) ); ?>" value="1" <?php checked( $row['strip_fontface'], 1 ); ?>> <strong>Remover blocos <code>@font-face</code> ao guardar</strong></label><br>
					<span class="description">
						Os geradores de CSS critico incluem as regras <code>@font-face</code> com URLs <strong>sem</strong> <code>?ver=</code>. Se o OMGF estiver a servir as mesmas fontes com <code>?ver=</code>, o browser trata-os como ficheiros diferentes e <strong>descarrega a mesma fonte duas vezes</strong>, alem de poder gerar 404. Deixa isto ligado salvo se souberes que precisas das regras.
					</span>
				</p>

				<p style="margin-top:10px">
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'minify_critical' ) ); ?>" value="1" <?php checked( $row['minify_critical'], 1 ); ?>> Comprimir ao guardar</label><br>
					<span class="description">
						Conservador de proposito: <strong>nao</strong> mexe em espacos em volta de operadores, porque o Elementor usa <code>calc( ( 1 - var( --x ) ) * 100% )</code>, onde esses espacos fazem parte da sintaxe. Nota que o CSS inline ja vai comprimido em gzip/Brotli com o HTML, por isso a poupanca em bytes transferidos e pequena &mdash; o ganho e no tempo de parse. A compressao e feita sobre o texto guardado.
					</span>
				</p>
			</td>
		</tr>

		<tr>
			<th scope="row">Adiar folhas de estilo</th>
			<td>
				<label><input type="checkbox" name="<?php echo esc_attr( $name( 'defer_css' ) ); ?>" value="1" <?php checked( $row['defer_css'], 1 ); ?>> Retirar o CSS nao critico do caminho de renderizacao</label>
				<p class="description">Usa <code>media="print" onload="this.media='all'"</code>, com fallback em <code>&lt;noscript&gt;</code>. So tem efeito com o CSS critico preenchido. <strong>Risco medio:</strong> testa visualmente todas as paginas depois de ativar.</p>

				<p style="margin-top:10px">
					<label>Nunca adiar (um por linha: handle ou parte do nome do ficheiro)<br>
					<textarea name="<?php echo esc_attr( $name( 'defer_css_exclude' ) ); ?>" rows="4" class="large-text code"><?php echo esc_textarea( $row['defer_css_exclude'] ); ?></textarea></label><br>
					<span class="description">Se algo aparecer sem estilo durante o carregamento, acrescenta-o aqui.</span>
				</p>
			</td>
		</tr>
	</table>

	<h3 style="margin-bottom:0">JavaScript</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">Adiar JS ate a interacao</th>
			<td>
				<label><input type="checkbox" name="<?php echo esc_attr( $name( 'delay_js' ) ); ?>" value="1" <?php checked( $row['delay_js'], 1 ); ?>> <strong>Adiar os scripts abaixo ate ao primeiro toque, scroll ou tecla</strong></label>
				<p class="description">
					E a funcionalidade com maior retorno da suite, e a equivalente ao <em>delay JavaScript</em> dos plugins pagos. Os scripts sao marcados com um tipo que o browser nao executa, e um carregador de ~700 bytes volta a coloca-los em execucao <strong>pela ordem original</strong> na primeira interacao.
					<br><br>
					Resolve em simultaneo o Google Tag Manager (peso grande e tarefas longas) e o Contact Form 7 (as chamadas REST <code>/feedback/schema</code> e <code>/NNN/refill</code>, que atrasam o caminho critico mesmo em paginas onde o formulario nao e usado).
					<br><br>
					<strong>O formulario continua visivel de imediato</strong>, porque e HTML. Apenas a validacao inicializa ao primeiro toque, muito antes de alguem conseguir escrever no primeiro campo. Isto torna viavel ter o CF7 no hero sem pagar o preco no LCP.
				</p>

				<p style="margin-top:12px">
					<label>Padroes a adiar (um por linha)<br>
					<textarea name="<?php echo esc_attr( $name( 'delay_js_patterns' ) ); ?>" rows="6" class="large-text code"><?php echo esc_textarea( $row['delay_js_patterns'] ); ?></textarea></label><br>
					<span class="description">
						Sao <strong>substrings simples</strong>, nao expressoes regulares, comparadas com a tag <code>&lt;script&gt;</code> completa (atributos e conteudo inline). Scripts com <code>type</code> que nao seja JavaScript &mdash; como o <code>application/ld+json</code> do Rank Math &mdash; nunca sao adiados.
						<br><strong>Nao</strong> poe aqui <code>jquery</code>, <code>elementor</code> nem <code>frontend</code>: sao necessarios para a pagina funcionar.
					</span>
				</p>

				<p style="margin-top:12px">
					<label>Carregar de qualquer forma apos (ms)
					<input type="number" min="0" step="500" name="<?php echo esc_attr( $name( 'delay_js_timeout' ) ); ?>" value="<?php echo esc_attr( $row['delay_js_timeout'] ); ?>" class="small-text"></label><br>
					<span class="description">
						Rede de seguranca para visitantes que nunca interagem. <strong>Com <code>0</code> os scripts so correm com interacao</strong>, o que da a melhor pontuacao mas faz-te <strong>perder as visitas de quem sai sem tocar em nada</strong> nas estatisticas &mdash; e tipicamente uma boa parte do trafego. O valor por defeito de <code>5000</code> mantem os dados intactos e o custo em pontuacao e pequeno, porque a essa altura as metricas de pintura ja foram registadas. Recomendo deixar em 5000 e nao trocar analytics por 2 pontos.
					</span>
				</p>

				<p style="margin-top:12px" class="description">
					<strong>Depois de ativar, testa obrigatoriamente:</strong> submeter o formulario de contacto e confirmar que o email chega; menu mobile abre e fecha; acordeoes do FAQ; e que o Analytics registou a visita (Tempo real).
					<br>Para diagnostico, acrescenta <code>?ts_perf_off=1</code> a qualquer URL para desligar todo o plugin nesse pedido.
				</p>
			</td>
		</tr>

		<tr>
			<th scope="row">Adiar scripts (defer nativo)</th>
			<td>
				<label><input type="checkbox" name="<?php echo esc_attr( $name( 'defer_scripts' ) ); ?>" value="1" <?php checked( $row['defer_scripts'], 1 ); ?>> <strong>Aplicar <code>defer</code> aos handles abaixo</strong></label>
				<p class="description">
					Diferente de <em>Adiar JS ate a interacao</em>: aqui os scripts continuam a correr sozinhos, logo apos o parse do HTML, sem esperar por toque nenhum. So deixam de <strong>bloquear a pintura</strong> da pagina. E o indicado para o proprio nucleo do Elementor, que tem de correr para os widgets funcionarem.
				</p>
				<p style="margin-top:10px">
					<label>Handles a adiar (um por linha)<br>
					<textarea name="<?php echo esc_attr( $name( 'defer_scripts_handles' ) ); ?>" rows="5" class="large-text code"><?php echo esc_textarea( $row['defer_scripts_handles'] ); ?></textarea></label>
				</p>
				<p class="description">
					<strong>O plugin expande a lista automaticamente:</strong> qualquer handle registado que dependa de um dos indicados e adiado tambem, em cadeia. Isto e o que impede o erro classico <code>jQuery is not defined</code> &mdash; se adiares <code>jquery</code>, tudo o que depende dele (incluindo <code>elementor-frontend</code>) e arrastado junto, mantendo a ordem correta. Nao precisas de descobrir as dependencias a mao.
				</p>
				<p class="description" style="margin-top:8px">
					<strong>Limitacao a conhecer:</strong> o <code>defer</code> nao afeta scripts <em>inline</em>. Se algum plugin imprimir codigo inline que <em>chame</em> uma biblioteca adiada (em vez de so definir variaveis), esse codigo corre antes e falha. Os inline do Elementor e do CF7 apenas definem configuracao, por isso sao seguros &mdash; mas se instalares outro plugin, testa de novo.
				</p>
				<p class="description" style="color:#b32d2e;margin-top:8px">
					Depois de ativar, testa: menu mobile, acordeoes do FAQ, galeria de imagens e submissao do formulario.
				</p>
			</td>
		</tr>

		<tr>
			<th scope="row">jQuery</th>
			<td>
				<p>
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'remove_jq_migrate' ) ); ?>" value="1" <?php checked( $row['remove_jq_migrate'], 1 ); ?>> Remover jquery-migrate</label><br>
					<span class="description">5 KiB bloqueantes. So e preciso para codigo antigo. <strong>Risco baixo</strong>, mas testa o formulario.</span>
				</p>

				<p style="margin-top:10px">
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'defer_jquery' ) ); ?>" value="1" <?php checked( $row['defer_jquery'], 1 ); ?>> <strong>Adiar jQuery</strong></label><br>
					<span class="description" style="color:#b32d2e"><strong>Metodo antigo, mantido por compatibilidade. Prefere a opcao acima.</strong> Este interruptor adia <em>apenas</em> os handles do jQuery, sem arrastar os que dependem dele &mdash; o que pode fazer o <code>elementor-frontend</code> correr primeiro e rebentar com <code>jQuery is not defined</code>. Para adiar o jQuery em seguranca, acrescenta <code>jquery</code> a lista de <em>Adiar scripts (defer nativo)</em> em vez de usares esta caixa: a expansao automatica de dependencias trata da ordem.</span>
				</p>
			</td>
		</tr>
	</table>

	<h3 style="margin-bottom:0">Atrasar inicializacao de containers (avancado)</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">Containers a atrasar</th>
			<td>
				<textarea name="<?php echo esc_attr( $name( 'delay_containers' ) ); ?>" rows="3" class="large-text code" placeholder="64c47b77"><?php echo esc_textarea( $row['delay_containers'] ); ?></textarea>
				<p class="description">
					Um <code>data-id</code> de container Elementor por linha (visivel no Inspecionar Elemento, depois de <code>elementor-element-</code>). O plugin insere <code>data-delay-child-handlers="true"</code> nessa tag &mdash; e o proprio <code>frontend.min.js</code> do Elementor que verifica este atributo antes de correr qualquer inicializacao de widget, incluindo dos que estao la dentro. Equivalente gratuito ao controlo "Custom Attributes" do Elementor Pro, aplicado so a este atributo.
				</p>
				<p class="description" style="color:#b32d2e;margin-top:8px">
					<strong>Risco alto se usado no container errado.</strong> Desliga TODA a interatividade JS dentro do container: sliders, motion effects, elementos sticky, popups, animacoes. So e seguro em zonas com apenas texto, imagens e links simples (<code>&lt;a href&gt;</code>). <strong>Nunca</strong> usar num container com formulario, carrossel de testemunhos, ou efeitos de movimento.
				</p>
				<p class="description">
					Pensado para o container do hero, onde a inicializacao consome tempo de CPU (recalculos de layout) sem trazer comportamento que o utilizador precise. Testa sempre visualmente numa janela anonima depois de ativar.
				</p>
			</td>
		</tr>
	</table>

	<h3 style="margin-bottom:0">Contact Form 7</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">Carregar so onde ha formulario</th>
			<td>
				<label><input type="checkbox" name="<?php echo esc_attr( $name( 'cf7_conditional' ) ); ?>" value="1" <?php checked( $row['cf7_conditional'], 1 ); ?>> Nao carregar o JS/CSS do CF7 em paginas sem formulario</label>
				<p class="description">
					Usa os filtros oficiais <code>wpcf7_load_js</code> e <code>wpcf7_load_css</code>. A detecao procura o shortcode no conteudo do post <strong>e</strong> dentro dos dados do Elementor, porque um formulario num widget de shortcode nao aparece no <code>post_content</code>.
					<br><br>
					<strong>Nao ative se o formulario estiver num header ou footer global</strong> do Theme Builder: a detecao e por pagina e nesse caso falharia. Em caso de duvida a funcao carrega os assets, que e o lado seguro do erro.
				</p>
				<p style="margin-top:10px">
					<label>Carregar sempre nestes caminhos (um por linha)<br>
					<textarea name="<?php echo esc_attr( $name( 'cf7_always' ) ); ?>" rows="3" class="large-text code" placeholder="contacts&#10;contactos&#10;pedir-orcamento"><?php echo esc_textarea( $row['cf7_always'] ); ?></textarea></label><br>
					<span class="description">Parte do URL. Rede de seguranca para paginas onde a detecao falhe.</span>
				</p>
			</td>
		</tr>
	</table>

	<h3 style="margin-bottom:0">Limpeza do WordPress</h3>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">Assets nao usados</th>
			<td>
				<p>
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'clean_wp' ) ); ?>" value="1" <?php checked( $row['clean_wp'], 1 ); ?>> Remover emojis, oEmbed e metadados do <code>&lt;head&gt;</code></label><br>
					<span class="description">Desativa a incorporacao automatica de YouTube/X por URL. <strong>Risco baixo.</strong></span>
				</p>
				<p style="margin-top:10px">
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'clean_block_css' ) ); ?>" value="1" <?php checked( $row['clean_block_css'], 1 ); ?>> Remover CSS do editor de blocos</label><br>
					<span class="description">Seguro em sites 100% Elementor. Se alguma pagina usar blocos do Gutenberg (por exemplo artigos no site mae), deixa desativado nesse site.</span>
				</p>
			</td>
		</tr>
	</table>
	<?php
}

function ts_perf_render_network_page() {
	if ( ! current_user_can( 'manage_network_options' ) ) {
		wp_die( 'Sem permissoes.' );
	}

	$saved    = false;
	$scanned  = 0;
	$applied  = 0;

	if ( isset( $_POST['ts_perf_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['ts_perf_nonce'] ), 'ts_perf_save' ) ) {




		$incoming = isset( $_POST['ts_perf'] ) && is_array( $_POST['ts_perf'] ) ? wp_unslash( $_POST['ts_perf'] ) : array();

		if ( $incoming ) {
			$map = array();
			foreach ( $incoming as $blog_id => $raw ) {
				$map[ absint( $blog_id ) ] = ts_perf_sanitize_row( $raw );
			}
			ts_perf_save_map( $map );
			$saved = true;
		}


		if ( ! empty( $_POST['ts_perf_scan'] ) ) {
			$target = absint( $_POST['ts_perf_scan'] );

			switch_to_blog( $target );
			$findings = ts_perf_run_scan();
			restore_current_blog();

			set_site_transient( 'ts_perf_scan_' . $target, $findings, 30 * MINUTE_IN_SECONDS );
			$scanned = $target;


		} elseif ( ! empty( $_POST['ts_perf_apply_go'] ) ) {
			$target  = absint( $_POST['ts_perf_apply_go'] );
			$indexes = isset( $_POST['ts_perf_apply'][ $target ] ) ? (array) $_POST['ts_perf_apply'][ $target ] : array();



			$applied = ts_perf_apply_findings( $target, $indexes );

			if ( 0 === $applied ) {
				$applied = -1;
			}

		}
	}

	$map   = ts_perf_get_map();
	$sites = get_sites( array( 'number' => 200, 'orderby' => 'id' ) );
	?>
	<div class="wrap">
		<h1>Navia Suite &ndash; Performance <span style="font-size:13px;color:#646970">v<?php echo esc_html( TS_PERF_VERSION ); ?></span></h1>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible"><p>Definicoes guardadas. Purga a cache do W3 Total Cache e testa numa janela anonima.</p></div>
		<?php endif; ?>

		<?php if ( $scanned ) : ?>
			<div class="notice notice-info is-dismissible"><p>Analise concluida. Ve o resultado na seccao do site correspondente, mais abaixo.</p></div>
		<?php endif; ?>

		<?php if ( $applied > 0 ) : ?>
			<div class="notice notice-success is-dismissible"><p><strong><?php echo esc_html( $applied ); ?></strong> definicao(oes) aplicada(s) e guardada(s). Confirma os valores no formulario abaixo e purga a cache do W3 Total Cache.</p></div>
		<?php elseif ( -1 === $applied ) : ?>
			<div class="notice notice-warning is-dismissible"><p>Nada foi alterado: as definicoes selecionadas ja tinham o valor sugerido, ou a analise expirou. Se expirou, corre <strong>Analisar este site</strong> outra vez.</p></div>
		<?php endif; ?>

		<p style="max-width:62em">Cada subsite tem as suas definicoes. As alteracoes aplicam-se so ao site escolhido, nunca a rede toda. Sites novos aparecem aqui automaticamente, com tudo desligado.</p>

		<div style="background:#fff;border:1px solid #c3c4c7;border-left:4px solid #d63638;padding:12px 16px;margin:16px 0;max-width:62em">
			<h3 style="margin-top:0">Como medir sem se enganar</h3>
			<p style="margin-bottom:8px"><strong>Ignora sempre a primeira medicao depois de purgar a cache.</strong> Com a cache vazia o servidor gera tudo do zero e a pontuacao pode cair 15 pontos sem que nada esteja errado. Corre o PageSpeed <strong>duas ou tres vezes</strong> e usa a mediana.</p>
			<p style="margin-bottom:0">Ativa <strong>uma funcionalidade de cada vez</strong> quando o risco indicado for medio ou alto. As de risco baixo podem ir todas juntas.</p>
		</div>

		<?php ts_perf_critical_help(); ?>

		<form method="post">
			<?php wp_nonce_field( 'ts_perf_save', 'ts_perf_nonce' ); ?>

			<?php foreach ( $sites as $site ) :
				$blog_id = (int) $site->blog_id;

				switch_to_blog( $blog_id );
				$site_name = get_bloginfo( 'name' );
				$site_url  = home_url();
				restore_current_blog();

				$row = isset( $map[ $blog_id ] ) && is_array( $map[ $blog_id ] )
					? array_merge( ts_perf_defaults(), $map[ $blog_id ] )
					: ts_perf_defaults();

				$active = array();
				if ( $row['ids'] ) {
					$active[] = 'CLS';
				}
				if ( $row['critical_css'] && $row['defer_css'] ) {
					$active[] = 'CSS critico';
				}
				if ( $row['delay_js'] ) {
					$active[] = 'JS adiado';
				}
				if ( $row['font_preload'] ) {
					$active[] = 'preload fontes';
				}
				if ( $row['cf7_conditional'] ) {
					$active[] = 'CF7 condicional';
				}
				?>
				<details style="background:#fff;border:1px solid #c3c4c7;margin:14px 0;padding:0">
					<summary style="cursor:pointer;padding:14px 16px;font-size:15px;font-weight:600">
						<?php echo esc_html( $site_name ? $site_name : 'Site ' . $blog_id ); ?>
						<span style="font-weight:400;color:#646970"> &ndash; <?php echo esc_html( preg_replace( '#^https?://#', '', $site_url ) ); ?></span>
						<?php if ( $active ) : ?>
							<span style="color:#00701a;font-weight:400"> &bull; <?php echo esc_html( implode( ', ', $active ) ); ?></span>
						<?php else : ?>
							<span style="color:#996800;font-weight:400"> &bull; nada ativo</span>
						<?php endif; ?>
					</summary>
					<div style="padding:0 16px 8px">
						<?php ts_perf_render_scan( $blog_id ); ?>
						<?php ts_perf_render_fields( $blog_id, $row ); ?>
					</div>
				</details>
			<?php endforeach; ?>

			<?php submit_button( 'Guardar definicoes' ); ?>
		</form>

		<h2>Ordem recomendada</h2>
		<ol style="max-width:62em;margin-left:1.4em">
			<li><strong>IDs prioritarios</strong>, <strong>preload de fontes</strong>, <strong>preconnect</strong> e <strong>limpeza</strong> &ndash; risco baixo, podem ir todos de uma vez.</li>
			<li><strong>Adiar JS ate a interacao</strong> &ndash; o maior ganho. Testa o formulario e o Analytics.</li>
			<li><strong>CSS critico + adiar folhas de estilo</strong> &ndash; segundo maior ganho. Testa visualmente todas as paginas.</li>
			<li><strong>CF7 condicional</strong> &ndash; so se o formulario nao estiver num header/footer global.</li>
			<li><strong>jquery-migrate</strong>, e por fim <strong>adiar jQuery</strong> &ndash; um de cada vez.</li>
		</ol>
	</div>
	<?php
}

function ts_perf_render_site_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Sem permissoes.' );
	}

	$blog_id = get_current_blog_id();
	$saved   = false;
	$scanned = false;
	$applied = 0;

	if ( isset( $_POST['ts_perf_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['ts_perf_nonce'] ), 'ts_perf_save_site' ) ) {
		$incoming = isset( $_POST['ts_perf'][ $blog_id ] ) && is_array( $_POST['ts_perf'][ $blog_id ] )
			? wp_unslash( $_POST['ts_perf'][ $blog_id ] )
			: array();


		$map             = ts_perf_get_map();
		$map[ $blog_id ] = ts_perf_sanitize_row( $incoming );

		ts_perf_save_map( $map );
		$saved = true;

		if ( ! empty( $_POST['ts_perf_scan'] ) ) {
			set_site_transient( 'ts_perf_scan_' . $blog_id, ts_perf_run_scan(), 30 * MINUTE_IN_SECONDS );
			$scanned = true;
		} elseif ( ! empty( $_POST['ts_perf_apply_go'] ) ) {
			$indexes = isset( $_POST['ts_perf_apply'][ $blog_id ] ) ? (array) $_POST['ts_perf_apply'][ $blog_id ] : array();
			$applied = ts_perf_apply_findings( $blog_id, $indexes );
			$applied = $applied ? $applied : -1;
		}

		if ( class_exists( 'NAS_Cache' ) ) {
			NAS_Cache::purge( 0 );
		}
	}

	$map = ts_perf_get_map();
	$row = isset( $map[ $blog_id ] ) && is_array( $map[ $blog_id ] )
		? array_merge( ts_perf_defaults(), $map[ $blog_id ] )
		: ts_perf_defaults();
	?>
	<div class="wrap">
		<h1>Navia Suite &ndash; Performance &ndash; <?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible"><p>Guardado e caches limpas. Testa numa janela anonima e ignora a primeira medicao do PageSpeed.</p></div>
		<?php endif; ?>
		<?php if ( $scanned ) : ?>
			<div class="notice notice-info is-dismissible"><p>Analise concluida. Ve as sugestoes abaixo e aplica so as que quiseres.</p></div>
		<?php endif; ?>
		<?php if ( $applied > 0 ) : ?>
			<div class="notice notice-success is-dismissible"><p><strong><?php echo esc_html( $applied ); ?></strong> definicao(oes) aplicada(s). Confirma os valores no formulario.</p></div>
		<?php elseif ( -1 === $applied ) : ?>
			<div class="notice notice-warning is-dismissible"><p>Nada foi alterado: os valores ja eram os sugeridos, ou a analise expirou.</p></div>
		<?php endif; ?>

		<?php if ( NAS_Env::network_mode() && current_user_can( 'manage_network_options' ) ) : ?>
			<p>Numa rede, todos os subsites tambem se configuram em <a href="<?php echo esc_url( network_admin_url( 'admin.php?page=ts-performance' ) ); ?>">Network Admin &gt; Navia Suite &gt; Performance</a>.</p>
		<?php endif; ?>

		<?php ts_perf_critical_help(); ?>

		<form method="post">
			<?php wp_nonce_field( 'ts_perf_save_site', 'ts_perf_nonce' ); ?>
			<?php ts_perf_render_scan( $blog_id ); ?>
			<?php ts_perf_render_fields( $blog_id, $row ); ?>
			<?php submit_button( 'Guardar' ); ?>
		</form>
	</div>
	<?php
}















function ts_perf_risky_widgets() {
	return array(
		'form', 'shortcode', 'login', 'search-form', 'password',
		'toggle', 'accordion', 'tabs', 'nested-tabs', 'nested-accordion',
		'slides', 'image-carousel', 'media-carousel', 'testimonial-carousel',
		'reviews', 'loop-carousel', 'nav-menu', 'menu-anchor',
		'video', 'google_maps', 'countdown', 'counter', 'progress',
		'lottie', 'animated-headline', 'gallery', 'portfolio', 'posts',
		'alert', 'social-icons', 'share-buttons',
	);
}






function ts_perf_safe_widgets() {
	return array(
		'heading', 'text-editor', 'image', 'button',
		'icon', 'icon-box', 'icon-list', 'divider', 'spacer',
		'star-rating', 'testimonial', 'text-path',
	);
}




function ts_perf_collect_widgets( $node, &$widgets, &$motion ) {
	if ( ! is_array( $node ) ) {
		return;
	}

	if ( isset( $node['widgetType'] ) ) {
		$widgets[] = $node['widgetType'];
	}

	if ( ! empty( $node['settings'] ) && is_array( $node['settings'] ) ) {
		foreach ( $node['settings'] as $k => $v ) {
			$is_dynamic = ( false !== strpos( $k, 'motion_fx' ) )
				|| ( 0 === strpos( $k, 'sticky' ) )
				|| ( false !== strpos( $k, '_animation' ) )
				|| ( false !== strpos( $k, 'background_video' ) );

			if ( $is_dynamic && '' !== $v && array() !== $v && 'none' !== $v ) {
				$motion = true;
			}
		}
	}

	if ( ! empty( $node['elements'] ) && is_array( $node['elements'] ) ) {
		foreach ( $node['elements'] as $child ) {
			ts_perf_collect_widgets( $child, $widgets, $motion );
		}
	}
}




function ts_perf_elementor_data( $post_id ) {
	$raw = get_post_meta( $post_id, '_elementor_data', true );

	if ( ! $raw || ! is_string( $raw ) ) {
		return array();
	}

	$data = json_decode( $raw, true );

	return is_array( $data ) ? $data : array();
}




function ts_perf_front_page_id() {
	if ( 'page' !== get_option( 'show_on_front' ) ) {
		return 0;
	}
	return (int) get_option( 'page_on_front' );
}





function ts_perf_footer_template_id() {
	$hfe = get_posts( array(
		'post_type'      => 'elementor-hf',
		'posts_per_page' => 5,
		'post_status'    => 'publish',
		'fields'         => 'ids',
	) );

	foreach ( (array) $hfe as $id ) {
		$type = get_post_meta( $id, 'ehf_template_type', true );
		if ( 'type_footer' === $type || 'footer' === $type ) {
			return (int) $id;
		}
	}

	$pro = get_posts( array(
		'post_type'      => 'elementor_library',
		'posts_per_page' => 5,
		'post_status'    => 'publish',
		'fields'         => 'ids',
		'meta_query'     => array(
			array(
				'key'   => '_elementor_template_type',
				'value' => 'footer',
			),
		),
	) );

	if ( ! empty( $pro[0] ) ) {
		return (int) $pro[0];
	}

	return 0;
}




function ts_perf_scan_containers( $data ) {
	$risky_list = ts_perf_risky_widgets();
	$safe_list  = ts_perf_safe_widgets();
	$out        = array();

	foreach ( (array) $data as $el ) {
		if ( ! is_array( $el ) ) {
			continue;
		}

		$type = isset( $el['elType'] ) ? $el['elType'] : '';
		if ( 'container' !== $type && 'section' !== $type ) {
			continue;
		}

		$widgets = array();
		$motion  = false;
		ts_perf_collect_widgets( $el, $widgets, $motion );
		$widgets = array_values( array_unique( $widgets ) );

		$hits    = array_values( array_intersect( $widgets, $risky_list ) );
		$unknown = array_values( array_diff( $widgets, $risky_list, $safe_list ) );

		$verdict = 'safe';
		$reasons = array();

		if ( $hits ) {
			$verdict   = 'risky';
			$reasons[] = 'widgets interativos: ' . implode( ', ', $hits );
		}
		if ( $motion ) {
			$verdict   = 'risky';
			$reasons[] = 'motion effects, sticky ou video de fundo';
		}
		if ( $unknown ) {
			if ( 'safe' === $verdict ) {
				$verdict = 'unknown';
			}
			$reasons[] = 'widgets nao classificados: ' . implode( ', ', $unknown );
		}

		$out[] = array(
			'id'      => isset( $el['id'] ) ? $el['id'] : '',
			'verdict' => $verdict,
			'widgets' => $widgets,
			'reasons' => $reasons,
		);
	}

	return $out;
}





function ts_perf_scan_hero( $data ) {
	foreach ( (array) $data as $el ) {
		if ( ! is_array( $el ) || empty( $el['settings'] ) ) {
			continue;
		}

		$s = $el['settings'];

		foreach ( array( 'background_image_mobile', 'background_image' ) as $key ) {
			if ( ! empty( $s[ $key ]['url'] ) ) {
				return array(
					'id'     => isset( $el['id'] ) ? $el['id'] : '',
					'url'    => $s[ $key ]['url'],
					'mobile' => ( 'background_image_mobile' === $key ),
				);
			}
		}
	}

	return null;
}




function ts_perf_collect_headings( $node, &$out ) {
	if ( ! is_array( $node ) ) {
		return;
	}

	if ( isset( $node['widgetType'] ) && 'heading' === $node['widgetType'] ) {
		$s     = ! empty( $node['settings'] ) ? $node['settings'] : array();
		$tag   = ! empty( $s['header_size'] ) ? strtolower( $s['header_size'] ) : 'h2';
		$out[] = array(
			'tag'   => $tag,
			'title' => isset( $s['title'] ) ? wp_strip_all_tags( $s['title'] ) : '',
		);
	}

	if ( ! empty( $node['elements'] ) && is_array( $node['elements'] ) ) {
		foreach ( $node['elements'] as $c ) {
			ts_perf_collect_headings( $c, $out );
		}
	}
}




function ts_perf_check_headings( $headings ) {
	$problems = array();
	$prev     = 0;

	foreach ( $headings as $i => $h ) {
		if ( ! preg_match( '#^h([1-6])$#', $h['tag'], $m ) ) {
			continue;
		}

		$level = (int) $m[1];
		$title = $h['title'] ? '"' . mb_substr( $h['title'], 0, 45 ) . '"' : '(sem texto)';

		if ( 0 === $prev ) {
			if ( 1 !== $level ) {
				$problems[] = sprintf(
					'#%d [%s] %s — o primeiro titulo devia ser H1. Se for texto decorativo por cima do titulo, muda o HTML Tag para <code>p</code> ou <code>span</code> em vez de um nivel de heading.',
					$i + 1,
					strtoupper( $h['tag'] ),
					esc_html( $title )
				);
			}
		} elseif ( $level > $prev + 1 ) {
			$problems[] = sprintf(
				'#%d [%s] %s — salta de H%d para H%d. Devia ser no maximo H%d.',
				$i + 1,
				strtoupper( $h['tag'] ),
				esc_html( $title ),
				$prev,
				$level,
				$prev + 1
			);
		}

		$prev = $level;
	}

	return $problems;
}




function ts_perf_url_to_path( $url ) {
	$up   = wp_get_upload_dir();
	$base = trailingslashit( $up['baseurl'] );
	$dir  = trailingslashit( $up['basedir'] );

	$clean = strtok( $url, '?' );

	if ( 0 !== strpos( $clean, $base ) ) {
		return '';
	}

	return $dir . substr( $clean, strlen( $base ) );
}







function ts_perf_scan_omgf_fonts() {
	$up   = wp_get_upload_dir();
	$root = trailingslashit( $up['basedir'] ) . 'omgf';

	if ( ! is_dir( $root ) ) {
		return array();
	}

	$found = array();
	$sheets = glob( $root . '/*/*.css' );

	foreach ( (array) $sheets as $sheet ) {
		$css = file_get_contents( $sheet );

		if ( ! $css ) {
			continue;
		}

		if ( preg_match_all( '#url\(\s*[\'"]?([^\'")]+\.woff2[^\'")]*)#i', $css, $m ) ) {
			foreach ( $m[1] as $url ) {

				if ( false !== stripos( $url, 'latin-ext' ) ) {
					continue;
				}
				if ( 0 === strpos( $url, '//' ) ) {
					$url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
				}
				$found[ $url ] = true;
			}
		}
	}

	return array_keys( $found );
}




function ts_perf_run_scan() {
	$cur      = ts_perf_get();
	$findings = array();


	$logo = get_theme_mod( 'custom_logo' );
	if ( ! $logo ) {
		$logo = get_option( 'site_logo' );
	}

	if ( $logo ) {
		$findings[] = array(
			'key'       => 'ids',
			'group'     => 'safe',
			'label'     => 'ID do logo (correcao de CLS)',
			'current'   => $cur['ids'],
			'suggested' => (string) absint( $logo ),
			'note'      => 'Detetado a partir do logo definido no Personalizador.',
		);
	} else {
		$findings[] = array(
			'key'       => '',
			'group'     => 'manual',
			'label'     => 'ID do logo',
			'current'   => $cur['ids'],
			'suggested' => '',
			'note'      => 'Nao foi possivel detetar automaticamente (o logo nao esta definido no Personalizador). Ve em Media &rarr; Biblioteca, abre o logo, e usa o numero no fim do URL.',
		);
	}


	$front = ts_perf_front_page_id();

	if ( $front ) {
		$data = ts_perf_elementor_data( $front );

		if ( $data ) {
			$hero = ts_perf_scan_hero( $data );

			if ( $hero ) {
				$findings[] = array(
					'key'       => 'hero_url',
					'group'     => 'safe',
					'label'     => 'Imagem LCP da homepage (preload)',
					'current'   => $cur['hero_url'],
					'suggested' => $hero['url'],
					'note'      => $hero['mobile']
						? 'Versao mobile do fundo do container <code>' . esc_html( $hero['id'] ) . '</code>. E a que o Lighthouse mede.'
						: 'Fundo do container <code>' . esc_html( $hero['id'] ) . '</code>. <strong>Nao existe versao mobile definida</strong> — considera criar uma (~800px de largura, &lt;60 KB) em Style &rarr; Background &rarr; Image &rarr; icone de dispositivo &rarr; Mobile.',
				);
			}

			$containers = ts_perf_scan_containers( $data );
			$safe_ids   = array();

			foreach ( $containers as $c ) {
				if ( 'safe' === $c['verdict'] ) {
					$safe_ids[] = $c['id'];
				}
			}

			$findings[] = array(
				'key'        => 'delay_containers',
				'group'      => 'test',
				'label'      => 'Containers seguros para atrasar inicializacao',
				'current'    => $cur['delay_containers'],
				'suggested'  => implode( "\n", $safe_ids ),
				'note'       => sprintf(
					'%d de %d containers classificados como seguros. Os restantes tem widgets que precisam de JavaScript e foram excluidos.',
					count( $safe_ids ),
					count( $containers )
				),
				'containers' => $containers,
			);

			$headings = array();
			foreach ( $data as $el ) {
				ts_perf_collect_headings( $el, $headings );
			}

			$footer_id = ts_perf_footer_template_id();
			if ( $footer_id ) {
				$fdata = ts_perf_elementor_data( $footer_id );
				foreach ( $fdata as $el ) {
					ts_perf_collect_headings( $el, $headings );
				}
			}

			$problems = ts_perf_check_headings( $headings );

			$findings[] = array(
				'key'       => '',
				'group'     => 'manual',
				'label'     => 'Hierarquia de titulos (H1-H6)',
				'current'   => sprintf( '%d titulos analisados%s', count( $headings ), $footer_id ? ' (pagina + rodape)' : ' (so a pagina; rodape nao encontrado)' ),
				'suggested' => '',
				'note'      => $problems
					? '<strong style="color:#b32d2e">Problemas encontrados:</strong><br>&bull; ' . implode( '<br>&bull; ', $problems )
					: '<span style="color:#00701a">Sequencia correta, sem saltos de nivel.</span>',
			);
		} else {
			$findings[] = array(
				'key'       => '',
				'group'     => 'manual',
				'label'     => 'Dados do Elementor',
				'current'   => '',
				'suggested' => '',
				'note'      => 'A homepage nao tem dados do Elementor. A analise de hero, containers e titulos foi ignorada.',
			);
		}
	} else {
		$findings[] = array(
			'key'       => '',
			'group'     => 'manual',
			'label'     => 'Pagina inicial',
			'current'   => '',
			'suggested' => '',
			'note'      => 'A pagina inicial nao esta definida como pagina estatica, por isso nao foi possivel analisar o hero nem os containers.',
		);
	}


	$fonts   = ts_perf_scan_omgf_fonts();
	$current = ts_perf_lines( 'font_preload' );
	$stale   = array();

	foreach ( $current as $url ) {
		$path = ts_perf_url_to_path( $url );
		if ( $path && ! file_exists( $path ) ) {
			$stale[] = $url;
		}
	}

	if ( $stale ) {
		$findings[] = array(
			'key'       => 'font_preload',
			'group'     => 'safe',
			'label'     => 'Preload de fontes: URLs invalidos',
			'current'   => implode( "\n", $current ),
			'suggested' => '',
			'note'      => '<strong style="color:#b32d2e">' . count( $stale ) . ' URL(s) apontam para ficheiros que ja nao existem</strong> (o OMGF muda o hash da pasta a cada reprocessamento). Isto gera erros 404 na consola e faz o site perder pontos em Praticas Recomendadas. A sugestao e <strong>esvaziar este campo</strong> e usar em vez disso a opcao <em>Load Early</em> do OMGF, que se mantem sempre correta sozinha.',
		);
	} elseif ( $fonts && ! $current ) {
		$findings[] = array(
			'key'       => '',
			'group'     => 'manual',
			'label'     => 'Preload de fontes',
			'current'   => '(vazio)',
			'suggested' => '',
			'note'      => 'Campo vazio, que e o recomendado. Ativa antes o <em>Load Early</em> no OMGF para os pesos usados &mdash; mantem-se correto automaticamente quando o hash da pasta muda. Fontes locais encontradas: ' . count( $fonts ) . '.',
		);
	}


	$print_method = get_option( 'elementor_css_print_method' );

	if ( 'internal' !== $print_method ) {
		$findings[] = array(
			'key'       => '',
			'group'     => 'manual',
			'label'     => 'Elementor: CSS Print Method',
			'current'   => $print_method ? $print_method : 'external (defeito)',
			'suggested' => 'internal',
			'note'      => 'Em Elementor &rarr; Settings &rarr; Performance, muda <strong>CSS Print Method</strong> para <strong>Internal Embedding</strong>. Elimina varios ficheiros CSS bloqueantes por pagina.',
		);
	}


	if ( $cur['critical_css'] && false !== stripos( $cur['critical_css'], '@font-face' ) ) {
		$findings[] = array(
			'key'       => '',
			'group'     => 'manual',
			'label'     => 'CSS critico contem @font-face',
			'current'   => 'presente',
			'suggested' => 'remover',
			'note'      => 'Os geradores de CSS critico incluem regras <code>@font-face</code> com URLs sem <code>?ver=</code>, que entram em conflito com as do OMGF: o browser descarrega a mesma fonte duas vezes. Liga a opcao <strong>"Remover @font-face ao guardar"</strong> e volta a guardar o CSS critico.',
		);
	}


	if ( ! $cur['clean_wp'] ) {
		$findings[] = array(
			'key'       => 'clean_wp',
			'group'     => 'safe',
			'label'     => 'Remover emojis, oEmbed e metadados',
			'current'   => 'desligado',
			'suggested' => '1',
			'note'      => 'Risco baixo. Remove JavaScript de emojis e metadados nao usados do <code>&lt;head&gt;</code>.',
		);
	}

	return $findings;
}




function ts_perf_render_scan( $blog_id ) {
	$key      = 'ts_perf_scan_' . $blog_id;
	$findings = get_site_transient( $key );
	?>
	<div style="background:#f6f7f7;border:1px solid #c3c4c7;border-left:4px solid #2271b1;padding:14px 16px;margin:16px 0">
		<h3 style="margin-top:0">Analise automatica</h3>
		<p style="max-width:60em;margin-bottom:12px">
			Le a estrutura real deste site (dados do Elementor, ficheiros do OMGF, opcoes) e sugere as definicoes, para nao teres de as descobrir a mao no DevTools. <strong>A analise so le</strong> &mdash; nada e alterado sem confirmares.
		</p>

		<p>
			<button type="submit" name="ts_perf_scan" value="<?php echo esc_attr( $blog_id ); ?>" class="button button-secondary">
				<?php echo $findings ? 'Analisar de novo' : 'Analisar este site'; ?>
			</button>
			<?php if ( $findings ) : ?>
				<span class="description" style="margin-left:8px">Resultado guardado durante 30 minutos.</span>
			<?php endif; ?>
		</p>

		<?php if ( ! is_array( $findings ) ) : ?>
			</div>
			<?php
			return;
		endif;
		?>

		<?php if ( empty( $findings ) ) : ?>
			<p><em>Nada a sugerir.</em></p></div>
			<?php
			return;
		endif;
		?>

		<table class="widefat striped" style="margin-top:14px">
			<thead>
				<tr>
					<th style="width:30px"></th>
					<th style="width:26%">Item</th>
					<th style="width:24%">Atual</th>
					<th style="width:24%">Sugerido</th>
					<th>Nota</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $findings as $i => $f ) :
				$applicable = ! empty( $f['key'] );
				$group      = isset( $f['group'] ) ? $f['group'] : 'manual';

				$badge = array(
					'safe'   => array( '#00701a', 'seguro' ),
					'test'   => array( '#996800', 'testar' ),
					'manual' => array( '#646970', 'manual' ),
				);
				list( $color, $word ) = isset( $badge[ $group ] ) ? $badge[ $group ] : $badge['manual'];
				?>
				<tr>
					<td>
						<?php if ( $applicable ) : ?>
							<input type="checkbox" name="ts_perf_apply[<?php echo esc_attr( $blog_id ); ?>][]" value="<?php echo esc_attr( $i ); ?>" <?php checked( 'safe' === $group ); ?>>
						<?php endif; ?>
					</td>
					<td>
						<strong><?php echo esc_html( $f['label'] ); ?></strong><br>
						<span style="color:<?php echo esc_attr( $color ); ?>;font-size:11px;text-transform:uppercase;letter-spacing:.4px"><?php echo esc_html( $word ); ?></span>
					</td>
					<td><code style="font-size:11px;word-break:break-all"><?php echo esc_html( ts_perf_trim( $f['current'] ) ); ?></code></td>
					<td><code style="font-size:11px;word-break:break-all"><?php echo esc_html( ts_perf_trim( $f['suggested'] ) ); ?></code></td>
					<td style="font-size:12px"><?php echo wp_kses_post( $f['note'] ); ?></td>
				</tr>

				<?php if ( ! empty( $f['containers'] ) ) : ?>
					<tr>
						<td></td>
						<td colspan="4" style="padding-top:0">
							<details>
								<summary style="cursor:pointer;font-size:12px">Ver os <?php echo count( $f['containers'] ); ?> containers analisados</summary>
								<table class="widefat" style="margin-top:8px;font-size:12px">
									<?php foreach ( $f['containers'] as $c ) :
										$c_color = 'safe' === $c['verdict'] ? '#00701a' : ( 'risky' === $c['verdict'] ? '#b32d2e' : '#996800' );
										?>
										<tr>
											<td style="width:110px"><code><?php echo esc_html( $c['id'] ); ?></code></td>
											<td style="width:80px;color:<?php echo esc_attr( $c_color ); ?>"><?php echo esc_html( strtoupper( $c['verdict'] ) ); ?></td>
											<td><?php echo esc_html( implode( ', ', $c['widgets'] ) ); ?></td>
											<td><?php echo esc_html( implode( '; ', $c['reasons'] ) ); ?></td>
										</tr>
									<?php endforeach; ?>
								</table>
							</details>
						</td>
					</tr>
				<?php endif; ?>
			<?php endforeach; ?>
			</tbody>
		</table>

		<p style="margin-top:12px">
			<button type="submit" name="ts_perf_apply_go" value="<?php echo esc_attr( $blog_id ); ?>" class="button button-primary">
				Aplicar as selecionadas
			</button>
			<span class="description" style="margin-left:8px">
				Preenche os campos. <strong>Nao liga nenhuma funcionalidade de risco</strong> (adiar CSS, adiar JS, defer) &mdash; essas continuas a ativar uma de cada vez e a testar.
			</span>
		</p>
		<p class="description" style="max-width:60em">
			A linha marcada como <span style="color:#996800;text-transform:uppercase;font-size:11px;letter-spacing:.4px">testar</span> tem efeito imediato assim que o campo for preenchido. Depois de aplicar, verifica numa janela anonima que tudo nesses containers continua a funcionar (imagens clicaveis, botoes, lightbox).
		</p>
	</div>
	<?php
}




function ts_perf_trim( $value ) {
	$value = trim( (string) $value );

	if ( '' === $value ) {
		return '(vazio)';
	}

	$value = preg_replace( '#\s+#', ' ', $value );

	if ( mb_strlen( $value ) > 90 ) {
		return mb_substr( $value, 0, 90 ) . '...';
	}

	return $value;
}




function ts_perf_apply_findings( $blog_id, $indexes ) {
	$findings = get_site_transient( 'ts_perf_scan_' . $blog_id );

	if ( ! is_array( $findings ) ) {
		return 0;
	}

	$map = ts_perf_get_map();
	$row = isset( $map[ $blog_id ] ) && is_array( $map[ $blog_id ] )
		? array_merge( ts_perf_defaults(), $map[ $blog_id ] )
		: ts_perf_defaults();

	$applied = 0;

	foreach ( (array) $indexes as $i ) {
		$i = (int) $i;

		if ( ! isset( $findings[ $i ] ) || empty( $findings[ $i ]['key'] ) ) {
			continue;
		}

		$f   = $findings[ $i ];
		$key = $f['key'];

		if ( ! array_key_exists( $key, $row ) ) {
			continue;
		}


		if ( (string) $row[ $key ] === (string) $f['suggested'] ) {
			continue;
		}

		$row[ $key ] = $f['suggested'];
		$applied++;
	}

	if ( $applied ) {
		$map[ $blog_id ] = $row;
		ts_perf_save_map( $map );
		delete_site_transient( 'ts_perf_scan_' . $blog_id );
	}

	return $applied;
}





add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || false === strpos( (string) $screen->id, 'navia-suite' ) || false !== strpos( (string) $screen->id, 'ts-performance' ) ) {
		return;
	}

	if ( ! empty( ts_perf_get( 'ids' ) ) ) {
		return;
	}

	$link = admin_url( 'admin.php?page=ts-performance-site' );

	echo '<div class="notice notice-warning is-dismissible"><p><strong>Navia Performance:</strong> este site ainda nao tem o ID do logo definido. <a href="' . esc_url( $link ) . '">Definir agora</a>. A protecao generica (2 primeiras imagens sem lazy-load) ja esta ativa.</p></div>';
} );






function ts_perf_uninstall() {
	if ( is_multisite() ) {
		delete_site_option( TS_PERF_OPTION );
		delete_site_option( TS_PERF_LEGACY_OPTION );
	} else {
		delete_option( TS_PERF_OPTION );
		delete_option( TS_PERF_LEGACY_OPTION );
	}
}
