<?php









defined( 'ABSPATH' ) || exit;

class NAS_Cookies {

	const OPTION = 'cookie_notice_options';

	public static function init(): void {
		add_action( 'admin_post_nas_cookies_save', array( __CLASS__, 'handle_save' ) );
		if ( ! is_admin() ) {
			add_filter( 'option_' . self::OPTION, array( __CLASS__, 'localise' ) );
		}
	}

	public static function available(): bool {
		return NAS_Env::active( 'cookie_notice' );
	}

	public static function default_texts( string $lang ): array {
		if ( 'pt' === substr( $lang, 0, 2 ) ) {
			return array(
				'message' => 'Usamos cookies para o site funcionar e, com a sua autorização, para medir visitas. Pode aceitar ou recusar.',
				'accept'  => 'Aceitar',
				'refuse'  => 'Recusar',
				'more'    => 'Política de privacidade',
				'revoke'  => 'Alterar preferências de cookies',
			);
		}
		return array(
			'message' => 'We use cookies to make the site work and, with your consent, to measure visits. You can accept or refuse.',
			'accept'  => 'Accept',
			'refuse'  => 'Refuse',
			'more'    => 'Privacy policy',
			'revoke'  => 'Change cookie preferences',
		);
	}

	public static function languages(): array {
		return function_exists( 'pll_languages_list' ) ? (array) pll_languages_list( array( 'fields' => 'slug' ) ) : array( substr( get_locale(), 0, 2 ) );
	}

	public static function texts( string $lang ): array {
		$saved = (array) ( NAS_Settings::get( 'cookies' )['texts'][ $lang ] ?? array() );
		return array_merge( self::default_texts( $lang ), array_filter( $saved ) );
	}


	public static function colours(): array {
		$s = NAS_Settings::get( 'cookies' );
		if ( 'custom' === ( $s['colors'] ?? 'kit' ) && $s['bar'] ) {
			return array( 'bar' => $s['bar'], 'text' => $s['text'] ? $s['text'] : '#ffffff', 'button' => $s['button'] ? $s['button'] : '#ffffff' );
		}
		$kit    = self::kit_colours();
		$bar    = $kit['text'] ?? ( $kit['primary'] ?? '#1f2933' );
		$button = $kit['accent'] ?? '#ffffff';
		return array( 'bar' => $bar, 'text' => '#ffffff', 'button' => $button );
	}

	public static function kit_colours(): array {
		$kit = (int) get_option( 'elementor_active_kit' );
		$out = array();
		if ( ! $kit ) {
			return $out;
		}
		$s = get_post_meta( $kit, '_elementor_page_settings', true );
		foreach ( (array) ( $s['system_colors'] ?? array() ) as $c ) {
			if ( ! empty( $c['_id'] ) && ! empty( $c['color'] ) ) {
				$out[ $c['_id'] ] = $c['color'];
			}
		}
		return $out;
	}

	public static function privacy_page( string $lang ): int {
		$id = (int) get_option( 'wp_page_for_privacy_policy' );
		if ( $id && function_exists( 'pll_get_post' ) ) {
			$tr = pll_get_post( $id, $lang );
			$id = $tr ? (int) $tr : $id;
		}
		return $id;
	}




	public static function apply(): array {
		$o      = get_option( self::OPTION, array() );
		$o      = is_array( $o ) ? $o : array();
		$lang   = function_exists( 'pll_default_language' ) ? (string) pll_default_language() : substr( get_locale(), 0, 2 );
		$t      = self::texts( $lang );
		$c      = self::colours();
		$page   = self::privacy_page( $lang );
		$colors = array_merge( (array) ( $o['colors'] ?? array() ), array( 'text' => $c['text'], 'bar' => $c['bar'], 'button' => $c['button'], 'bar_opacity' => 100 ) );

		$o = array_merge(
			$o,
			array(
				'position'            => 'bottom',
				'message_text'        => $t['message'],
				'accept_text'         => $t['accept'],
				'refuse_text'         => $t['refuse'],
				'refuse_opt'          => true,
				'revoke_cookies'      => true,
				'revoke_cookies_opt'  => 'automatic',
				'revoke_message_text' => $t['revoke'],
				'revoke_text'         => $t['revoke'],
				'see_more'            => (bool) $page,
				'link_target'         => '_self',
				'link_position'       => 'banner',
				'time'                => 'month',
				'time_rejected'       => 'month',
				'hide_effect'         => 'fade',
				'on_scroll'           => false,
				'colors'              => $colors,
			)
		);
		$o['see_more_opt'] = array_merge(
			(array) ( $o['see_more_opt'] ?? array() ),
			array(
				'text'      => $t['more'],
				'link_type' => 'page',
				'id'        => $page,
				'sync'      => true,
			)
		);
		update_option( self::OPTION, $o );
		NAS_Updater::record( 'cookies', 'Cookie Notice configured (' . implode( ', ', self::languages() ) . ')' );
		NAS_Cache::after_change( 0 );
		return array(
			'languages' => self::languages(),
			'colours'   => $c,
			'privacy'   => $page,
		);
	}


	public static function localise( $value ) {
		if ( ! is_array( $value ) || ! function_exists( 'pll_current_language' ) ) {
			return $value;
		}
		$lang = (string) pll_current_language();
		if ( ! $lang ) {
			return $value;
		}
		$saved = NAS_Settings::get( 'cookies' )['texts'] ?? array();
		if ( empty( $saved ) && $lang === (string) pll_default_language() ) {
			return $value;
		}
		$t                            = self::texts( $lang );
		$value['message_text']        = $t['message'];
		$value['accept_text']         = $t['accept'];
		$value['refuse_text']         = $t['refuse'];
		$value['revoke_message_text'] = $t['revoke'];
		$value['revoke_text']         = $t['revoke'];
		if ( isset( $value['see_more_opt'] ) && is_array( $value['see_more_opt'] ) ) {
			$value['see_more_opt']['text'] = $t['more'];
			$page                          = self::privacy_page( $lang );
			if ( $page ) {
				$value['see_more_opt']['id']   = $page;
				$value['see_more_opt']['link'] = get_permalink( $page );
			}
		}
		return $value;
	}




	public static function save_texts( array $texts ): void {
		$s          = NAS_Settings::get( 'cookies' );
		$s['texts'] = array();
		foreach ( $texts as $lang => $row ) {
			$lang = sanitize_key( $lang );
			foreach ( array( 'message', 'accept', 'refuse', 'more', 'revoke' ) as $k ) {
				$s['texts'][ $lang ][ $k ] = sanitize_text_field( (string) ( $row[ $k ] ?? '' ) );
			}
		}
		NAS_Settings::save_site( array( 'cookies' => $s ) );
	}

	public static function render_tab(): void {
		$s = NAS_Settings::get( 'cookies' );
		$c = self::colours();
		?>
		<div class="nas-card">
			<h2>Cookie bar (Cookie Notice)</h2>
			<?php if ( ! self::available() ) : ?>
				<p>Cookie Notice is not active.</p>
			<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="nas_cookies_save">
				<?php wp_nonce_field( 'nas_cookies_save' ); ?>
				<?php foreach ( self::languages() as $lang ) : $t = self::texts( $lang ); ?>
					<h3><?php echo esc_html( strtoupper( $lang ) ); ?></h3>
					<table class="form-table" role="presentation">
						<tr><th>Message</th><td><textarea class="large-text" rows="2" name="texts[<?php echo esc_attr( $lang ); ?>][message]"><?php echo esc_textarea( $t['message'] ); ?></textarea></td></tr>
						<tr><th>Buttons</th><td><input type="text" name="texts[<?php echo esc_attr( $lang ); ?>][accept]" value="<?php echo esc_attr( $t['accept'] ); ?>"> <input type="text" name="texts[<?php echo esc_attr( $lang ); ?>][refuse]" value="<?php echo esc_attr( $t['refuse'] ); ?>"></td></tr>
						<tr><th>Privacy link text</th><td><input type="text" class="regular-text" name="texts[<?php echo esc_attr( $lang ); ?>][more]" value="<?php echo esc_attr( $t['more'] ); ?>"> <span class="description">Page: <?php $pid = self::privacy_page( $lang ); echo $pid ? esc_html( get_the_title( $pid ) ) : 'none set in Settings &gt; Privacy'; ?></span></td></tr>
						<tr><th>Revoke text</th><td><input type="text" class="regular-text" name="texts[<?php echo esc_attr( $lang ); ?>][revoke]" value="<?php echo esc_attr( $t['revoke'] ); ?>"></td></tr>
					</table>
				<?php endforeach; ?>
				<h3>Colours</h3>
				<p><label><input type="radio" name="colors" value="kit" <?php checked( $s['colors'], 'kit' ); ?>> From the Elementor kit (bar <code><?php echo esc_html( $c['bar'] ); ?></code>, button <code><?php echo esc_html( $c['button'] ); ?></code>)</label><br>
				<label><input type="radio" name="colors" value="custom" <?php checked( $s['colors'], 'custom' ); ?>> Custom: bar <input type="color" name="bar" value="<?php echo esc_attr( $s['bar'] ? $s['bar'] : '#1f2933' ); ?>"> text <input type="color" name="text" value="<?php echo esc_attr( $s['text'] ? $s['text'] : '#ffffff' ); ?>"> button <input type="color" name="button" value="<?php echo esc_attr( $s['button'] ? $s['button'] : '#ffffff' ); ?>"></label></p>
				<p class="description">Check the contrast of the button text in the PageSpeed accessibility audit.</p>
				<?php submit_button( 'Save and apply to Cookie Notice' ); ?>
			</form>
			<p class="description">Scripts that need consent (Google Tag Manager, Analytics, Meta pixel) go in Cookie Notice &gt; Script blocking, not in the theme. The Performance module still delays them until the first interaction.</p>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_cookies_save' );
		self::save_texts( isset( $_POST['texts'] ) && is_array( $_POST['texts'] ) ? wp_unslash( $_POST['texts'] ) : array() );
		$s           = NAS_Settings::get( 'cookies' );
		$s['colors'] = 'custom' === ( $_POST['colors'] ?? '' ) ? 'custom' : 'kit';
		foreach ( array( 'bar', 'text', 'button' ) as $k ) {
			$s[ $k ] = sanitize_hex_color( wp_unslash( $_POST[ $k ] ?? '' ) ) ?: '';
		}
		NAS_Settings::save_site( array( 'cookies' => $s ) );
		self::apply();
		NAS_Admin::notice_flash( 'Cookie Notice configured.' );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=cookies' ) );
		exit;
	}
}

NAS_Cookies::init();
