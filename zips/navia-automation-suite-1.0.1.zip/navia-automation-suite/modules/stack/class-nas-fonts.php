<?php














defined( 'ABSPATH' ) || exit;

class NAS_Fonts {

	const MAX_PRELOAD = 4;

	public static function init(): void {
		add_action( 'admin_post_nas_fonts_apply', array( __CLASS__, 'handle_apply' ) );
		add_action( 'admin_post_nas_fonts_warm', array( __CLASS__, 'handle_warm' ) );
	}

	public static function available(): bool {
		return NAS_Env::active( 'omgf' );
	}






	public static function used(): array {
		$used = array();
		$add  = static function ( string $family, $weight, string $style, string $where ) use ( &$used ) {
			$family = trim( $family );
			if ( '' === $family || 0 === strpos( $family, 'var(' ) ) {
				return;
			}
			$w = (string) $weight;
			$w = ( '' === $w || 'normal' === $w ) ? '400' : ( 'bold' === $w ? '700' : $w );
			if ( ! ctype_digit( $w ) ) {
				$w = '400';
			}
			$key = strtolower( $family );
			if ( ! isset( $used[ $key ] ) ) {
				$used[ $key ] = array( 'family' => $family, 'weights' => array(), 'italic' => false, 'where' => array() );
			}
			$used[ $key ]['weights'][ $w ] = true;
			if ( 'italic' === $style ) {
				$used[ $key ]['italic'] = true;
			}
			$used[ $key ]['where'][ $where ] = true;
		};


		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit ) {
			$s = get_post_meta( $kit, '_elementor_page_settings', true );
			if ( is_array( $s ) ) {
				foreach ( array( 'system_typography', 'custom_typography' ) as $group ) {
					foreach ( (array) ( $s[ $group ] ?? array() ) as $t ) {
						if ( ! empty( $t['typography_font_family'] ) ) {
							$add( (string) $t['typography_font_family'], $t['typography_font_weight'] ?? '', (string) ( $t['typography_font_style'] ?? '' ), 'global ' . ( $t['title'] ?? $t['_id'] ?? '' ) );
						}
					}
				}
				self::scan_settings( $s, $add, 'theme style' );



				$text_family = (string) ( $s['body_typography_font_family'] ?? '' );
				foreach ( (array) ( $s['system_typography'] ?? array() ) as $t ) {
					if ( 'text' === ( $t['_id'] ?? '' ) && ! empty( $t['typography_font_family'] ) ) {
						$text_family = (string) $t['typography_font_family'];
					}
				}
				if ( $text_family ) {
					$add( $text_family, '700', '', 'bold text in content' );
				}
			}
		}


		$ids = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'fields'         => 'ids',
				'meta_key'       => '_elementor_edit_mode',
				'meta_value'     => 'builder',
				'no_found_rows'  => true,
			)
		);
		$extra = get_posts( array( 'post_type' => array( 'chf_template', 'elementor_library' ), 'post_status' => 'publish', 'posts_per_page' => 200, 'fields' => 'ids', 'no_found_rows' => true ) );
		foreach ( array_unique( array_merge( $ids, $extra ) ) as $id ) {
			$data = get_post_meta( $id, '_elementor_data', true );
			$data = is_string( $data ) ? json_decode( $data, true ) : $data;
			if ( is_array( $data ) ) {
				self::walk( $data, $add, get_the_title( $id ) );
			}
		}

		foreach ( $used as &$u ) {

			$u['weights'] = array_map( 'strval', array_keys( $u['weights'] ) );
			sort( $u['weights'] );
			$u['where'] = array_slice( array_keys( $u['where'] ), 0, 8 );
		}
		return $used;
	}

	private static function walk( array $elements, callable $add, string $where ): void {
		foreach ( $elements as $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( ! empty( $el['settings'] ) && is_array( $el['settings'] ) ) {
				self::scan_settings( $el['settings'], $add, $where );
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				self::walk( $el['elements'], $add, $where );
			}
		}
	}


	private static function scan_settings( array $s, callable $add, string $where ): void {
		foreach ( $s as $k => $v ) {
			if ( ! is_string( $k ) || ! is_string( $v ) || '' === $v ) {
				continue;
			}
			if ( preg_match( '/^(.*)_font_family$/', $k, $m ) ) {
				$p = $m[1];
				$weights = array( $s[ $p . '_font_weight' ] ?? '' );
				foreach ( array( '_tablet', '_mobile' ) as $bp ) {
					if ( ! empty( $s[ $p . '_font_weight' . $bp ] ) ) {
						$weights[] = $s[ $p . '_font_weight' . $bp ];
					}
				}
				foreach ( $weights as $w ) {
					$add( $v, $w, (string) ( $s[ $p . '_font_style' ] ?? '' ), $where );
				}
			}
		}
	}



	public static function omgf_fonts(): array {
		$f = get_option( 'omgf_optimized_fonts', array() );
		if ( is_string( $f ) ) {
			$f = maybe_unserialize( $f );
		}
		return is_array( $f ) ? $f : array();
	}

	private static function prop( $obj, string $key ) {
		if ( is_object( $obj ) ) {
			return $obj->$key ?? null;
		}
		return is_array( $obj ) ? ( $obj[ $key ] ?? null ) : null;
	}






	public static function plan(): array {
		if ( ! self::available() ) {
			return array( 'status' => 'omgf_inactive', 'used' => array(), 'handles' => array(), 'keep' => 0, 'unload' => 0, 'preload' => array() );
		}
		$used  = self::used();
		$fonts = self::omgf_fonts();
		if ( ! $fonts ) {
			return array( 'status' => 'nothing_detected', 'used' => $used, 'handles' => array(), 'keep' => 0, 'unload' => 0, 'preload' => array() );
		}

		$handles = array();
		$keep    = 0;
		$unload  = 0;
		$preload_candidates = array();
		foreach ( $fonts as $handle => $list ) {
			foreach ( (array) $list as $font ) {
				$fid    = (string) self::prop( $font, 'id' );
				$family = (string) self::prop( $font, 'family' );
				$u      = $used[ strtolower( $family ) ] ?? null;
				foreach ( (array) self::prop( $font, 'variants' ) as $variant ) {
					$vid    = (string) self::prop( $variant, 'id' );
					$weight = (string) self::prop( $variant, 'fontWeight' );
					$style  = (string) self::prop( $variant, 'fontStyle' );
					$weight = $weight ? $weight : ( preg_match( '/^(\d{3})/', $vid, $mm ) ? $mm[1] : '400' );
					$is_it  = 'italic' === $style || false !== strpos( $vid, 'italic' );
					$wanted = $u && ( in_array( $weight, $u['weights'], true ) || self::is_variable( $weight ) ) && ( ! $is_it || $u['italic'] );
					$handles[ $handle ][ $fid ]['family']          = $family;
					$handles[ $handle ][ $fid ]['variants'][ $vid ] = array(
						'weight' => $weight,
						'style'  => $is_it ? 'italic' : 'normal',
						'keep'   => $wanted,
					);
					if ( $wanted ) {
						++$keep;
						if ( ! $is_it ) {
							$preload_candidates[] = array( $handle, $fid, $vid, $family, $weight );
						}
					} else {
						++$unload;
					}
				}
			}
		}



		usort(
			$preload_candidates,
			static function ( $a, $b ) {
				return ( '400' === $b[4] ) <=> ( '400' === $a[4] );
			}
		);
		$first = array();
		$rest  = array();
		foreach ( $preload_candidates as $cand ) {
			if ( isset( $first[ $cand[3] ] ) ) {
				$rest[] = $cand;
			} else {
				$first[ $cand[3] ] = $cand;
			}
		}
		$preload = array_slice( array_merge( array_values( $first ), $rest ), 0, self::MAX_PRELOAD );

		return array(
			'status'  => 'ok',
			'used'    => $used,
			'handles' => $handles,
			'keep'    => $keep,
			'unload'  => $unload,
			'preload' => array_map(
				static function ( $p ) {
					return array( 'handle' => $p[0], 'font' => $p[1], 'variant' => $p[2], 'family' => $p[3], 'weight' => $p[4] );
				},
				$preload
			),
		);
	}

	private static function is_variable( string $weight ): bool {
		return false !== strpos( $weight, ' ' );
	}





	public static function apply( bool $preload = true ): array {
		$plan = self::plan();
		if ( 'ok' !== $plan['status'] ) {
			return $plan;
		}
		$unload_opt  = get_option( 'omgf_unload_fonts', array() );
		$unload_opt  = is_array( $unload_opt ) ? $unload_opt : array();
		$preload_opt = array();
		$changed     = array();

		foreach ( $plan['handles'] as $handle => $fonts ) {
			$unload_opt[ $handle ] = array();
			foreach ( $fonts as $fid => $f ) {
				foreach ( $f['variants'] as $vid => $v ) {
					if ( ! $v['keep'] ) {
						$unload_opt[ $handle ][ $fid ][ $vid ] = $vid;
					}
				}
			}
			$changed[] = $handle;
		}
		if ( $preload ) {
			foreach ( $plan['preload'] as $p ) {
				$preload_opt[ $p['handle'] ][ $p['font'] ][ $p['variant'] ] = $p['variant'];
			}
		}

		update_option( 'omgf_unload_fonts', $unload_opt, false );
		update_option( 'omgf_preload_fonts', $preload_opt );

		$settings = get_option( 'omgf_settings', array() );
		$settings = is_array( $settings ) ? $settings : array();
		$keys     = array_filter( explode( ',', (string) ( $settings['cache_keys'] ?? '' ) ) );
		if ( ! $keys ) {
			$keys = array_keys( self::omgf_fonts() );
		}
		foreach ( $keys as $i => $key ) {
			foreach ( $changed as $handle ) {
				$base = preg_replace( '/-mod-[a-z0-9]+$/', '', $key );
				if ( $base === $handle ) {
					$keys[ $i ] = $handle . '-mod-' . strtolower( wp_generate_password( 5, false, false ) );
				}
			}
		}
		$settings['cache_keys']     = implode( ',', $keys );
		$settings['subsets']        = array( 'latin' );
		$settings['display_option'] = 'swap';
		update_option( 'omgf_settings', $settings );
		update_option( 'omgf_cache_is_stale', true );

		NAS_Updater::record( 'fonts', sprintf( 'OMGF plan applied: %d kept, %d unloaded, %d preloaded', $plan['keep'], $plan['unload'], count( $plan['preload'] ) ) );
		NAS_Cache::purge( 0 );
		self::warm();
		$plan['applied'] = true;
		$plan['next']    = 'Open the homepage two or three times in a private window before measuring: OMGF builds the new stylesheets on the first visits.';
		return $plan;
	}


	public static function warm(): void {
		for ( $i = 0; $i < 2; $i++ ) {
			wp_remote_get( add_query_arg( 'nas_warm', wp_rand( 1, 99999 ), home_url( '/' ) ), array( 'timeout' => 15, 'blocking' => 0 === $i, 'sslverify' => false ) );
		}
	}



	public static function render_tab(): void {
		$plan = self::plan();
		?>
		<div class="nas-card">
			<h2>Fonts in use (OMGF)</h2>
			<?php if ( 'omgf_inactive' === $plan['status'] ) : ?>
				<p>OMGF is not active.</p>
			<?php else : ?>
				<h3>What the Elementor site uses</h3>
				<?php if ( ! $plan['used'] ) : ?>
					<p>No font family found in the kit or the pages.</p>
				<?php else : ?>
					<table class="widefat striped" style="max-width:900px"><thead><tr><th>Family</th><th>Weights</th><th>Where (sample)</th></tr></thead><tbody>
					<?php foreach ( $plan['used'] as $u ) : ?>
						<tr><td><strong><?php echo esc_html( $u['family'] ); ?></strong></td><td><?php echo esc_html( implode( ', ', $u['weights'] ) . ( $u['italic'] ? ' + italic' : '' ) ); ?></td><td class="nas-muted"><?php echo esc_html( implode( ', ', $u['where'] ) ); ?></td></tr>
					<?php endforeach; ?>
					</tbody></table>
				<?php endif; ?>

				<?php if ( 'nothing_detected' === $plan['status'] ) : ?>
					<p><strong>OMGF has not detected any font yet.</strong> Go to Settings &gt; Optimize Google Fonts, click Save &amp; Optimize, then use the button below (or open the homepage in a private window) and come back.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="nas_fonts_warm"><?php wp_nonce_field( 'nas_fonts_warm' ); ?><button class="button">Visit the homepage now</button></form>
				<?php else : ?>
					<h3>Plan for OMGF</h3>
					<p><?php echo (int) $plan['keep']; ?> file(s) kept, <?php echo (int) $plan['unload']; ?> unloaded. Preload: <?php echo esc_html( implode( ', ', array_map( static fn( $p ) => $p['family'] . ' ' . $p['weight'], $plan['preload'] ) ) ); ?>.</p>
					<table class="widefat striped" style="max-width:900px"><thead><tr><th>Stylesheet</th><th>Family</th><th>Kept</th><th>Unloaded</th></tr></thead><tbody>
					<?php foreach ( $plan['handles'] as $h => $fonts ) : foreach ( $fonts as $f ) : $k = array(); $x = array(); foreach ( $f['variants'] as $vid => $v ) { if ( $v['keep'] ) { $k[] = $vid; } else { $x[] = $vid; } } ?>
						<tr><td><code><?php echo esc_html( $h ); ?></code></td><td><?php echo esc_html( $f['family'] ); ?></td><td><?php echo esc_html( implode( ', ', $k ) ); ?></td><td class="nas-muted"><?php echo esc_html( implode( ', ', $x ) ); ?></td></tr>
					<?php endforeach; endforeach; ?>
					</tbody></table>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
						<input type="hidden" name="action" value="nas_fonts_apply">
						<?php wp_nonce_field( 'nas_fonts_apply' ); ?>
						<label><input type="checkbox" name="preload" value="1" checked> Preload the kept regular weights (Load Early, up to <?php echo (int) self::MAX_PRELOAD; ?> files)</label><br><br>
						<button class="button button-primary">Apply to OMGF</button>
						<span class="description">Also sets latin only and font-display swap, clears the caches and visits the homepage.</span>
					</form>
					<p class="description">A font loaded by something outside Elementor (a plugin, a custom CSS) is not seen here. After applying, check the pages; OMGF &gt; Local Fonts can undo any unload.</p>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_apply(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_fonts_apply' );
		$r = self::apply( ! empty( $_POST['preload'] ) );
		NAS_Admin::notice_flash( ! empty( $r['applied'] ) ? sprintf( 'OMGF updated: %d kept, %d unloaded. %s', $r['keep'], $r['unload'], $r['next'] ) : 'Nothing applied (' . esc_html( $r['status'] ) . ').' );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=fonts' ) );
		exit;
	}

	public static function handle_warm(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_fonts_warm' );
		self::warm();
		NAS_Admin::notice_flash( 'Homepage visited. If OMGF still shows nothing, run Save & Optimize in OMGF first.' );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=fonts' ) );
		exit;
	}
}

NAS_Fonts::init();
