<?php












defined( 'ABSPATH' ) || exit;

class NAS_Forms {

	const CSS_HANDLE = 'contact-form-7';

	public static function init(): void {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'styles' ), 30 );
		add_action( 'admin_post_nas_forms_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_nas_forms_create', array( __CLASS__, 'handle_create' ) );
	}

	public static function available(): bool {
		return class_exists( 'WPCF7_ContactForm' );
	}






	public static function texts( string $lang ): array {
		$pt = array(
			'name'        => 'Nome',
			'email'       => 'Email',
			'phone'       => 'Telefone ou WhatsApp',
			'service'     => 'Serviço',
			'area'        => 'Zona',
			'message'     => 'Mensagem',
			'message_ph'  => 'Conte-nos o que precisa. Fotografias ajudam: pode enviá-las depois por WhatsApp.',
			'consent'     => 'Li e aceito a [privacy]política de privacidade[/privacy].',
			'submit'      => 'Enviar pedido',
			'choose'      => 'Escolha uma opção',
			'subject'     => 'Novo pedido de [your-name] em [_site_title]',
			'mail_intro'  => 'Novo pedido recebido pelo site.',
			'mail_page'   => 'Página',
			'mail_date'   => 'Data',
			'messages'    => array(
				'mail_sent_ok'             => 'Obrigado. Recebemos o seu pedido e respondemos em breve.',
				'mail_sent_ng'             => 'Não foi possível enviar a mensagem. Tente outra vez ou contacte-nos por telefone.',
				'validation_error'         => 'Há campos por preencher ou com erros. Verifique e envie outra vez.',
				'spam'                     => 'Não foi possível enviar a mensagem. Tente outra vez mais tarde.',
				'accept_terms'             => 'Para enviar, aceite a política de privacidade.',
				'invalid_required'         => 'Preencha este campo.',
				'invalid_too_long'         => 'Este texto é demasiado longo.',
				'invalid_too_short'        => 'Este texto é demasiado curto.',
				'upload_failed'            => 'Não foi possível carregar o ficheiro.',
				'invalid_email'            => 'Indique um email válido.',
				'invalid_tel'              => 'Indique um número de telefone válido.',
			),
		);
		$en = array(
			'name'        => 'Name',
			'email'       => 'Email',
			'phone'       => 'Phone or WhatsApp',
			'service'     => 'Service',
			'area'        => 'Area',
			'message'     => 'Message',
			'message_ph'  => 'Tell us what you need. Photos help: you can send them later on WhatsApp.',
			'consent'     => 'I have read and accept the [privacy]privacy policy[/privacy].',
			'submit'      => 'Send request',
			'choose'      => 'Choose an option',
			'subject'     => 'New request from [your-name] on [_site_title]',
			'mail_intro'  => 'New request received through the website.',
			'mail_page'   => 'Page',
			'mail_date'   => 'Date',
			'messages'    => array(
				'mail_sent_ok'      => 'Thank you. We received your request and will reply soon.',
				'mail_sent_ng'      => 'The message could not be sent. Please try again or call us.',
				'validation_error'  => 'Some fields are missing or wrong. Please check and send again.',
				'spam'              => 'The message could not be sent. Please try again later.',
				'accept_terms'      => 'Please accept the privacy policy to send.',
				'invalid_required'  => 'Please fill in this field.',
				'invalid_too_long'  => 'This text is too long.',
				'invalid_too_short' => 'This text is too short.',
				'upload_failed'     => 'The file could not be uploaded.',
				'invalid_email'     => 'Please enter a valid email.',
				'invalid_tel'       => 'Please enter a valid phone number.',
			),
		);
		$lang = strtolower( substr( $lang, 0, 2 ) );
		return 'pt' === $lang ? $pt : $en;
	}








	public static function template( array $a ): string {
		$t   = self::texts( $a['lang'] );
		$opt = static function ( array $list, string $choose ): string {
			$items = array_map(
				static function ( $v ) {
					return '"' . str_replace( '"', '', wp_strip_all_tags( (string) $v ) ) . '"';
				},
				array_values( array_filter( $list ) )
			);
			return 'first_as_label "' . $choose . '" ' . implode( ' ', $items );
		};
		$privacy = $a['privacy_url'] ? '<a href="' . esc_url( $a['privacy_url'] ) . '" target="_blank" rel="noopener">' : '';
		$consent = $privacy ? str_replace( array( '[privacy]', '[/privacy]' ), array( $privacy, '</a>' ), $t['consent'] ) : str_replace( array( '[privacy]', '[/privacy]' ), '', $t['consent'] );
		$phone   = ! empty( $a['phone_required'] ) ? 'tel*' : 'tel';

		$f  = '<div class="nas-form__grid">' . "\n";
		$f .= '<p class="nas-form__field"><label>' . $t['name'] . "\n" . '[text* your-name autocomplete:name]</label></p>' . "\n";
		$f .= '<p class="nas-form__field"><label>' . $t['email'] . "\n" . '[email* your-email autocomplete:email]</label></p>' . "\n";
		$f .= '<p class="nas-form__field"><label>' . $t['phone'] . "\n" . '[' . $phone . ' your-phone autocomplete:tel]</label></p>' . "\n";
		if ( ! empty( $a['services'] ) ) {
			$f .= '<p class="nas-form__field"><label>' . $t['service'] . "\n" . '[select* your-service ' . $opt( (array) $a['services'], $t['choose'] ) . ']</label></p>' . "\n";
		}
		if ( ! empty( $a['areas'] ) ) {
			$f .= '<p class="nas-form__field"><label>' . $t['area'] . "\n" . '[select* your-area ' . $opt( (array) $a['areas'], $t['choose'] ) . ']</label></p>' . "\n";
		}
		$f .= '<p class="nas-form__field nas-form__field--full"><label>' . $t['message'] . "\n" . '[textarea* your-message x4 placeholder "' . $t['message_ph'] . '"]</label></p>' . "\n";
		$f .= '<p class="nas-form__field nas-form__field--full nas-form__consent">[acceptance your-consent] ' . $consent . ' [/acceptance]</p>' . "\n";
		$f .= '<p class="nas-form__field nas-form__field--full">[submit "' . $t['submit'] . '"]</p>' . "\n";
		$f .= '</div>';
		return $f;
	}

	public static function mail_body( array $a ): string {
		$t     = self::texts( $a['lang'] );
		$lines = array(
			$t['mail_intro'],
			'',
			$t['name'] . ': [your-name]',
			$t['email'] . ': [your-email]',
			$t['phone'] . ': [your-phone]',
		);
		if ( ! empty( $a['services'] ) ) {
			$lines[] = $t['service'] . ': [your-service]';
		}
		if ( ! empty( $a['areas'] ) ) {
			$lines[] = $t['area'] . ': [your-area]';
		}
		$lines[] = '';
		$lines[] = $t['message'] . ':';
		$lines[] = '[your-message]';
		$lines[] = '';
		$lines[] = '--';
		$lines[] = $t['mail_page'] . ': [_url]';
		$lines[] = $t['mail_date'] . ': [_date] [_time]';
		return implode( "\n", $lines );
	}


	public static function sender_email(): string {
		$o = get_option( 'postman_options', array() );
		if ( is_array( $o ) && ! empty( $o['sender_email'] ) && is_email( $o['sender_email'] ) ) {
			return $o['sender_email'];
		}
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$host = preg_replace( '/^www\./', '', $host );
		return 'wordpress@' . $host;
	}







	public static function setup( array $a ) {
		if ( ! self::available() ) {
			return new WP_Error( 'nas_no_cf7', 'Contact Form 7 is not active on this site.' );
		}
		$a = wp_parse_args(
			$a,
			array(
				'lang'           => function_exists( 'pll_default_language' ) ? (string) pll_default_language() : substr( get_locale(), 0, 2 ),
				'title'          => '',
				'recipient'      => '',
				'services'       => array(),
				'areas'          => array(),
				'privacy_url'    => '',
				'phone_required' => false,
				'form_id'        => 0,
			)
		);
		$a['lang'] = sanitize_key( $a['lang'] );
		if ( ! is_email( $a['recipient'] ) ) {
			return new WP_Error( 'nas_bad_recipient', 'recipient must be the client email address that receives the leads.' );
		}
		if ( ! $a['privacy_url'] ) {
			$a['privacy_url'] = self::privacy_url( $a['lang'] );
		}
		$t = self::texts( $a['lang'] );

		$saved   = (array) ( NAS_Settings::get( 'forms' )['forms'] ?? array() );
		$form_id = (int) ( $a['form_id'] ? $a['form_id'] : ( $saved[ $a['lang'] ] ?? 0 ) );
		$form    = $form_id ? wpcf7_contact_form( $form_id ) : null;
		$updated = (bool) $form;
		if ( ! $form ) {
			$form = WPCF7_ContactForm::get_template( array( 'locale' => 'pt' === $a['lang'] ? 'pt_PT' : 'en_GB' ) );
		}
		$title = $a['title'] ? $a['title'] : get_bloginfo( 'name' ) . ' lead form (' . strtoupper( $a['lang'] ) . ')';
		$form->set_title( $title );

		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$props          = $form->get_properties();
		$props['form']  = self::template( $a );
		$props['mail']  = array_merge(
			(array) ( $props['mail'] ?? array() ),
			array(
				'active'             => true,
				'subject'            => $t['subject'],
				'sender'             => '"' . str_replace( '"', '', $site_name ) . '" <' . self::sender_email() . '>',
				'recipient'          => $a['recipient'],
				'body'               => self::mail_body( $a ),
				'additional_headers' => 'Reply-To: "[your-name]" <[your-email]>',
				'attachments'        => '',
				'use_html'           => false,
				'exclude_blank'      => true,
			)
		);
		$props['mail_2']           = array_merge( (array) ( $props['mail_2'] ?? array() ), array( 'active' => false ) );
		$props['messages']         = array_merge( (array) ( $props['messages'] ?? array() ), $t['messages'] );
		$form->set_properties( $props );
		$id = $form->save();
		if ( ! $id ) {
			return new WP_Error( 'nas_cf7_save', 'Contact Form 7 did not save the form.' );
		}
		$forms                  = NAS_Settings::get( 'forms' );
		$forms['forms']         = $saved;
		$forms['forms'][ $a['lang'] ] = (int) $id;
		NAS_Settings::save_site( array( 'forms' => $forms ) );

		$shortcode = sprintf( '[contact-form-7 id="%d" title="%s" html_class="nas-form"]', (int) $id, esc_attr( $title ) );
		NAS_Updater::record( 'forms', ( $updated ? 'Updated' : 'Created' ) . ' CF7 form ' . $id . ' (' . $a['lang'] . ') for ' . $a['recipient'] );
		NAS_Cache::after_change( 0 );

		return array(
			'id'        => (int) $id,
			'title'     => $title,
			'lang'      => $a['lang'],
			'shortcode' => $shortcode,
			'updated'   => $updated,
			'sender'    => self::sender_email(),
			'note'      => 'Put the shortcode in an Elementor Shortcode widget. The form takes the Elementor global colours and fonts; on a dark section set the Suite form style to dark.',
		);
	}

	public static function privacy_url( string $lang ): string {
		$id = (int) get_option( 'wp_page_for_privacy_policy' );
		if ( $id && function_exists( 'pll_get_post' ) ) {
			$tr = pll_get_post( $id, $lang );
			$id = $tr ? (int) $tr : $id;
		}
		return $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : '';
	}



	public static function recaptcha_keys(): array {
		return class_exists( 'WPCF7' ) ? (array) WPCF7::get_option( 'recaptcha' ) : array();
	}

	public static function set_recaptcha( string $site_key, string $secret ): bool {
		if ( ! class_exists( 'WPCF7' ) || '' === $site_key || '' === $secret ) {
			return false;
		}
		WPCF7::update_option( 'recaptcha', array( $site_key => $secret ) );
		return true;
	}







	public static function css(): string {
		$s      = NAS_Settings::get( 'forms' );
		$radius = max( 0, min( 30, (int) ( $s['radius'] ?? 10 ) ) );
		$btn    = array( 'pill' => '999px', 'rounded' => $radius . 'px', 'square' => '0' )[ $s['button'] ?? 'pill' ] ?? '999px';
		$dark   = 'dark' === ( $s['style'] ?? 'light' );
		$label  = $dark ? '#ffffff' : 'var(--e-global-color-text, #1f2933)';
		$field  = $dark ? 'rgba(255,255,255,.96)' : '#ffffff';
		$border = $dark ? 'rgba(255,255,255,.35)' : 'rgba(0,0,0,.18)';

		return ".nas-form .nas-form__grid{display:grid;grid-template-columns:1fr 1fr;gap:4px 18px}"
			. '.nas-form .nas-form__field{margin:0 0 12px}'
			. '.nas-form .nas-form__field--full{grid-column:1/-1}'
			. "@media(max-width:767px){.nas-form .nas-form__grid{grid-template-columns:1fr}}"
			. ".nas-form label{display:block;font-family:var(--e-global-typography-text-font-family,inherit);font-size:14px;font-weight:600;line-height:1.4;color:{$label}}"
			. ".nas-form input[type=text],.nas-form input[type=email],.nas-form input[type=tel],.nas-form select,.nas-form textarea{display:block;width:100%;box-sizing:border-box;margin-top:6px;padding:12px 14px;font-family:var(--e-global-typography-text-font-family,inherit);font-size:16px;line-height:1.4;color:#1f2933;background:{$field};border:1px solid {$border};border-radius:{$radius}px;transition:border-color .2s,box-shadow .2s}"
			. '.nas-form textarea{min-height:120px;resize:vertical}'
			. '.nas-form input:focus,.nas-form select:focus,.nas-form textarea:focus{outline:none;border-color:var(--e-global-color-accent,#2271b1);box-shadow:0 0 0 3px color-mix(in srgb,var(--e-global-color-accent,#2271b1) 25%,transparent)}'
			. ".nas-form .nas-form__consent{font-size:14px;font-weight:400;color:{$label}}"
			. ".nas-form .nas-form__consent a{color:inherit;text-decoration:underline}"
			. ".nas-form .wpcf7-submit{display:inline-block;padding:14px 30px;font-family:var(--e-global-typography-accent-font-family,inherit);font-size:16px;font-weight:700;color:#fff;background:var(--e-global-color-accent,#2271b1);border:0;border-radius:{$btn};cursor:pointer;transition:filter .2s,transform .1s}"
			. '.nas-form .wpcf7-submit:hover{filter:brightness(.92)}.nas-form .wpcf7-submit:active{transform:scale(.98)}'
			. '.nas-form .wpcf7-spinner{vertical-align:middle}'
			. '.nas-form .wpcf7-not-valid-tip{font-size:13px;font-weight:500;margin-top:4px;color:' . ( $dark ? '#ffc9bd' : '#b42318' ) . '}'
			. ".nas-form .wpcf7-response-output{margin:12px 0 0!important;padding:12px 14px!important;border-radius:{$radius}px;font-size:15px;" . ( $dark ? 'color:#fff;' : '' ) . '}'
			. '.nas-form .wpcf7-list-item{margin:0 6px 0 0}';
	}

	public static function styles(): void {
		if ( wp_style_is( self::CSS_HANDLE, 'enqueued' ) || wp_style_is( self::CSS_HANDLE, 'registered' ) ) {
			wp_add_inline_style( self::CSS_HANDLE, self::css() );
		}
	}



	public static function render_tab(): void {
		$s    = NAS_Settings::get( 'forms' );
		$keys = self::recaptcha_keys();
		$site = $keys ? (string) array_key_first( $keys ) : '';
		$langs = function_exists( 'pll_languages_list' ) ? (array) pll_languages_list( array( 'fields' => 'slug' ) ) : array( substr( get_locale(), 0, 2 ) );
		?>
		<div class="nas-card">
			<h2>Lead form per language</h2>
			<?php if ( ! self::available() ) : ?>
				<p>Contact Form 7 is not active.</p>
			<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="nas_forms_create">
				<?php wp_nonce_field( 'nas_forms_create' ); ?>
				<table class="form-table" role="presentation">
					<tr><th>Client email (receives the leads)</th><td><input type="email" class="regular-text" name="recipient" required></td></tr>
					<tr><th>Languages</th><td><?php foreach ( $langs as $l ) : ?><label style="margin-right:12px"><input type="checkbox" name="langs[]" value="<?php echo esc_attr( $l ); ?>" checked> <?php echo esc_html( strtoupper( $l ) ); ?></label><?php endforeach; ?></td></tr>
					<tr><th>Services (one per line, optional)</th><td><textarea name="services" rows="4" class="large-text"></textarea></td></tr>
					<tr><th>Areas (one per line, optional)</th><td><textarea name="areas" rows="3" class="large-text"></textarea><p class="description">The towns or neighbourhoods the business covers.</p></td></tr>
					<tr><th>Phone required</th><td><label><input type="checkbox" name="phone_required" value="1" checked> Yes</label></td></tr>
				</table>
				<p class="description">From: <code><?php echo esc_html( self::sender_email() ); ?></code> (the Post SMTP mailbox when set). Reply-To: the visitor. The privacy link uses the privacy policy page of each language.</p>
				<?php submit_button( 'Create or update the forms', 'primary', 'submit', false ); ?>
			</form>
			<?php if ( ! empty( $s['forms'] ) ) : ?>
				<h3>Forms created by the Suite</h3>
				<ul>
				<?php foreach ( (array) $s['forms'] as $l => $fid ) : ?>
					<li><?php echo esc_html( strtoupper( $l ) ); ?>: <code>[contact-form-7 id="<?php echo (int) $fid; ?>" html_class="nas-form"]</code> <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpcf7&post=' . (int) $fid . '&action=edit' ) ); ?>">edit in CF7</a></li>
				<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php endif; ?>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="nas_forms_save">
			<?php wp_nonce_field( 'nas_forms_save' ); ?>
			<div class="nas-card">
				<h2>Design</h2>
				<p><label>Style <select name="style"><option value="light" <?php selected( $s['style'], 'light' ); ?>>Light background</option><option value="dark" <?php selected( $s['style'], 'dark' ); ?>>Dark background</option></select></label>
				<label style="margin-left:16px">Corners <input type="number" min="0" max="30" name="radius" value="<?php echo (int) $s['radius']; ?>" class="small-text"> px</label>
				<label style="margin-left:16px">Button <select name="button"><option value="pill" <?php selected( $s['button'], 'pill' ); ?>>Pill</option><option value="rounded" <?php selected( $s['button'], 'rounded' ); ?>>Rounded</option><option value="square" <?php selected( $s['button'], 'square' ); ?>>Square</option></select></label></p>
				<p class="description">Colours and fonts come from the Elementor kit (accent colour on the button and focus, text font on the fields).</p>
			</div>
			<div class="nas-card">
				<h2>reCAPTCHA v3</h2>
				<p><label>Site key<br><input type="text" class="regular-text code" name="recaptcha_site" value="<?php echo esc_attr( $site ); ?>"></label></p>
				<p><label>Secret key<br><input type="password" class="regular-text code" name="recaptcha_secret" value="" placeholder="<?php echo $site ? 'saved (leave empty to keep)' : ''; ?>" autocomplete="new-password"></label></p>
				<p class="description">From google.com/recaptcha/admin, type v3, with the site's domain. The Performance module delays the reCAPTCHA script until the first interaction (pattern "recaptcha").</p>
			</div>
			<?php submit_button( 'Save' ); ?>
		</form>
		<?php
	}

	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_forms_save' );
		$s           = NAS_Settings::get( 'forms' );
		$s['style']  = in_array( $_POST['style'] ?? '', array( 'light', 'dark' ), true ) ? sanitize_key( $_POST['style'] ) : 'light';
		$s['radius'] = max( 0, min( 30, (int) ( $_POST['radius'] ?? 10 ) ) );
		$s['button'] = in_array( $_POST['button'] ?? '', array( 'pill', 'rounded', 'square' ), true ) ? sanitize_key( $_POST['button'] ) : 'pill';
		NAS_Settings::save_site( array( 'forms' => $s ) );

		$site   = sanitize_text_field( wp_unslash( $_POST['recaptcha_site'] ?? '' ) );
		$secret = sanitize_text_field( wp_unslash( $_POST['recaptcha_secret'] ?? '' ) );
		$msg    = 'Saved.';
		if ( $site ) {
			$keys   = self::recaptcha_keys();
			$secret = $secret ? $secret : (string) ( $keys[ $site ] ?? '' );
			if ( $secret && self::set_recaptcha( $site, $secret ) ) {
				$msg .= ' reCAPTCHA keys set in Contact Form 7.';
			}
		}
		NAS_Cache::after_change( 0 );
		NAS_Admin::notice_flash( $msg );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=forms' ) );
		exit;
	}

	public static function handle_create(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_forms_create' );
		$lines = static function ( $v ) {
			return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', sanitize_textarea_field( wp_unslash( (string) $v ) ) ) ) ) );
		};
		$out = array();
		foreach ( (array) ( $_POST['langs'] ?? array() ) as $lang ) {
			$r     = self::setup(
				array(
					'lang'           => sanitize_key( $lang ),
					'recipient'      => sanitize_email( wp_unslash( $_POST['recipient'] ?? '' ) ),
					'services'       => $lines( $_POST['services'] ?? '' ),
					'areas'          => $lines( $_POST['areas'] ?? '' ),
					'phone_required' => ! empty( $_POST['phone_required'] ),
				)
			);
			$out[] = is_wp_error( $r ) ? strtoupper( $lang ) . ': ' . $r->get_error_message() : strtoupper( $lang ) . ': form ' . $r['id'] . ( $r['updated'] ? ' updated' : ' created' );
		}
		NAS_Admin::notice_flash( implode( '<br>', array_map( 'esc_html', $out ) ) );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=forms' ) );
		exit;
	}
}

NAS_Forms::init();
