<?php









defined( 'ABSPATH' ) || exit;

class NAS_Hygiene {

	public static function init(): void {
		$h = NAS_Settings::get( 'hygiene' );
		if ( ! empty( $h['feed_links_extra'] ) ) {
			add_action( 'wp', static function () {
				remove_action( 'wp_head', 'feed_links_extra', 3 );
			} );
		}
		if ( ! empty( $h['templates_noindex'] ) ) {
			add_filter( 'rank_math/sitemap/exclude_post_type', array( __CLASS__, 'rank_math_exclude' ), 10, 2 );
			add_filter( 'wp_sitemaps_post_types', array( __CLASS__, 'core_sitemap' ) );
			add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
			add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'rank_math_robots' ) );
		}
		add_action( 'admin_post_nas_hygiene_save', array( __CLASS__, 'handle_save' ) );
	}

	private static function template_types(): array {
		return array( 'chf_template', 'elementor_library' );
	}

	public static function rank_math_exclude( $exclude, $type ) {
		return in_array( $type, self::template_types(), true ) ? true : $exclude;
	}

	public static function core_sitemap( $types ) {
		foreach ( self::template_types() as $t ) {
			unset( $types[ $t ] );
		}
		return $types;
	}

	private static function is_template_view(): bool {
		return is_singular( self::template_types() );
	}

	public static function robots( $robots ) {
		if ( self::is_template_view() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}

	public static function rank_math_robots( $robots ) {
		if ( self::is_template_view() ) {
			$robots['index']  = 'noindex';
			$robots['follow'] = 'nofollow';
		}
		return $robots;
	}

	public static function render_tab(): void {
		$h = NAS_Settings::get( 'hygiene' );
		?>
		<div class="nas-card">
			<h2>SEO hygiene</h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="nas_hygiene_save">
				<?php wp_nonce_field( 'nas_hygiene_save' ); ?>
				<p><label><input type="checkbox" name="templates_noindex" value="1" <?php checked( ! empty( $h['templates_noindex'] ) ); ?>> Header, footer and template URLs out of sitemaps and search results</label></p>
				<p><label><input type="checkbox" name="feed_links_extra" value="1" <?php checked( ! empty( $h['feed_links_extra'] ) ); ?>> Remove feed links per post, per tag and per category (the main feed stays)</label></p>
				<?php submit_button( 'Save' ); ?>
			</form>
			<h3>Done by hand or over MCP, once per site</h3>
			<ul style="list-style:disc;margin-left:20px">
				<li>Tags with one or two posts: noindex in Rank Math (Titles &amp; Meta &gt; Tags).</li>
				<li>In Search Console, never press "Validate fix" for intentional reasons (redirects, canonical, robots, noindex): the validation fails and sends the warning emails.</li>
				<li>Links to the language root always with the final slash (<code>/pt/</code>, not <code>/pt</code>), to avoid a 301 on every page.</li>
				<li>Rank Math AMP module off when there is no AMP plugin.</li>
				<li>If AI crawlers (OAI-SearchBot, PerplexityBot, ClaudeBot) get 406 or a cut connection while Googlebot gets 200, the block is on the server (ModSecurity or the host firewall), not in WordPress: ask the host to allow them.</li>
			</ul>
		</div>
		<?php
	}

	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_hygiene_save' );
		NAS_Settings::save_site(
			array(
				'hygiene' => array(
					'templates_noindex' => ! empty( $_POST['templates_noindex'] ),
					'feed_links_extra'  => ! empty( $_POST['feed_links_extra'] ),
				),
			)
		);
		NAS_Cache::after_change( 0 );
		NAS_Admin::notice_flash( 'Saved. Caches cleared.' );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=hygiene' ) );
		exit;
	}
}

NAS_Hygiene::init();
