<?php








defined( 'ABSPATH' ) || exit;

class NAS_SMTP {

	const OPTION = 'postman_options';

	public static function init(): void {
		add_action( 'admin_post_nas_smtp_save', array( __CLASS__, 'handle_save' ) );
	}

	public static function available(): bool {
		return NAS_Env::active( 'post_smtp' );
	}

	public static function options(): array {
		$o = get_option( self::OPTION, array() );
		return is_array( $o ) ? $o : array();
	}

	public static function global_network_settings(): bool {
		if ( ! is_multisite() ) {
			return false;
		}
		$n = get_site_option( 'postman_network_options', array() );
		return is_array( $n ) && ! empty( $n['post_smtp_global_settings'] );
	}


	public static function status(): array {
		$o = self::options();
		$s = NAS_Settings::get( 'smtp' );
		return array(
			'plugin_active'  => self::available(),
			'configured'     => 'smtp' === ( $o['transport_type'] ?? '' ) && ! empty( $o['hostname'] ) && ! empty( $o['basic_auth_username'] ),
			'host'           => (string) ( $o['hostname'] ?? '' ),
			'port'           => (string) ( $o['port'] ?? '' ),
			'security'       => (string) ( $o['enc_type'] ?? '' ),
			'username'       => (string) ( $o['basic_auth_username'] ?? '' ),
			'sender_email'   => (string) ( $o['sender_email'] ?? '' ),
			'sender_name'    => (string) ( $o['sender_name'] ?? '' ),
			'network_global' => self::global_network_settings(),
			'last_test'      => (string) ( $s['last_test'] ?? '' ),
			'last_result'    => (string) ( $s['last_test_result'] ?? '' ),
		);
	}





	public static function save( array $a ): void {
		$o    = self::options();
		$user = sanitize_email( $a['username'] );
		$o    = array_merge(
			$o,
			array(
				'transport_type'                => 'smtp',
				'hostname'                      => sanitize_text_field( $a['host'] ),
				'port'                          => (int) $a['port'],
				'enc_type'                      => in_array( $a['security'], array( 'ssl', 'tls', 'none' ), true ) ? $a['security'] : 'ssl',
				'auth_type'                     => 'login',
				'basic_auth_username'           => $user,
				'sender_email'                  => $a['sender_email'] ? sanitize_email( $a['sender_email'] ) : $user,
				'sender_name'                   => $a['sender_name'] ? sanitize_text_field( $a['sender_name'] ) : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'envelope_sender'               => $a['sender_email'] ? sanitize_email( $a['sender_email'] ) : $user,

				'prevent_sender_email_override' => 'on',
			)
		);
		if ( '' !== (string) $a['password'] ) {
			$o['basic_auth_password'] = base64_encode( (string) $a['password'] );
		}
		update_option( self::OPTION, $o );
		NAS_Updater::record( 'smtp', 'Post SMTP set to ' . $user . ' at ' . $o['hostname'] . ':' . $o['port'] );
	}

	public static function send_test( string $to ): string {
		$ok = wp_mail(
			$to,
			'Navia Suite: test email from ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			"This email was sent by Post SMTP through the mailbox of the site.\n\nSite: " . home_url( '/' ) . "\nTime: " . current_time( 'mysql' ) . "\n\nIf it reached the inbox (not spam), contact forms will arrive too."
		);
		$s                     = NAS_Settings::get( 'smtp' );
		$s['last_test']        = current_time( 'mysql' );
		$s['last_test_result'] = $ok ? 'ok' : 'failed';
		NAS_Settings::save_site( array( 'smtp' => $s ) );
		NAS_Updater::record( 'smtp', 'Test email to ' . $to . ': ' . $s['last_test_result'] );
		return $s['last_test_result'];
	}

	public static function render_tab(): void {
		$st   = self::status();
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$host = preg_replace( '/^www\./', '', $host );
		?>
		<div class="nas-card">
			<h2>Email through the site mailbox (Post SMTP)</h2>
			<?php if ( ! self::available() ) : ?>
				<p>Post SMTP is not active.</p>
			<?php else : ?>
				<?php if ( $st['network_global'] ) : ?>
					<p><strong>Post SMTP uses network wide settings:</strong> every site sends with the settings of site 1. Change them there, or switch global settings off in Post SMTP.</p>
				<?php endif; ?>
				<p>In cPanel &gt; Email Accounts create the mailbox for this site (for example <code>geral@<?php echo esc_html( $host ); ?></code> or <code>noreply@<?php echo esc_html( $host ); ?></code>). In cPanel &gt; Email Deliverability confirm SPF and DKIM are valid. Then fill in:</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="nas_smtp_save">
					<?php wp_nonce_field( 'nas_smtp_save' ); ?>
					<table class="form-table" role="presentation">
						<tr><th>SMTP server</th><td><input type="text" class="regular-text code" name="host" value="<?php echo esc_attr( $st['host'] ? $st['host'] : 'mail.' . $host ); ?>"></td></tr>
						<tr><th>Port and security</th><td><input type="number" name="port" class="small-text" value="<?php echo esc_attr( $st['port'] ? $st['port'] : '465' ); ?>">
							<select name="security"><option value="ssl" <?php selected( $st['security'] ? $st['security'] : 'ssl', 'ssl' ); ?>>SSL (465)</option><option value="tls" <?php selected( $st['security'], 'tls' ); ?>>STARTTLS (587)</option><option value="none" <?php selected( $st['security'], 'none' ); ?>>None</option></select></td></tr>
						<tr><th>Mailbox (username)</th><td><input type="email" class="regular-text" name="username" value="<?php echo esc_attr( $st['username'] ); ?>" required></td></tr>
						<tr><th>Password</th><td><input type="password" class="regular-text" name="password" value="" autocomplete="new-password" placeholder="<?php echo $st['configured'] ? 'saved (leave empty to keep)' : ''; ?>"></td></tr>
						<tr><th>From name</th><td><input type="text" class="regular-text" name="sender_name" value="<?php echo esc_attr( $st['sender_name'] ? $st['sender_name'] : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ); ?>"></td></tr>
						<tr><th>Send a test to</th><td><input type="email" class="regular-text" name="test_to" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>"> <span class="description">Leave empty to skip the test.</span></td></tr>
					</table>
					<?php submit_button( 'Save and test' ); ?>
				</form>
				<p class="description">Last test: <?php echo esc_html( $st['last_test'] ? $st['last_test'] . ', ' . $st['last_result'] : 'none' ); ?>. Post SMTP keeps a log of every email in Post SMTP &gt; Email Log.</p>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'nas_smtp_save' );
		self::save(
			array(
				'host'         => wp_unslash( $_POST['host'] ?? '' ),
				'port'         => (int) ( $_POST['port'] ?? 465 ),
				'security'     => sanitize_key( $_POST['security'] ?? 'ssl' ),
				'username'     => wp_unslash( $_POST['username'] ?? '' ),
				'password'     => (string) wp_unslash( $_POST['password'] ?? '' ),
				'sender_email' => '',
				'sender_name'  => wp_unslash( $_POST['sender_name'] ?? '' ),
			)
		);
		$msg = 'Post SMTP settings saved.';
		$to  = sanitize_email( wp_unslash( $_POST['test_to'] ?? '' ) );
		if ( $to ) {
			$r    = self::send_test( $to );
			$msg .= 'ok' === $r ? ' Test email sent to ' . esc_html( $to ) . ': check the inbox and the spam folder.' : ' The test email failed: see Post SMTP > Email Log for the server answer.';
		}
		NAS_Admin::notice_flash( $msg );
		wp_safe_redirect( admin_url( 'admin.php?page=navia-suite-stack&tab=smtp' ) );
		exit;
	}
}

NAS_SMTP::init();
