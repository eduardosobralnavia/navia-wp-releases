<?php





defined( 'ABSPATH' ) || exit;

class CHF_Polylang {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'pll_get_post_types', [ $this, 'make_translatable' ], 10, 2 );
		add_filter( 'pll_copy_post_metas', [ $this, 'copy_metas' ] );
	}

	public function make_translatable( $post_types, $is_settings ) {
		$post_types[ CHF_POST_TYPE ] = CHF_POST_TYPE;
		return $post_types;
	}

	public function copy_metas( $metas ) {
		$metas[] = CHF_Post_Type::META_TYPE;
		$metas[] = CHF_Post_Type::META_ENABLED;
		return $metas;
	}
}
