<?php





defined( 'ABSPATH' ) || exit;

class CHF_Post_Type {

	const META_TYPE    = '_chf_template_type';
	const META_ENABLED = '_chf_enabled';
	const NONCE        = 'chf_meta_nonce';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', [ __CLASS__, 'register_post_type' ] );


		add_filter( 'option_elementor_cpt_support', [ $this, 'add_elementor_cpt_support' ] );
		add_filter( 'default_option_elementor_cpt_support', [ $this, 'add_elementor_cpt_support' ] );

		add_action( 'add_meta_boxes', [ $this, 'add_meta_box' ] );
		add_action( 'save_post_' . CHF_POST_TYPE, [ $this, 'save_meta' ], 10, 2 );


		add_filter( 'manage_' . CHF_POST_TYPE . '_posts_columns', [ $this, 'admin_columns' ] );
		add_action( 'manage_' . CHF_POST_TYPE . '_posts_custom_column', [ $this, 'admin_column_content' ], 10, 2 );


		add_filter( 'template_include', [ $this, 'canvas_template' ], 999 );
	}

	public static function register_post_type() {
		$labels = [
			'name'               => __( 'Header & Footer', 'custom-hf-elementor' ),
			'singular_name'      => __( 'HF Template', 'custom-hf-elementor' ),
			'menu_name'          => __( 'Header & Footer', 'custom-hf-elementor' ),
			'add_new'            => __( 'Add New Template', 'custom-hf-elementor' ),
			'add_new_item'       => __( 'Add New Template', 'custom-hf-elementor' ),
			'edit_item'          => __( 'Edit Template', 'custom-hf-elementor' ),
			'new_item'           => __( 'New Template', 'custom-hf-elementor' ),
			'view_item'          => __( 'View Template', 'custom-hf-elementor' ),
			'search_items'       => __( 'Search Templates', 'custom-hf-elementor' ),
			'not_found'          => __( 'No templates found', 'custom-hf-elementor' ),
			'not_found_in_trash' => __( 'No templates found in Trash', 'custom-hf-elementor' ),
		];

		register_post_type(
			CHF_POST_TYPE,
			[
				'labels'              => $labels,
				'public'              => true,
				'publicly_queryable'  => true,
				'exclude_from_search' => true,
				'show_in_nav_menus'   => false,
				'show_ui'             => true,
				'show_in_menu'        => NAS_Admin::MENU,
				'menu_icon'           => 'dashicons-editor-kitchensink',
				'menu_position'       => 60,
				'rewrite'             => false,
				'has_archive'         => false,
				'show_in_rest'        => false,
				'supports'            => [ 'title', 'elementor' ],
				'capability_type'     => 'post',
			]
		);
	}




	public function add_elementor_cpt_support( $value ) {
		if ( ! is_array( $value ) ) {
			$value = [ 'page', 'post' ];
		}
		if ( ! in_array( CHF_POST_TYPE, $value, true ) ) {
			$value[] = CHF_POST_TYPE;
		}
		return $value;
	}

	public function add_meta_box() {
		add_meta_box(
			'chf_settings',
			__( 'Template Settings', 'custom-hf-elementor' ),
			[ $this, 'render_meta_box' ],
			CHF_POST_TYPE,
			'side',
			'high'
		);
	}

	public function render_meta_box( $post ) {
		wp_nonce_field( self::NONCE, self::NONCE );

		$type    = get_post_meta( $post->ID, self::META_TYPE, true );
		$type    = $type ? $type : 'header';
		$enabled = get_post_meta( $post->ID, self::META_ENABLED, true );
		$enabled = ( '' === $enabled ) ? 'yes' : $enabled;
		?>
		<p>
			<label for="chf_template_type"><strong><?php esc_html_e( 'Template type', 'custom-hf-elementor' ); ?></strong></label><br>
			<select name="chf_template_type" id="chf_template_type" style="width:100%">
				<option value="header" <?php selected( $type, 'header' ); ?>><?php esc_html_e( 'Header', 'custom-hf-elementor' ); ?></option>
				<option value="footer" <?php selected( $type, 'footer' ); ?>><?php esc_html_e( 'Footer', 'custom-hf-elementor' ); ?></option>
				<option value="single" <?php selected( $type, 'single' ); ?>><?php esc_html_e( 'Single Post (Blog)', 'custom-hf-elementor' ); ?></option>
			</select>
		</p>
		<p>
			<label>
				<input type="checkbox" name="chf_enabled" value="yes" <?php checked( $enabled, 'yes' ); ?>>
				<?php esc_html_e( 'Display on entire site', 'custom-hf-elementor' ); ?>
			</label>
		</p>
		<p class="description">
			<?php esc_html_e( 'Only one published, enabled template per type (and per language when using Polylang) is displayed. The most recent one wins. "Single Post" templates replace the layout of every blog post; build them with the Navia dynamic widgets (Post Title, Featured Image, Post Content, etc.).', 'custom-hf-elementor' ); ?>
		</p>
		<?php
	}

	public function save_meta( $post_id, $post ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( $_POST[ self::NONCE ] ), self::NONCE ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$type = isset( $_POST['chf_template_type'] ) ? sanitize_key( $_POST['chf_template_type'] ) : 'header';
		if ( ! in_array( $type, [ 'header', 'footer', 'single' ], true ) ) {
			$type = 'header';
		}
		update_post_meta( $post_id, self::META_TYPE, $type );

		$enabled = ( isset( $_POST['chf_enabled'] ) && 'yes' === $_POST['chf_enabled'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, self::META_ENABLED, $enabled );
	}

	public function admin_columns( $columns ) {
		$new = [];
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['chf_type']    = __( 'Type', 'custom-hf-elementor' );
				$new['chf_enabled'] = __( 'Displayed', 'custom-hf-elementor' );
			}
		}
		return $new;
	}

	public function admin_column_content( $column, $post_id ) {
		if ( 'chf_type' === $column ) {
			$type   = get_post_meta( $post_id, self::META_TYPE, true );
			$labels = [
				'header' => __( 'Header', 'custom-hf-elementor' ),
				'footer' => __( 'Footer', 'custom-hf-elementor' ),
				'single' => __( 'Single Post', 'custom-hf-elementor' ),
			];
			echo esc_html( isset( $labels[ $type ] ) ? $labels[ $type ] : $labels['header'] );
		}
		if ( 'chf_enabled' === $column ) {
			$enabled = get_post_meta( $post_id, self::META_ENABLED, true );
			echo ( 'no' === $enabled ) ? esc_html__( 'No', 'custom-hf-elementor' ) : esc_html__( 'Yes', 'custom-hf-elementor' );
		}
	}




	public function canvas_template( $template ) {
		if ( is_singular( CHF_POST_TYPE ) ) {
			return NAS_TB_DIR . 'templates/canvas.php';
		}
		return $template;
	}
}
