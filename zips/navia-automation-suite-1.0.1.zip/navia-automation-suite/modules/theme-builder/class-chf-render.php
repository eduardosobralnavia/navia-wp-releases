<?php





defined( 'ABSPATH' ) || exit;

class CHF_Render {

	private static $instance = null;


	private $cache = [];


	private $rendered = [];


	private $markup = [];

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', [ $this, 'setup_frontend' ] );
		add_filter( 'template_include', [ $this, 'single_post_template' ], 998 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_template_css' ], 20 );
	}





	public function setup_frontend() {

		if ( is_singular( CHF_POST_TYPE ) ) {
			return;
		}
		if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::instance()->preview->is_preview_mode() ) {
			return;
		}

		$has_header = (bool) $this->get_template_id( 'header' );
		$has_footer = (bool) $this->get_template_id( 'footer' );

		if ( ! $has_header && ! $has_footer ) {
			return;
		}


		if ( $this->is_hello_elementor() ) {
			add_filter( 'hello_elementor_header_footer', '__return_false' );
		}




		if ( $this->uses_single_template() ) {
			return;
		}

		if ( $this->is_hello_elementor() ) {
			if ( $has_header ) {
				add_action( 'wp_body_open', [ $this, 'render_header_markup' ], 1 );
			}
			if ( $has_footer ) {
				add_action( 'wp_footer', [ $this, 'render_footer_markup' ], 5 );
			}
			return;
		}

		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {


			if ( $has_header ) {
				add_action( 'wp_body_open', [ $this, 'render_header_markup' ], 1 );
			}
			if ( $has_footer ) {
				add_action( 'wp_footer', [ $this, 'render_footer_markup' ], 5 );
			}
			return;
		}


		if ( $has_header ) {
			add_action( 'get_header', [ $this, 'override_header' ] );
		}
		if ( $has_footer ) {
			add_action( 'get_footer', [ $this, 'override_footer' ] );
		}
	}




	private function is_hello_elementor() {
		return defined( 'HELLO_ELEMENTOR_VERSION' ) || 'hello-elementor' === get_template();
	}




	private function uses_single_template() {
		return is_singular( 'post' ) && (bool) $this->get_template_id( 'single' );
	}

	public function override_header() {
		require NAS_TB_DIR . 'templates/header.php';

		ob_start();
		locate_template( [ 'header.php' ], true );
		ob_get_clean();
	}

	public function override_footer() {
		require NAS_TB_DIR . 'templates/footer.php';
		ob_start();
		locate_template( [ 'footer.php' ], true );
		ob_get_clean();
	}








	public function single_post_template( $template ) {
		if ( ! is_singular( 'post' ) ) {
			return $template;
		}
		if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::instance()->preview->is_preview_mode() ) {
			return $template;
		}
		if ( ! $this->uses_single_template() ) {
			return $template;
		}
		return NAS_TB_DIR . 'templates/single.php';
	}














	public function get_template_id( $type ) {
		if ( isset( $this->cache[ $type ] ) ) {
			return $this->cache[ $type ];
		}

		$id = $this->query_template( $type );


		if ( ! $id && function_exists( 'pll_default_language' ) && function_exists( 'pll_current_language' ) ) {
			$default = pll_default_language();
			$current = pll_current_language();
			if ( $default && $default !== $current ) {
				$fallback_id = $this->query_template( $type, $default );
				if ( $fallback_id ) {
					$translated = function_exists( 'pll_get_post' ) ? pll_get_post( $fallback_id, $current ) : 0;
					$id         = $translated ? $translated : $fallback_id;
				}
			}
		}







		$id = (int) apply_filters( 'chf_template_id', $id, $type );

		$this->cache[ $type ] = $id;
		return $id;
	}




	private function query_template( $type, $lang = '' ) {
		$args = [
			'post_type'      => CHF_POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_query'     => [
				[
					'key'   => CHF_Post_Type::META_TYPE,
					'value' => $type,
				],
				[
					'relation' => 'OR',
					[
						'key'   => CHF_Post_Type::META_ENABLED,
						'value' => 'yes',
					],
					[
						'key'     => CHF_Post_Type::META_ENABLED,
						'compare' => 'NOT EXISTS',
					],
				],
			],
		];

		if ( $lang ) {
			$args['lang'] = $lang;
		}

		$ids = get_posts( $args );
		return $ids ? (int) $ids[0] : 0;
	}





	public function render_header_markup() {
		$this->render_markup( 'header' );
	}

	public function render_footer_markup() {
		$this->render_markup( 'footer' );
	}

	public function render_single_markup() {
		$this->render_markup( 'single' );
	}











	private function get_markup( $type ) {
		if ( isset( $this->markup[ $type ] ) ) {
			return $this->markup[ $type ];
		}

		$this->markup[ $type ] = '';

		$id = $this->get_template_id( $type );
		if ( ! $id || ! class_exists( '\Elementor\Plugin' ) ) {
			return '';
		}

		$this->markup[ $type ] = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $id );

		return $this->markup[ $type ];
	}

	private function render_markup( $type ) {


		if ( ! empty( $this->rendered[ $type ] ) ) {
			return;
		}

		$markup = $this->get_markup( $type );
		if ( '' === $markup ) {
			return;
		}

		$this->rendered[ $type ] = true;
		echo '<div class="chf-template chf-template--' . esc_attr( $type ) . '">';
		echo $markup;
		echo '</div>';
	}






	public function enqueue_template_css() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}

		$types = [ 'header', 'footer' ];
		if ( is_singular( 'post' ) ) {
			$types[] = 'single';
		}

		foreach ( $types as $type ) {
			$id = $this->get_template_id( $type );
			if ( ! $id ) {
				continue;
			}

			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
				$css = \Elementor\Core\Files\CSS\Post::create( $id );
				$css->enqueue();
			}






			$this->enqueue_widget_assets( $id );




			if ( 'single' !== $type ) {
				$this->get_markup( $type );
			}
		}
	}




	private function enqueue_widget_assets( $id ) {
		$document = \Elementor\Plugin::instance()->documents->get( $id );
		if ( ! $document ) {
			return;
		}

		$data = $document->get_elements_data();
		if ( empty( $data ) || ! is_array( $data ) ) {
			return;
		}

		$types = [];
		$this->collect_widget_types( $data, $types );
		if ( empty( $types ) ) {
			return;
		}

		$manager = \Elementor\Plugin::instance()->widgets_manager;

		foreach ( array_keys( $types ) as $widget_type ) {
			$widget = $manager->get_widget_types( $widget_type );
			if ( ! $widget ) {
				continue;
			}

			foreach ( (array) $widget->get_style_depends() as $handle ) {
				$this->enqueue_elementor_style( $handle );
			}
			foreach ( (array) $widget->get_script_depends() as $handle ) {
				if ( wp_script_is( $handle, 'registered' ) ) {
					wp_enqueue_script( $handle );
				}
			}
		}
	}




	private function collect_widget_types( $elements, &$types ) {
		foreach ( $elements as $element ) {
			if ( ! empty( $element['widgetType'] ) ) {
				$types[ $element['widgetType'] ] = true;
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$this->collect_widget_types( $element['elements'], $types );
			}
		}
	}





	private function enqueue_elementor_style( $handle ) {
		if ( ! wp_style_is( $handle, 'registered' ) && defined( 'ELEMENTOR_PATH' ) && defined( 'ELEMENTOR_ASSETS_URL' ) ) {
			$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
			$rel    = 'css/' . $handle . $suffix . '.css';

			if ( ! file_exists( ELEMENTOR_PATH . 'assets/' . $rel ) ) {
				$rel = 'css/' . $handle . '.css';
			}

			if ( ! file_exists( ELEMENTOR_PATH . 'assets/' . $rel ) ) {
				return;
			}

			wp_register_style(
				$handle,
				ELEMENTOR_ASSETS_URL . $rel,
				[],
				defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : NAS_VERSION
			);
		}

		if ( wp_style_is( $handle, 'registered' ) ) {
			wp_enqueue_style( $handle );
		}
	}
}