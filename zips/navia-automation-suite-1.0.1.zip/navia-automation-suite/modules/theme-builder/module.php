<?php








defined( 'ABSPATH' ) || exit;

NAS_Plugin::define( 'CHF_POST_TYPE', 'chf_template' );
NAS_Plugin::define( 'NAS_TB_DIR', __DIR__ . '/' );

require_once __DIR__ . '/class-chf-post-type.php';
require_once __DIR__ . '/class-chf-render.php';
require_once __DIR__ . '/class-chf-polylang.php';

add_action(
	'plugins_loaded',
	static function () {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}
		CHF_Post_Type::instance();
		CHF_Render::instance();
		CHF_Polylang::instance();
	}
);





add_action(
	'admin_notices',
	static function () {
		if ( NAS_Env::elementor_pro() && current_user_can( 'manage_options' ) ) {
			$screen = get_current_screen();
			if ( $screen && ( false !== strpos( (string) $screen->id, 'navia-suite' ) || CHF_POST_TYPE === $screen->post_type ) ) {
				echo '<div class="notice notice-warning"><p><strong>Navia Suite:</strong> the Theme Builder module is on while Elementor Pro is active. Use only one of them for headers and footers, or the header can appear twice.</p></div>';
			}
		}
	}
);
