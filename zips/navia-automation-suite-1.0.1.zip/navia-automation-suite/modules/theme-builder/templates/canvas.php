<?php





defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
	<style>
		body.chf-canvas { margin: 0; padding: 0; }
	</style>
</head>
<body <?php body_class( 'chf-canvas' ); ?>>
<?php
wp_body_open();

while ( have_posts() ) {
	the_post();



	the_content();
}

wp_footer();
?>
</body>
</html>
