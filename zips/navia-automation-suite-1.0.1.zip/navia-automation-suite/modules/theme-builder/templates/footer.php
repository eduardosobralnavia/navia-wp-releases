<?php




defined( 'ABSPATH' ) || exit;

CHF_Render::instance()->render_footer_markup();

wp_footer();
?>
</body>
</html>
