<?php






defined( 'ABSPATH' ) || exit;

$chf_render = CHF_Render::instance();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
	<style>
		body.chf-single { margin: 0; padding: 0; }
	</style>
</head>
<body <?php body_class( 'chf-single' ); ?>>
<?php
wp_body_open();

$chf_render->render_header_markup();

while ( have_posts() ) {
	the_post();
	$chf_render->render_single_markup();
}

$chf_render->render_footer_markup();

wp_footer();
?>
</body>
</html>
