
(function () {
	'use strict';

	function initNav(nav) {
		if (nav.dataset.chfInit) {
			return;
		}
		nav.dataset.chfInit = '1';

		var toggle = nav.querySelector('.chf-nav__toggle');
		if (toggle) {
			toggle.addEventListener('click', function () {
				var open = nav.classList.toggle('chf-nav-open');
				toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			});
		}


		nav.querySelectorAll('.menu-item-has-children > a').forEach(function (link) {
			var arrow = document.createElement('span');
			arrow.className = 'chf-nav__arrow';
			link.appendChild(arrow);

			arrow.addEventListener('click', function (e) {
				if (nav.classList.contains('chf-nav-open')) {
					e.preventDefault();
					e.stopPropagation();
					link.parentElement.classList.toggle('chf-sub-open');
				}
			});
		});
	}

	function initAll() {
		document.querySelectorAll('.chf-nav').forEach(initNav);
	}

	document.addEventListener('DOMContentLoaded', initAll);


	window.addEventListener('elementor/frontend/init', function () {
		if (window.elementorFrontend && window.elementorFrontend.hooks) {
			window.elementorFrontend.hooks.addAction('frontend/element_ready/chf-nav-menu.default', function ($scope) {
				var el = $scope[0] || $scope;
				var nav = el.querySelector ? el.querySelector('.chf-nav') : null;
				if (nav) { initNav(nav); }
			});
		}
	});
})();
