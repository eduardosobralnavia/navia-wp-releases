
(function () {
	'use strict';

	
	
	

	function initLoadMore(wrap) {
		if (wrap.dataset.naviaInit) {
			return;
		}
		wrap.dataset.naviaInit = '1';

		var button = wrap.querySelector('.navia-load-more');
		var grid = wrap.querySelector('.navia-grid');
		if (!button || !grid || typeof naviaBlog === 'undefined') {
			return;
		}

		button.addEventListener('click', function () {
			var page = parseInt(wrap.dataset.page || '0', 10) + 1;
			button.disabled = true;
			button.textContent = button.dataset.loading || '...';

			var body = new URLSearchParams();
			body.append('action', 'navia_load_more');
			body.append('nonce', naviaBlog.nonce);
			body.append('page', String(page));
			body.append('config', wrap.dataset.config || '{}');

			fetch(naviaBlog.ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString()
			})
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success && res.data.html) {
						grid.insertAdjacentHTML('beforeend', res.data.html);
						wrap.dataset.page = String(page);
					}
					if (res && res.success && res.data.has_more) {
						button.disabled = false;
						button.textContent = button.dataset.label;
					} else {
						button.textContent = button.dataset.done || button.dataset.label;
						button.disabled = true;
					}
				})
				.catch(function () {
					button.disabled = false;
					button.textContent = button.dataset.label;
				});
		});
	}

	
	
	

	function slugify(text, index) {
		return 'navia-h-' + index + '-' + text.toLowerCase()
			.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
			.replace(/[^a-z0-9]+/g, '-')
			.replace(/^-+|-+$/g, '')
			.slice(0, 60);
	}

	function initToc(toc) {
		if (toc.dataset.naviaInit) {
			return;
		}
		toc.dataset.naviaInit = '1';

		var content = document.querySelector('.navia-post-content');
		var list = toc.querySelector('.navia-toc__list');
		if (!content || !list) {
			return;
		}

		var levels = (toc.dataset.levels || 'h2').split(',');
		var headings = content.querySelectorAll(levels.join(','));
		if (!headings.length) {
			return;
		}

		var currentTopLi = null;
		var currentSub = null;

		headings.forEach(function (h, i) {
			if (!h.id) {
				h.id = slugify(h.textContent, i);
			}
			var li = document.createElement('li');
			var a = document.createElement('a');
			a.href = '#' + h.id;
			a.textContent = h.textContent;
			li.appendChild(a);

			if (h.tagName.toLowerCase() === 'h2' || !currentTopLi) {
				list.appendChild(li);
				currentTopLi = li;
				currentSub = null;
			} else {
				if (!currentSub) {
					currentSub = document.createElement('ul');
					currentSub.className = 'navia-toc__sub';
					currentTopLi.appendChild(currentSub);
				}
				currentSub.appendChild(li);
			}
		});

		toc.hidden = false;
	}

	function initAll() {
		document.querySelectorAll('.navia-posts').forEach(initLoadMore);
		document.querySelectorAll('.navia-toc').forEach(initToc);
	}

	document.addEventListener('DOMContentLoaded', initAll);

	window.addEventListener('elementor/frontend/init', function () {
		if (window.elementorFrontend && window.elementorFrontend.hooks) {
			['navia-posts', 'navia-loop-grid', 'navia-toc'].forEach(function (name) {
				window.elementorFrontend.hooks.addAction('frontend/element_ready/' + name + '.default', function () {
					initAll();
				});
			});
		}
	});
})();
