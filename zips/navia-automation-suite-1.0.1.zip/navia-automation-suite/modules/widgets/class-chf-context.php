<?php








defined( 'ABSPATH' ) || exit;

class CHF_Context {




	public static function post_id() {
		if ( is_singular( 'post' ) ) {
			return (int) get_queried_object_id();
		}

		global $post;
		if ( $post instanceof WP_Post && 'post' === $post->post_type ) {
			return (int) $post->ID;
		}


		$ids = get_posts(
			[
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);

		return $ids ? (int) $ids[0] : 0;
	}




	public static function is_demo() {
		return ! is_singular( 'post' );
	}
}
