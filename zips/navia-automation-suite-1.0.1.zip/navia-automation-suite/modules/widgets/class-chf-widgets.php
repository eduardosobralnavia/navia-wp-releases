<?php





defined( 'ABSPATH' ) || exit;

class CHF_Widgets {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_category' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );



		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ], 5 );
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_assets' ], 5 );
		add_action( 'elementor/preview/enqueue_styles', [ $this, 'register_assets' ], 5 );


		add_action( 'wp_ajax_navia_load_more', [ $this, 'ajax_load_more' ] );
		add_action( 'wp_ajax_nopriv_navia_load_more', [ $this, 'ajax_load_more' ] );
	}

	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'chf-elements',
			[
				'title' => __( 'Header & Footer', 'custom-hf-elementor' ),
				'icon'  => 'fa fa-header',
			]
		);
		$elements_manager->add_category(
			'navia-elements',
			[
				'title' => __( 'Navia Blog', 'custom-hf-elementor' ),
				'icon'  => 'fa fa-newspaper-o',
			]
		);
	}

	public function register_widgets( $widgets_manager ) {
		$widgets = [
			'class-chf-nav-menu-widget.php'        => 'CHF_Nav_Menu_Widget',
			'class-navia-posts-widget.php'         => 'Navia_Posts_Widget',
			'class-navia-loop-grid-widget.php'     => 'Navia_Loop_Grid_Widget',
			'class-navia-post-title-widget.php'    => 'Navia_Post_Title_Widget',
			'class-navia-featured-image-widget.php' => 'Navia_Featured_Image_Widget',
			'class-navia-post-meta-widget.php'     => 'Navia_Post_Meta_Widget',
			'class-navia-post-content-widget.php'  => 'Navia_Post_Content_Widget',
			'class-navia-breadcrumbs-widget.php'   => 'Navia_Breadcrumbs_Widget',
			'class-navia-toc-widget.php'           => 'Navia_TOC_Widget',
		];
		foreach ( $widgets as $file => $class ) {
			require_once NAS_WIDGETS_DIR . 'widgets/' . $file;
			$widgets_manager->register( new $class() );
		}
	}

	public function register_assets() {
		wp_register_style( 'chf-nav-menu', NAS_WIDGETS_URL . 'assets/css/nav-menu.css', [], NAS_VERSION );
		wp_register_script( 'chf-nav-menu', NAS_WIDGETS_URL . 'assets/js/nav-menu.js', [], NAS_VERSION, true );

		wp_register_style( 'navia-blog', NAS_WIDGETS_URL . 'assets/css/navia-blog.css', [], NAS_VERSION );
		wp_register_script( 'navia-blog', NAS_WIDGETS_URL . 'assets/js/navia-blog.js', [], NAS_VERSION, true );
		wp_localize_script(
			'navia-blog',
			'naviaBlog',
			[
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'navia_load_more' ),
			]
		);
	}




	public function ajax_load_more() {
		check_ajax_referer( 'navia_load_more', 'nonce' );

		$raw  = isset( $_POST['config'] ) ? json_decode( wp_unslash( $_POST['config'] ), true ) : [];
		$c    = Navia_Cards::sanitize_config( $raw );
		$page = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;

		$c['offset'] = $page * $c['per_page'];

		$query = new WP_Query( Navia_Cards::query_args( $c ) );
		$html  = Navia_Cards::render_cards_html( $query, $c );

		$total    = (int) $query->found_posts;
		$has_more = ( $c['offset'] + $query->post_count ) < $total;

		wp_send_json_success(
			[
				'html'     => $html,
				'has_more' => $has_more,
			]
		);
	}
}
