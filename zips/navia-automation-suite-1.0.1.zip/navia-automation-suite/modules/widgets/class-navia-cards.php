<?php





defined( 'ABSPATH' ) || exit;

class Navia_Cards {







	public static function query_args( $c ) {
		$args = [
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $c['per_page'] ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => false,
			'orderby'             => in_array( $c['orderby'], [ 'date', 'title', 'rand', 'comment_count' ], true ) ? $c['orderby'] : 'date',
			'order'               => ( 'ASC' === strtoupper( $c['order'] ) ) ? 'ASC' : 'DESC',
		];

		if ( ! empty( $c['offset'] ) ) {
			$args['offset'] = (int) $c['offset'];
		}
		if ( ! empty( $c['cats'] ) ) {
			$args['category__in'] = array_map( 'absint', (array) $c['cats'] );
		}
		if ( ! empty( $c['exclude'] ) ) {
			$args['post__not_in'] = array_map( 'absint', (array) $c['exclude'] );
		}
		if ( ! empty( $c['related_to'] ) ) {
			$related_id = absint( $c['related_to'] );
			$cats       = wp_get_post_categories( $related_id );
			if ( $cats ) {
				$args['category__in'] = $cats;
			}
			$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? $args['post__not_in'] : [], [ $related_id ] );
		}
		if ( ! empty( $c['lang'] ) && function_exists( 'pll_current_language' ) ) {
			$args['lang'] = sanitize_key( $c['lang'] );
		}

		return $args;
	}




	public static function config_defaults() {
		return [
			'per_page'       => 9,
			'offset'         => 0,
			'cats'           => [],
			'exclude'        => [],
			'related_to'     => 0,
			'order'          => 'DESC',
			'orderby'        => 'date',
			'lang'           => function_exists( 'pll_current_language' ) ? pll_current_language() : '',
			'show_image'     => 'yes',
			'show_category'  => 'yes',
			'show_date'      => 'yes',
			'show_excerpt'   => 'yes',
			'excerpt_length' => 22,
			'read_more'      => '',
		];
	}




	public static function render_card( $post_id, $c ) {
		$permalink = get_permalink( $post_id );
		$title     = get_the_title( $post_id );
		?>
		<article class="navia-card">
			<?php if ( 'yes' === $c['show_image'] ) : ?>
				<a class="navia-card__media" href="<?php echo esc_url( $permalink ); ?>" aria-hidden="true" tabindex="-1">
					<?php
					if ( has_post_thumbnail( $post_id ) ) {
						echo get_the_post_thumbnail( $post_id, 'large', [ 'loading' => 'lazy' ] );
					} else {
						echo '<span class="navia-card__placeholder"></span>';
					}
					?>
				</a>
			<?php endif; ?>
			<div class="navia-card__body">
				<?php if ( 'yes' === $c['show_category'] || 'yes' === $c['show_date'] ) : ?>
					<div class="navia-card__meta">
						<?php
						if ( 'yes' === $c['show_category'] ) {
							$cats = get_the_category( $post_id );
							if ( $cats ) {
								echo '<span class="navia-card__cat">' . esc_html( $cats[0]->name ) . '</span>';
							}
						}
						if ( 'yes' === $c['show_date'] ) {
							echo '<time class="navia-card__date" datetime="' . esc_attr( get_the_date( 'c', $post_id ) ) . '">' . esc_html( get_the_date( '', $post_id ) ) . '</time>';
						}
						?>
					</div>
				<?php endif; ?>
				<h3 class="navia-card__title"><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></h3>
				<?php if ( 'yes' === $c['show_excerpt'] ) : ?>
					<p class="navia-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt( $post_id ), max( 5, (int) $c['excerpt_length'] ), '...' ) ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $c['read_more'] ) ) : ?>
					<a class="navia-card__more" href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $c['read_more'] ); ?><span aria-hidden="true"> &rarr;</span></a>
				<?php endif; ?>
			</div>
		</article>
		<?php
	}




	public static function render_cards_html( $query, $c ) {
		ob_start();
		while ( $query->have_posts() ) {
			$query->the_post();
			self::render_card( get_the_ID(), $c );
		}
		wp_reset_postdata();
		return ob_get_clean();
	}




	public static function sanitize_config( $raw ) {
		$c = self::config_defaults();
		if ( ! is_array( $raw ) ) {
			return $c;
		}
		$c['per_page']       = isset( $raw['per_page'] ) ? min( 24, absint( $raw['per_page'] ) ) : $c['per_page'];
		$c['offset']         = isset( $raw['offset'] ) ? absint( $raw['offset'] ) : 0;
		$c['cats']           = isset( $raw['cats'] ) ? array_map( 'absint', (array) $raw['cats'] ) : [];
		$c['exclude']        = isset( $raw['exclude'] ) ? array_map( 'absint', (array) $raw['exclude'] ) : [];
		$c['related_to']     = isset( $raw['related_to'] ) ? absint( $raw['related_to'] ) : 0;
		$c['order']          = isset( $raw['order'] ) ? sanitize_text_field( $raw['order'] ) : 'DESC';
		$c['orderby']        = isset( $raw['orderby'] ) ? sanitize_key( $raw['orderby'] ) : 'date';
		$c['lang']           = isset( $raw['lang'] ) ? sanitize_key( $raw['lang'] ) : '';
		$c['show_image']     = ( isset( $raw['show_image'] ) && 'yes' === $raw['show_image'] ) ? 'yes' : 'no';
		$c['show_category']  = ( isset( $raw['show_category'] ) && 'yes' === $raw['show_category'] ) ? 'yes' : 'no';
		$c['show_date']      = ( isset( $raw['show_date'] ) && 'yes' === $raw['show_date'] ) ? 'yes' : 'no';
		$c['show_excerpt']   = ( isset( $raw['show_excerpt'] ) && 'yes' === $raw['show_excerpt'] ) ? 'yes' : 'no';
		$c['excerpt_length'] = isset( $raw['excerpt_length'] ) ? max( 5, absint( $raw['excerpt_length'] ) ) : 22;
		$c['read_more']      = isset( $raw['read_more'] ) ? sanitize_text_field( $raw['read_more'] ) : '';
		return $c;
	}
}
