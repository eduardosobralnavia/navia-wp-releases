<?php








defined( 'ABSPATH' ) || exit;

NAS_Plugin::define( 'NAS_WIDGETS_DIR', __DIR__ . '/' );
NAS_Plugin::define( 'NAS_WIDGETS_URL', NAS_URL . 'modules/widgets/' );

require_once __DIR__ . '/class-chf-context.php';
require_once __DIR__ . '/class-navia-cards.php';
require_once __DIR__ . '/class-chf-widgets.php';

add_action(
	'plugins_loaded',
	static function () {
		if ( did_action( 'elementor/loaded' ) ) {
			CHF_Widgets::instance();
		}
	}
);
