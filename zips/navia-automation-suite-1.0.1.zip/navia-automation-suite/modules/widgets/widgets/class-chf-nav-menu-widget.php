<?php







defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class CHF_Nav_Menu_Widget extends Widget_Base {

	public function get_name() {
		return 'chf-nav-menu';
	}

	public function get_title() {
		return __( 'Site Menu', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'chf-elements' ];
	}

	public function get_keywords() {
		return [ 'menu', 'nav', 'navigation', 'header' ];
	}

	public function get_style_depends() {
		return [ 'chf-nav-menu' ];
	}

	public function get_script_depends() {
		return [ 'chf-nav-menu' ];
	}

	private function get_menus() {
		$options = [];
		foreach ( wp_get_nav_menus() as $menu ) {
			$options[ $menu->term_id ] = $menu->name;
		}
		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section( 'section_menu', [ 'label' => __( 'Menu', 'custom-hf-elementor' ) ] );

		$menus = $this->get_menus();

		if ( empty( $menus ) ) {
			$this->add_control(
				'no_menu_notice',
				[
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf(

						__( 'No menus found. Create one under <a href="%s" target="_blank">Appearance &gt; Menus</a>, then reload the editor.', 'custom-hf-elementor' ),
						esc_url( admin_url( 'nav-menus.php' ) )
					),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				]
			);
		} else {
			$this->add_control(
				'menu',
				[
					'label'   => __( 'Select menu', 'custom-hf-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => $menus,
					'default' => array_key_first( $menus ),
				]
			);
		}

		$this->add_control(
			'layout',
			[
				'label'        => __( 'Layout', 'custom-hf-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'horizontal',
				'options'      => [
					'horizontal' => __( 'Horizontal', 'custom-hf-elementor' ),
					'vertical'   => __( 'Vertical', 'custom-hf-elementor' ),
				],
				'prefix_class' => 'chf-nav-wrapper--',
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'     => __( 'Alignment', 'custom-hf-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [ 'title' => __( 'Left', 'custom-hf-elementor' ), 'icon' => 'eicon-h-align-left' ],
					'center'     => [ 'title' => __( 'Center', 'custom-hf-elementor' ), 'icon' => 'eicon-h-align-center' ],
					'flex-end'   => [ 'title' => __( 'Right', 'custom-hf-elementor' ), 'icon' => 'eicon-h-align-right' ],
				],
				'default'   => 'flex-end',
				'selectors' => [ '{{WRAPPER}} .chf-nav' => 'justify-content: {{VALUE}};' ],
			]
		);

		$this->add_control(
			'collapse',
			[
				'label'        => __( 'Collapse into hamburger', 'custom-hf-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'mobile',
				'options'      => [
					'none'   => __( 'Never', 'custom-hf-elementor' ),
					'mobile' => __( 'Mobile only', 'custom-hf-elementor' ),
					'tablet' => __( 'Tablet and mobile', 'custom-hf-elementor' ),
				],
				'prefix_class' => 'chf-nav-collapse--',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section( 'section_style_items', [ 'label' => __( 'Menu items', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[ 'name' => 'item_typography', 'selector' => '{{WRAPPER}} .chf-nav__menu a' ]
		);

		$this->start_controls_tabs( 'item_colors' );

		$this->start_controls_tab( 'item_normal', [ 'label' => __( 'Normal', 'custom-hf-elementor' ) ] );
		$this->add_control( 'item_color', [ 'label' => __( 'Text color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .chf-nav__menu a' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'item_bg', [ 'label' => __( 'Background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .chf-nav__menu > li > a' => 'background-color: {{VALUE}};' ] ] );
		$this->end_controls_tab();

		$this->start_controls_tab( 'item_hover', [ 'label' => __( 'Hover', 'custom-hf-elementor' ) ] );
		$this->add_control( 'item_color_hover', [ 'label' => __( 'Text color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .chf-nav__menu a:hover' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'item_bg_hover', [ 'label' => __( 'Background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .chf-nav__menu > li > a:hover' => 'background-color: {{VALUE}};' ] ] );
		$this->end_controls_tab();

		$this->start_controls_tab( 'item_active', [ 'label' => __( 'Active', 'custom-hf-elementor' ) ] );
		$this->add_control( 'item_color_active', [ 'label' => __( 'Text color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .chf-nav__menu li.current-menu-item > a, {{WRAPPER}} .chf-nav__menu li.current-menu-ancestor > a' => 'color: {{VALUE}};' ] ] );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'item_gap',
			[
				'label'      => __( 'Space between items', 'custom-hf-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [ 'px' => [ 'min' => 0, 'max' => 60 ] ],
				'default'    => [ 'size' => 8, 'unit' => 'px' ],
				'selectors'  => [ '{{WRAPPER}} .chf-nav__menu' => 'gap: {{SIZE}}{{UNIT}};' ],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => __( 'Item padding', 'custom-hf-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default'    => [ 'top' => '8', 'right' => '12', 'bottom' => '8', 'left' => '12', 'unit' => 'px', 'isLinked' => false ],
				'selectors'  => [ '{{WRAPPER}} .chf-nav__menu a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
			]
		);

		$this->add_control(
			'item_radius',
			[
				'label'      => __( 'Item radius', 'custom-hf-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [ 'px' => [ 'min' => 0, 'max' => 999 ] ],
				'selectors'  => [ '{{WRAPPER}} .chf-nav__menu a' => 'border-radius: {{SIZE}}{{UNIT}};' ],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section( 'section_style_dropdown', [ 'label' => __( 'Dropdown', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'dd_bg', [ 'label' => __( 'Background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .chf-nav__menu .sub-menu' => 'background-color: {{VALUE}};' ] ] );
		$this->add_control( 'dd_color', [ 'label' => __( 'Text color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .chf-nav__menu .sub-menu a' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'dd_color_hover', [ 'label' => __( 'Text hover color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .chf-nav__menu .sub-menu a:hover' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'dd_typography', 'selector' => '{{WRAPPER}} .chf-nav__menu .sub-menu a' ] );
		$this->add_control( 'dd_min_width', [ 'label' => __( 'Min width', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 120, 'max' => 480 ] ], 'default' => [ 'size' => 200, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .chf-nav__menu .sub-menu' => 'min-width: {{SIZE}}{{UNIT}};' ] ] );
		$this->add_group_control( Group_Control_Border::get_type(), [ 'name' => 'dd_border', 'selector' => '{{WRAPPER}} .chf-nav__menu .sub-menu' ] );
		$this->add_control( 'dd_radius', [ 'label' => __( 'Radius', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'selectors' => [ '{{WRAPPER}} .chf-nav__menu .sub-menu' => 'border-radius: {{SIZE}}{{UNIT}}; overflow: hidden;' ] ] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'dd_shadow', 'selector' => '{{WRAPPER}} .chf-nav__menu .sub-menu' ] );

		$this->end_controls_section();


		$this->start_controls_section( 'section_style_toggle', [ 'label' => __( 'Hamburger', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control(
			'toggle_color',
			[
				'label'     => __( 'Lines color', 'custom-hf-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16323B',
				'selectors' => [ '{{WRAPPER}} .chf-nav__toggle span' => 'background-color: {{VALUE}};' ],
			]
		);

		$this->add_control(
			'toggle_size',
			[
				'label'      => __( 'Size', 'custom-hf-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [ 'px' => [ 'min' => 18, 'max' => 60 ] ],
				'default'    => [ 'size' => 28, 'unit' => 'px' ],
				'selectors'  => [ '{{WRAPPER}} .chf-nav__toggle' => 'width: {{SIZE}}{{UNIT}};' ],
			]
		);

		$this->add_control(
			'mobile_menu_bg',
			[
				'label'     => __( 'Open menu background', 'custom-hf-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [ '{{WRAPPER}} .chf-nav.chf-nav-open .chf-nav__menu' => 'background-color: {{VALUE}};' ],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$menu_id  = isset( $settings['menu'] ) ? (int) $settings['menu'] : 0;

		if ( ! $menu_id || ! wp_get_nav_menu_object( $menu_id ) ) {
			if ( \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
				echo '<div style="padding:20px;border:1px dashed #ccc;text-align:center;">';
				esc_html_e( 'Site Menu: select a menu in the widget settings (or create one under Appearance > Menus).', 'custom-hf-elementor' );
				echo '</div>';
			}
			return;
		}

		$layout = isset( $settings['layout'] ) ? $settings['layout'] : 'horizontal';
		?>
		<nav class="chf-nav chf-nav--layout-<?php echo esc_attr( $layout ); ?>" aria-label="<?php esc_attr_e( 'Site navigation', 'custom-hf-elementor' ); ?>">
			<button type="button" class="chf-nav__toggle" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle menu', 'custom-hf-elementor' ); ?>">
				<span></span><span></span><span></span>
			</button>
			<?php
			wp_nav_menu(
				[
					'menu'        => $menu_id,
					'container'   => false,
					'menu_class'  => 'chf-nav__menu',
					'fallback_cb' => false,
				]
			);
			?>
		</nav>
		<?php
	}
}
