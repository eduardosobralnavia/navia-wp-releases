<?php







defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Navia_Breadcrumbs_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-breadcrumbs';
	}

	public function get_title() {
		return __( 'Navia Breadcrumbs', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-chevron-double-right';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'breadcrumbs', 'navigation', 'schema', 'navia' ];
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Breadcrumbs', 'custom-hf-elementor' ) ] );

		$this->add_control( 'home_label', [ 'label' => __( 'Home label', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Home', 'custom-hf-elementor' ) ] );
		$this->add_control( 'blog_label', [ 'label' => __( 'Blog label', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Articles', 'custom-hf-elementor' ) ] );
		$this->add_control( 'blog_url', [ 'label' => __( 'Blog page URL', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => '/articles/' ] );
		$this->add_control(
			'output_schema',
			[
				'label'       => __( 'Output BreadcrumbList JSON-LD', 'custom-hf-elementor' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => '',
				'description' => __( 'Keep OFF if Rank Math or another SEO plugin already outputs breadcrumb schema, to avoid duplicates.', 'custom-hf-elementor' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => __( 'Style', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'link_color', [ 'label' => __( 'Link color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#7A8A91', 'selectors' => [ '{{WRAPPER}} .navia-breadcrumbs a' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'current_color', [ 'label' => __( 'Current page color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .navia-breadcrumbs__current' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'typography', 'selector' => '{{WRAPPER}} .navia-breadcrumbs' ] );

		$this->end_controls_section();
	}

	protected function render() {
		$post_id = CHF_Context::post_id();
		if ( ! $post_id ) {
			return;
		}
		$settings = $this->get_settings_for_display();

		$home_url = home_url( '/' );
		$blog_url = $settings['blog_url'] ? ( 0 === strpos( $settings['blog_url'], 'http' ) ? $settings['blog_url'] : home_url( $settings['blog_url'] ) ) : $home_url;
		$title    = get_the_title( $post_id );

		echo '<nav class="navia-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'custom-hf-elementor' ) . '">';
		echo '<a href="' . esc_url( $home_url ) . '">' . esc_html( $settings['home_label'] ) . '</a>';
		echo '<span class="navia-breadcrumbs__sep" aria-hidden="true"> / </span>';
		echo '<a href="' . esc_url( $blog_url ) . '">' . esc_html( $settings['blog_label'] ) . '</a>';
		echo '<span class="navia-breadcrumbs__sep" aria-hidden="true"> / </span>';
		echo '<span class="navia-breadcrumbs__current">' . esc_html( $title ) . '</span>';
		echo '</nav>';

		if ( 'yes' === $settings['output_schema'] && ! CHF_Context::is_demo() ) {
			$schema = [
				'@context'        => 'https://schema.org',
				'@type'           => 'BreadcrumbList',
				'itemListElement' => [
					[ '@type' => 'ListItem', 'position' => 1, 'name' => $settings['home_label'], 'item' => $home_url ],
					[ '@type' => 'ListItem', 'position' => 2, 'name' => $settings['blog_label'], 'item' => $blog_url ],
					[ '@type' => 'ListItem', 'position' => 3, 'name' => $title, 'item' => get_permalink( $post_id ) ],
				],
			];
			echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>';
		}
	}
}
