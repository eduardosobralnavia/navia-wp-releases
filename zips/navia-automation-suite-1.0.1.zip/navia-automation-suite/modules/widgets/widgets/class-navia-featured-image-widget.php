<?php




defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class Navia_Featured_Image_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-featured-image';
	}

	public function get_title() {
		return __( 'Navia Featured Image', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-featured-image';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'image', 'featured', 'thumbnail', 'navia' ];
	}

	public function get_style_depends() {
		return [ 'navia-blog' ];
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Image', 'custom-hf-elementor' ) ] );

		$this->add_control(
			'size',
			[
				'label'   => __( 'Image size', 'custom-hf-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'full',
				'options' => [
					'full'         => __( 'Full', 'custom-hf-elementor' ),
					'large'        => __( 'Large', 'custom-hf-elementor' ),
					'medium_large' => __( 'Medium large', 'custom-hf-elementor' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => __( 'Style', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'radius', [ 'label' => __( 'Radius', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .navia-featured-image img, {{WRAPPER}} .navia-featured-image' => 'border-radius: {{SIZE}}{{UNIT}};' ] ] );
		$this->add_responsive_control( 'max_height', [ 'label' => __( 'Max height', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 200, 'max' => 900 ] ], 'default' => [ 'size' => 520, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .navia-featured-image img' => 'max-height: {{SIZE}}{{UNIT}}; object-fit: cover; width: 100%;' ] ] );

		$this->end_controls_section();
	}

	protected function render() {
		$post_id = CHF_Context::post_id();
		if ( ! $post_id ) {
			return;
		}
		$settings = $this->get_settings_for_display();
		$size     = in_array( $settings['size'], [ 'full', 'large', 'medium_large' ], true ) ? $settings['size'] : 'full';

		if ( ! has_post_thumbnail( $post_id ) ) {
			if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
				echo '<div class="navia-featured-image navia-featured-image--empty">' . esc_html__( 'This post has no featured image.', 'custom-hf-elementor' ) . '</div>';
			}
			return;
		}

		echo '<figure class="navia-featured-image">' . get_the_post_thumbnail( $post_id, $size ) . '</figure>';
	}
}
