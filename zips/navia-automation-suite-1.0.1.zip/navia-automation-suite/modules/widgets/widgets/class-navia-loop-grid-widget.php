<?php







defined( 'ABSPATH' ) || exit;

require_once NAS_WIDGETS_DIR . 'widgets/class-navia-posts-widget.php';

class Navia_Loop_Grid_Widget extends Navia_Posts_Widget {

	public function get_name() {
		return 'navia-loop-grid';
	}

	public function get_title() {
		return __( 'Navia Loop Grid', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-loop-builder';
	}

	public function get_keywords() {
		return [ 'loop', 'related', 'posts', 'grid', 'navia' ];
	}

	protected function register_controls() {
		parent::register_controls();


		$this->update_control( 'posts_per_page', [ 'default' => 3 ] );

		$this->start_injection( [ 'of' => 'posts_per_page', 'at' => 'before' ] );
		$this->add_control(
			'query_source',
			[
				'label'   => __( 'Source', 'custom-hf-elementor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'latest',
				'options' => [
					'latest'  => __( 'Latest posts', 'custom-hf-elementor' ),
					'related' => __( 'Related to current post (same categories)', 'custom-hf-elementor' ),
				],
			]
		);
		$this->end_injection();


		$this->update_control( 'show_load_more', [ 'default' => '' ] );
	}

	protected function build_config( $settings ) {
		$c = parent::build_config( $settings );
		$c['per_page'] = ! empty( $settings['posts_per_page'] ) ? (int) $settings['posts_per_page'] : 3;

		if ( isset( $settings['query_source'] ) && 'related' === $settings['query_source'] ) {
			$current = CHF_Context::post_id();
			if ( $current ) {
				$c['related_to'] = $current;
			}
		}
		return $c;
	}
}
