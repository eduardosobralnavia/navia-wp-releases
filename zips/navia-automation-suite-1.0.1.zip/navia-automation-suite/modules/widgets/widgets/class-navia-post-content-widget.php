<?php





defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Navia_Post_Content_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-post-content';
	}

	public function get_title() {
		return __( 'Navia Post Content', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-post-content';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'content', 'post', 'body', 'navia' ];
	}

	public function get_style_depends() {
		return [ 'navia-blog' ];
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_style', [ 'label' => __( 'Style', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'text_color', [ 'label' => __( 'Text color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#2E3E45', 'selectors' => [ '{{WRAPPER}} .navia-post-content' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'typography', 'selector' => '{{WRAPPER}} .navia-post-content' ] );
		$this->add_control( 'heading_color', [ 'label' => __( 'Headings color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .navia-post-content h2, {{WRAPPER}} .navia-post-content h3, {{WRAPPER}} .navia-post-content h4' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'heading_typography', 'label' => __( 'Headings typography', 'custom-hf-elementor' ), 'selector' => '{{WRAPPER}} .navia-post-content h2, {{WRAPPER}} .navia-post-content h3' ] );
		$this->add_control( 'link_color', [ 'label' => __( 'Link color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .navia-post-content a' => 'color: {{VALUE}};' ] ] );

		$this->end_controls_section();
	}

	protected function render() {
		$post_id = CHF_Context::post_id();
		if ( ! $post_id ) {
			if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
				echo '<div class="navia-post-content"><p>' . esc_html__( 'Publish at least one blog post to preview the content here.', 'custom-hf-elementor' ) . '</p></div>';
			}
			return;
		}


		if ( class_exists( '\Elementor\Plugin' ) ) {
			$document = \Elementor\Plugin::instance()->documents->get( $post_id );
			if ( $document && $document->is_built_with_elementor() ) {
				echo '<div class="navia-post-content">';
				echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $post_id );
				echo '</div>';
				return;
			}
		}

		global $post;
		$original = $post;
		$post     = get_post( $post_id );
		setup_postdata( $post );

		echo '<div class="navia-post-content">';
		echo apply_filters( 'the_content', get_the_content( null, false, $post_id ) );
		echo '</div>';

		wp_reset_postdata();
		$post = $original;
	}
}
