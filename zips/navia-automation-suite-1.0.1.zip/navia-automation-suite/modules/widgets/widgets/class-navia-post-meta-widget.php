<?php





defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Navia_Post_Meta_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-post-meta';
	}

	public function get_title() {
		return __( 'Navia Post Meta', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-post-info';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'meta', 'date', 'author', 'reading', 'navia' ];
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Items', 'custom-hf-elementor' ) ] );

		$this->add_control( 'show_date', [ 'label' => __( 'Date', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_updated', [ 'label' => __( 'Show updated date when different', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => '' ] );
		$this->add_control( 'show_category', [ 'label' => __( 'Category', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_reading_time', [ 'label' => __( 'Reading time', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'reading_label', [ 'label' => __( 'Reading time label', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'min read', 'custom-hf-elementor' ), 'condition' => [ 'show_reading_time' => 'yes' ] ] );
		$this->add_control( 'show_author', [ 'label' => __( 'Author', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => '' ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => __( 'Style', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'color', [ 'label' => __( 'Color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#7A8A91', 'selectors' => [ '{{WRAPPER}} .navia-post-meta' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'typography', 'selector' => '{{WRAPPER}} .navia-post-meta' ] );

		$this->end_controls_section();
	}

	protected function render() {
		$post_id = CHF_Context::post_id();
		if ( ! $post_id ) {
			return;
		}
		$settings = $this->get_settings_for_display();
		$parts    = [];

		if ( 'yes' === $settings['show_date'] ) {
			$date = '<time datetime="' . esc_attr( get_the_date( 'c', $post_id ) ) . '">' . esc_html( get_the_date( '', $post_id ) ) . '</time>';
			if ( 'yes' === $settings['show_updated'] && get_the_date( 'Ymd', $post_id ) !== get_the_modified_date( 'Ymd', $post_id ) ) {
				$date .= ' <span class="navia-post-meta__updated">(' . esc_html__( 'updated', 'custom-hf-elementor' ) . ' ' . esc_html( get_the_modified_date( '', $post_id ) ) . ')</span>';
			}
			$parts[] = $date;
		}

		if ( 'yes' === $settings['show_category'] ) {
			$cats = get_the_category( $post_id );
			if ( $cats ) {
				$parts[] = '<a href="' . esc_url( get_category_link( $cats[0] ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
			}
		}

		if ( 'yes' === $settings['show_reading_time'] ) {
			$content = get_post_field( 'post_content', $post_id );
			$minutes = max( 1, (int) ceil( str_word_count( wp_strip_all_tags( $content ) ) / 200 ) );
			$parts[] = esc_html( $minutes . ' ' . $settings['reading_label'] );
		}

		if ( 'yes' === $settings['show_author'] ) {
			$parts[] = esc_html( get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ) );
		}

		if ( ! $parts ) {
			return;
		}

		echo '<div class="navia-post-meta">' . implode( '<span class="navia-post-meta__sep" aria-hidden="true"> &middot; </span>', $parts ) . '</div>';
	}
}
