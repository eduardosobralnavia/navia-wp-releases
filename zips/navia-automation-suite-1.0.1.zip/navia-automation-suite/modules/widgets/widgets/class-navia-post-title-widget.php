<?php




defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Navia_Post_Title_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-post-title';
	}

	public function get_title() {
		return __( 'Navia Post Title', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-post-title';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'title', 'post', 'dynamic', 'navia' ];
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Title', 'custom-hf-elementor' ) ] );

		$this->add_control(
			'tag',
			[
				'label'   => __( 'HTML tag', 'custom-hf-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h1',
				'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'div' => 'div' ],
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'     => __( 'Alignment', 'custom-hf-elementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [ 'title' => __( 'Left', 'custom-hf-elementor' ), 'icon' => 'eicon-text-align-left' ],
					'center' => [ 'title' => __( 'Center', 'custom-hf-elementor' ), 'icon' => 'eicon-text-align-center' ],
					'right'  => [ 'title' => __( 'Right', 'custom-hf-elementor' ), 'icon' => 'eicon-text-align-right' ],
				],
				'selectors' => [ '{{WRAPPER}} .navia-post-title' => 'text-align: {{VALUE}};' ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => __( 'Style', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'color', [ 'label' => __( 'Color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .navia-post-title' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'typography', 'selector' => '{{WRAPPER}} .navia-post-title' ] );

		$this->end_controls_section();
	}

	protected function render() {
		$post_id = CHF_Context::post_id();
		if ( ! $post_id ) {
			return;
		}
		$settings = $this->get_settings_for_display();
		$tag      = in_array( $settings['tag'], [ 'h1', 'h2', 'h3', 'div' ], true ) ? $settings['tag'] : 'h1';

		printf(
			'<%1$s class="navia-post-title">%2$s</%1$s>',
			esc_html( $tag ),
			esc_html( get_the_title( $post_id ) )
		);
	}
}
