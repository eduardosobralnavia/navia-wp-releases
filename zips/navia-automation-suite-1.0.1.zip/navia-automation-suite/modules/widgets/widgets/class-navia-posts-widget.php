<?php






defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Navia_Posts_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-posts';
	}

	public function get_title() {
		return __( 'Navia Posts', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'posts', 'blog', 'grid', 'articles', 'navia' ];
	}

	public function get_style_depends() {
		return [ 'navia-blog' ];
	}

	public function get_script_depends() {
		return [ 'navia-blog' ];
	}

	private function get_category_options() {
		$options = [];
		$terms   = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$options[ $term->term_id ] = $term->name;
			}
		}
		return $options;
	}

	protected function register_controls() {


		$this->start_controls_section( 'section_query', [ 'label' => __( 'Query', 'custom-hf-elementor' ) ] );

		$this->add_control( 'posts_per_page', [ 'label' => __( 'Posts to show', 'custom-hf-elementor' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 24, 'default' => 9 ] );
		$this->add_control( 'categories', [ 'label' => __( 'Categories (empty = all)', 'custom-hf-elementor' ), 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'options' => $this->get_category_options(), 'default' => [] ] );
		$this->add_control(
			'orderby',
			[
				'label'   => __( 'Order by', 'custom-hf-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'          => __( 'Date', 'custom-hf-elementor' ),
					'title'         => __( 'Title', 'custom-hf-elementor' ),
					'rand'          => __( 'Random', 'custom-hf-elementor' ),
					'comment_count' => __( 'Comment count', 'custom-hf-elementor' ),
				],
			]
		);
		$this->add_control( 'order', [ 'label' => __( 'Order', 'custom-hf-elementor' ), 'type' => Controls_Manager::SELECT, 'default' => 'DESC', 'options' => [ 'DESC' => __( 'Newest first', 'custom-hf-elementor' ), 'ASC' => __( 'Oldest first', 'custom-hf-elementor' ) ] ] );

		$this->end_controls_section();


		$this->start_controls_section( 'section_layout', [ 'label' => __( 'Layout', 'custom-hf-elementor' ) ] );

		$this->add_responsive_control(
			'columns',
			[
				'label'          => __( 'Columns', 'custom-hf-elementor' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ],
				'selectors'      => [ '{{WRAPPER}} .navia-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);' ],
			]
		);
		$this->add_responsive_control( 'grid_gap', [ 'label' => __( 'Gap', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 28, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .navia-grid' => 'gap: {{SIZE}}{{UNIT}};' ] ] );
		$this->add_control( 'show_image', [ 'label' => __( 'Featured image', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_category', [ 'label' => __( 'Category badge', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_date', [ 'label' => __( 'Date', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_excerpt', [ 'label' => __( 'Excerpt', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'excerpt_length', [ 'label' => __( 'Excerpt length (words)', 'custom-hf-elementor' ), 'type' => Controls_Manager::NUMBER, 'min' => 5, 'max' => 80, 'default' => 22, 'condition' => [ 'show_excerpt' => 'yes' ] ] );
		$this->add_control( 'read_more', [ 'label' => __( 'Read more text (empty = hidden)', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Read article', 'custom-hf-elementor' ) ] );

		$this->end_controls_section();


		$this->start_controls_section( 'section_load_more', [ 'label' => __( 'Load more', 'custom-hf-elementor' ) ] );

		$this->add_control( 'show_load_more', [ 'label' => __( 'Load more button', 'custom-hf-elementor' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'load_more_text', [ 'label' => __( 'Button text', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Load more articles', 'custom-hf-elementor' ), 'condition' => [ 'show_load_more' => 'yes' ] ] );
		$this->add_control( 'loading_text', [ 'label' => __( 'Loading text', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Loading...', 'custom-hf-elementor' ), 'condition' => [ 'show_load_more' => 'yes' ] ] );
		$this->add_control( 'no_more_text', [ 'label' => __( 'All loaded text', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'You have read everything', 'custom-hf-elementor' ), 'condition' => [ 'show_load_more' => 'yes' ] ] );

		$this->end_controls_section();

		$this->register_card_style_controls();


		$this->start_controls_section( 'section_style_button', [ 'label' => __( 'Load more button', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_load_more' => 'yes' ] ] );

		$this->add_control( 'btn_bg', [ 'label' => __( 'Background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .navia-load-more' => 'background-color: {{VALUE}};' ] ] );
		$this->add_control( 'btn_color', [ 'label' => __( 'Text color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .navia-load-more' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'btn_bg_hover', [ 'label' => __( 'Background hover', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#A34523', 'selectors' => [ '{{WRAPPER}} .navia-load-more:hover' => 'background-color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'btn_typography', 'selector' => '{{WRAPPER}} .navia-load-more' ] );
		$this->add_control( 'btn_radius', [ 'label' => __( 'Radius', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 999 ] ], 'default' => [ 'size' => 999, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .navia-load-more' => 'border-radius: {{SIZE}}{{UNIT}};' ] ] );

		$this->end_controls_section();
	}





	protected function register_card_style_controls() {
		$this->start_controls_section( 'section_style_card', [ 'label' => __( 'Cards', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'card_bg', [ 'label' => __( 'Card background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .navia-card' => 'background-color: {{VALUE}};' ] ] );
		$this->add_control( 'card_border_color', [ 'label' => __( 'Border color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#E7E1D6', 'selectors' => [ '{{WRAPPER}} .navia-card' => 'border-color: {{VALUE}};' ] ] );
		$this->add_control( 'card_radius', [ 'label' => __( 'Radius', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 14, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .navia-card' => 'border-radius: {{SIZE}}{{UNIT}};' ] ] );
		$this->add_control( 'image_ratio', [ 'label' => __( 'Image height (ratio %)', 'custom-hf-elementor' ), 'type' => Controls_Manager::SLIDER, 'range' => [ '%' => [ 'min' => 30, 'max' => 100 ] ], 'default' => [ 'size' => 58, 'unit' => '%' ], 'selectors' => [ '{{WRAPPER}} .navia-card__media' => 'padding-top: {{SIZE}}%;' ] ] );

		$this->add_control( 'title_color', [ 'label' => __( 'Title color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .navia-card__title a' => 'color: {{VALUE}};' ], 'separator' => 'before' ] );
		$this->add_control( 'title_color_hover', [ 'label' => __( 'Title hover color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .navia-card__title a:hover' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'title_typography', 'selector' => '{{WRAPPER}} .navia-card__title' ] );

		$this->add_control( 'excerpt_color', [ 'label' => __( 'Excerpt color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#4A5A61', 'selectors' => [ '{{WRAPPER}} .navia-card__excerpt' => 'color: {{VALUE}};' ], 'separator' => 'before' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'excerpt_typography', 'selector' => '{{WRAPPER}} .navia-card__excerpt' ] );

		$this->add_control( 'meta_color', [ 'label' => __( 'Date color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#7A8A91', 'selectors' => [ '{{WRAPPER}} .navia-card__date' => 'color: {{VALUE}};' ], 'separator' => 'before' ] );
		$this->add_control( 'cat_bg', [ 'label' => __( 'Category badge background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#F3E4DC', 'selectors' => [ '{{WRAPPER}} .navia-card__cat' => 'background-color: {{VALUE}};' ] ] );
		$this->add_control( 'cat_color', [ 'label' => __( 'Category badge text', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#A34523', 'selectors' => [ '{{WRAPPER}} .navia-card__cat' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'more_color', [ 'label' => __( 'Read more color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .navia-card__more' => 'color: {{VALUE}};' ] ] );

		$this->end_controls_section();
	}




	protected function build_config( $settings ) {
		$c                   = Navia_Cards::config_defaults();
		$c['per_page']       = ! empty( $settings['posts_per_page'] ) ? (int) $settings['posts_per_page'] : 9;
		$c['cats']           = ! empty( $settings['categories'] ) ? array_map( 'absint', (array) $settings['categories'] ) : [];
		$c['orderby']        = ! empty( $settings['orderby'] ) ? $settings['orderby'] : 'date';
		$c['order']          = ! empty( $settings['order'] ) ? $settings['order'] : 'DESC';
		$c['show_image']     = ( 'yes' === $settings['show_image'] ) ? 'yes' : 'no';
		$c['show_category']  = ( 'yes' === $settings['show_category'] ) ? 'yes' : 'no';
		$c['show_date']      = ( 'yes' === $settings['show_date'] ) ? 'yes' : 'no';
		$c['show_excerpt']   = ( 'yes' === $settings['show_excerpt'] ) ? 'yes' : 'no';
		$c['excerpt_length'] = ! empty( $settings['excerpt_length'] ) ? (int) $settings['excerpt_length'] : 22;
		$c['read_more']      = isset( $settings['read_more'] ) ? $settings['read_more'] : '';
		return $c;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$c        = $this->build_config( $settings );

		$query = new WP_Query( Navia_Cards::query_args( $c ) );

		if ( ! $query->have_posts() ) {
			echo '<p class="navia-empty">' . esc_html__( 'No articles published yet. New guides are on the way.', 'custom-hf-elementor' ) . '</p>';
			return;
		}

		$total    = (int) $query->found_posts;
		$has_more = $query->post_count < $total;
		?>
		<div class="navia-posts" data-config="<?php echo esc_attr( wp_json_encode( $c ) ); ?>" data-page="0">
			<div class="navia-grid">
				<?php echo Navia_Cards::render_cards_html( $query, $c ); ?>
			</div>
			<?php if ( 'yes' === $settings['show_load_more'] && $has_more ) : ?>
				<div class="navia-load-more-wrap">
					<button type="button" class="navia-load-more"
						data-label="<?php echo esc_attr( $settings['load_more_text'] ); ?>"
						data-loading="<?php echo esc_attr( $settings['loading_text'] ); ?>"
						data-done="<?php echo esc_attr( $settings['no_more_text'] ); ?>">
						<?php echo esc_html( $settings['load_more_text'] ); ?>
					</button>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
