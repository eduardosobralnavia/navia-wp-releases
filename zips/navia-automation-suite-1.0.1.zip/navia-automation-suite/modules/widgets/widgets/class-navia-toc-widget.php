<?php






defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Navia_TOC_Widget extends Widget_Base {

	public function get_name() {
		return 'navia-toc';
	}

	public function get_title() {
		return __( 'Navia Table of Contents', 'custom-hf-elementor' );
	}

	public function get_icon() {
		return 'eicon-table-of-contents';
	}

	public function get_categories() {
		return [ 'navia-elements' ];
	}

	public function get_keywords() {
		return [ 'toc', 'index', 'contents', 'navia' ];
	}

	public function get_style_depends() {
		return [ 'navia-blog' ];
	}

	public function get_script_depends() {
		return [ 'navia-blog' ];
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Table of Contents', 'custom-hf-elementor' ) ] );

		$this->add_control( 'toc_title', [ 'label' => __( 'Title', 'custom-hf-elementor' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'In this article', 'custom-hf-elementor' ) ] );
		$this->add_control(
			'levels',
			[
				'label'   => __( 'Heading levels', 'custom-hf-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h2'    => __( 'H2 only', 'custom-hf-elementor' ),
					'h2,h3' => __( 'H2 and H3', 'custom-hf-elementor' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => __( 'Style', 'custom-hf-elementor' ), 'tab' => Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'box_bg', [ 'label' => __( 'Background', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .navia-toc' => 'background-color: {{VALUE}};' ] ] );
		$this->add_control( 'box_border', [ 'label' => __( 'Border color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#E7E1D6', 'selectors' => [ '{{WRAPPER}} .navia-toc' => 'border-color: {{VALUE}};' ] ] );
		$this->add_control( 'title_color', [ 'label' => __( 'Title color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#16323B', 'selectors' => [ '{{WRAPPER}} .navia-toc__title' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'title_typography', 'label' => __( 'Title typography', 'custom-hf-elementor' ), 'selector' => '{{WRAPPER}} .navia-toc__title' ] );
		$this->add_control( 'link_color', [ 'label' => __( 'Link color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#4A5A61', 'selectors' => [ '{{WRAPPER}} .navia-toc a' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'link_hover', [ 'label' => __( 'Link hover color', 'custom-hf-elementor' ), 'type' => Controls_Manager::COLOR, 'default' => '#C4572E', 'selectors' => [ '{{WRAPPER}} .navia-toc a:hover' => 'color: {{VALUE}};' ] ] );

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$levels   = ( 'h2,h3' === $settings['levels'] ) ? 'h2,h3' : 'h2';
		?>
		<div class="navia-toc" data-levels="<?php echo esc_attr( $levels ); ?>" hidden>
			<p class="navia-toc__title"><?php echo esc_html( $settings['toc_title'] ); ?></p>
			<ol class="navia-toc__list"></ol>
		</div>
		<?php
		if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
			echo '<div style="padding:12px;border:1px dashed #ccc;font-size:13px;">' . esc_html__( 'Table of Contents: built automatically on the live page from the headings of the Navia Post Content widget.', 'custom-hf-elementor' ) . '</div>';
		}
	}
}
