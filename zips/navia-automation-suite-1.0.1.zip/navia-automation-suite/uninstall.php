<?php








defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$nas_site_options = array( 'nas_site', 'nas_flush_rewrite' );
$nas_net_options  = array( 'nas_network', 'nas_version', 'nas_update_log', 'nas_seen_versions' );

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $nas_blog ) {
		switch_to_blog( (int) $nas_blog );
		foreach ( $nas_site_options as $nas_o ) {
			delete_option( $nas_o );
		}
		restore_current_blog();
	}
	foreach ( $nas_net_options as $nas_o ) {
		delete_site_option( $nas_o );
	}
	delete_site_transient( 'nas_manifest' );
} else {
	foreach ( array_merge( $nas_site_options, $nas_net_options ) as $nas_o ) {
		delete_option( $nas_o );
	}
	delete_transient( 'nas_manifest' );
}
