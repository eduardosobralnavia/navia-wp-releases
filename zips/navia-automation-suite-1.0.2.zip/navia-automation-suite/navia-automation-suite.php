<?php
/**
 * Plugin Name:       Navia Automation Suite
 * Description:       Navia Digital site tools.
 * Version:           1.0.2
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Author:            Navia Digital
 * License:           GPL-2.0-or-later
 * Text Domain:       navia-automation-suite
 * Update URI:        https://github.com/eduardosobralnavia/navia-wp-releases
 */

defined( 'ABSPATH' ) || exit;

define( 'NAS_VERSION', '1.0.2' );
define( 'NAS_FILE', __FILE__ );
define( 'NAS_DIR', plugin_dir_path( __FILE__ ) );
define( 'NAS_URL', plugin_dir_url( __FILE__ ) );

require_once NAS_DIR . 'includes/class-nas-env.php';
require_once NAS_DIR . 'includes/class-nas-settings.php';
require_once NAS_DIR . 'includes/class-nas-cache.php';
require_once NAS_DIR . 'includes/class-nas-checks.php';
require_once NAS_DIR . 'includes/class-nas-updater.php';
require_once NAS_DIR . 'includes/class-nas-admin.php';
require_once NAS_DIR . 'includes/class-nas-abilities.php';
require_once NAS_DIR . 'includes/class-nas-plugin.php';

NAS_Plugin::bootstrap();

register_activation_hook( __FILE__, array( 'NAS_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'NAS_Plugin', 'deactivate' ) );
